<?php
include('db_connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $date = $_POST['date'];
    $shift = $_POST['shift'];
    $shift_start_time = $_POST['shift_start_time'];
    $shift_end_time = $_POST['shift_end_time'];
    $customer = $_POST['customer'];
    $machine_number = $_POST['machine_number'];
    $setup = $_POST['setup'];
    $cycle_minutes = $_POST['cycle_minutes'];
    $cycle_seconds = $_POST['cycle_seconds'];
    $loading_time = $_POST['loading_time'];
    $hourly_target = $_POST['hourly_target'];
    $shift_target = $_POST['shift_target'];
    $setter_name = $_POST['setter_name'];
    $operator_name = $_POST['operator_name'];
    $ref_number = $_POST['ref_number'];
	$drowing = $_POST['drowing'];
    $lot_number = $_POST['lot_number'];
    $lot_qty = $_POST['lot_qty'];
    $heat_number = $_POST['heat_number'];
    $grade = $_POST['grade'];
    $part_count_1st = $_POST['part_count_1st'];
    $part_count_2nd = $_POST['part_count_2nd'];
    $part_count_3rd = $_POST['part_count_3rd'];
    $pcwp = $_POST['pcwp'];
    $breakdown_list = $_POST['breakdown_list'];
    $breakdown_time = $_POST['breakdown_time'];
    $total_production = $_POST['total_production'];

    // Insert into database
    $sql = "INSERT INTO production (`date`, shift, shift_start_time, shift_end_time, customer, machine_number, setup, cycle_minutes, cycle_seconds, loading_time, hourly_target, shift_target, setter_name, operator_name, ref_number, drowing, lot_number, lot_qty, heat_number, grade, part_count_1st, part_count_2nd, part_count_3rd, pcwp, breakdown_list, breakdown_time, total_production) 
VALUES ('$date', '$shift', '$shift_start_time', '$shift_end_time', '$customer', '$machine_number', '$setup', '$cycle_minutes', '$cycle_seconds', '$loading_time', '$hourly_target', '$shift_target', '$setter_name', '$operator_name', '$ref_number', '$drowing', '$lot_number', '$lot_qty', '$heat_number', '$grade', '$part_count_1st', '$part_count_2nd', '$part_count_3rd', '$pcwp', '$breakdown_list', '$breakdown_time', '$total_production')";


if ($conn->query($sql) === TRUE) {
        echo "<div style='text-align:center; margin-top: 50px;'>
                <h2 style='color: green;'>New record added successfully!</h2>
                <a href='maintenance_check_sheet.php?date=" . urlencode($date) . "&shift=" . urlencode($shift) . "&machine=" . urlencode($machine_number) . "' style='
                    display: inline-block;
                    margin-top: 20px;
                    padding: 10px 20px;
                    background-color: #007BFF;
                    color: white;
                    text-decoration: none;
                    border-radius: 5px;
                    font-size: 16px;
                '>+ Add Maintenance Record</a>
              </div>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>