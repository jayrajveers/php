<!-- Stylish Add Button -->
<div style="margin: 20px 0; text-align: center;">
    <a href="form.php" style="
        background-color: #28a745;
        color: white;
        padding: 12px 25px;
        text-decoration: none;
        border-radius: 6px;
        font-weight: bold;
        font-size: 16px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        transition: background-color 0.3s ease;
    " onmouseover="this.style.backgroundColor='#218838'" onmouseout="this.style.backgroundColor='#28a745'">
        ➕ Add New Record
    </a>
</div>

<!-- Search Form -->
<div style="text-align: center; margin-top: 20px;">
    <form method="GET" action="">
        <label for="date" style="font-size: 16px; font-weight: bold;">🔍 Search by Date:</label>
        <input type="text" name="date" id="date" placeholder="Enter date" required style="padding: 8px; font-size: 16px;">
        <button type="submit" style="
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            margin-left: 10px;
        ">Search</button>
    </form>
</div>

<!-- Download Buttons -->
<div style="text-align: center; margin-top: 20px;">
    <button onclick="window.location.href='export_excel.php'" style="
        background-color: #007bff;
        color: white;
        padding: 10px 25px;
        margin-right: 20px;
        border: none;
        border-radius: 6px;
        font-size: 16px;
        cursor: pointer;
    ">⬇️ Download Excel</button>

    <button onclick="window.location.href='export_pdf.php'" style="
        background-color: #dc3545;
        color: white;
        padding: 10px 25px;
        border: none;
        border-radius: 6px;
        font-size: 16px;
        cursor: pointer;
    ">⬇️ Download PDF</button>
</div>


<?php
include('db_connection.php');

if (isset($_GET['date'])) {
    $date = $_GET['date'];

    // SQL query to search based on Lot Number
    $sql = "SELECT * FROM production WHERE date = '$date'";
    $result = $conn->query($sql);

    // Check if any records were found
    if ($result->num_rows > 0) {
        // Styling for the table
        echo "
        <style>
            table {
                width: 100%;
                border-collapse: collapse;
                margin: 20px 0;
                font-family: 'Segoe UI', sans-serif;
                font-size: 14px;
            }
            th, td {
                padding: 10px 12px;
                border: 1px solid #ccc;
                text-align: center;
            }
            th {
                background-color: #343a40;
                color: #fff;
            }
            tr:nth-child(even) {
                background-color: #f2f2f2;
            }
            tr:hover {
                background-color: #e9f7ef;
            }
            a {
                color: #007bff;
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }
        </style>";

        // Table Header
        echo "<table>
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Shift</th>
                    <th>Shift Start Time</th>
                    <th>Shift End Time</th>
                    <th>Customer</th>
                    <th>Machine Number</th>
					<th>Setup</th>
					<th>Cycle Minutes</th>
					<th>Cycle Seconds</th>
					<th>Loading Time</th>
					<th>Hourly Production</th>
					<th>Shift Production</th>
                    <th>Setter Name</th>
                    <th>Operator Name</th>
                    <th>Ref Number</th>
					<th>Drowing & Rev no.</th>
					<th>Lot Number</th>
                    <th>Lot Qty</th>
                    <th>Heat Number</th>
					<th>Grade</th>
                    <th>Part Count 1st</th>
                    <th>Part Count 2nd</th>
                    <th>Part Count 3rd</th>
					<th>PCWP</th>
                    <th>Breakdwon List</th>
					<th>Breakdown Time</th>
                    <th>Total Production</th>
					</tr>";

        // Display Data
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row['id'] . "</td>
                    <td>" . $row['date'] . "</td>
                    <td>" . $row['shift'] . "</td>
                    <td>" . $row['shift_start_time'] . "</td>
                    <td>" . $row['shift_end_time'] . "</td>
                    <td>" . $row['customer'] . "</td>
                    <td>" . $row['machine_number'] . "</td>
					<td>" . $row['setup'] . "</td>
					<td>" . $row['cycle_minutes'] . "</td>
					<td>" . $row['cycle_seconds'] . "</td>
					<td>" . $row['loading_time'] . "</td>
					<td>" . $row['hourly_target'] . "</td>
					<td>" . $row['shift_target'] . "</td>
					<td>" . $row['setter_name'] . "</td>
                    <td>" . $row['operator_name'] . "</td>
                    <td>" . $row['ref_number'] . "</td>
					<td>" . $row['drowing'] . "</td>
                    <td>" . $row['lot_number'] . "</td>
                    <td>" . $row['lot_qty'] . "</td>
                    <td>" . $row['heat_number'] . "</td>
					<td>" . $row['grade'] . "</td>
                    <td>" . $row['part_count_1st'] . "</td>
                    <td>" . $row['part_count_2nd'] . "</td>
                    <td>" . $row['part_count_3rd'] . "</td>
					<td>" . $row['pcwp'] . "</td>
                    <td>" . $row['breakdown_list'] . "</td>
                    <td>" . $row['breakdown_time'] . "</td>
                    <td>" . $row['total_production'] . "</td>
					</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color: red; text-align: center; font-weight: bold;'>❌ No records found for the given date.</p>";
    }

    $conn->close();
}
?>
