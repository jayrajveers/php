<?php

// --- 1. ડેટાબેઝ ગોઠવણી ---
define('DB_SERVER', 'localhost'); // તમારું ડેટાબેઝ સર્વર
define('DB_USERNAME', 'root'); // તમારું ડેટાબેઝ યુઝરનેમ
define('DB_PASSWORD', ''); // તમારો ડેટાબેઝ પાસવર્ડ
define('DB_NAME', 'dasp'); // આપણે બનાવેલા ડેટાબેઝનું નામ
define('MACHINE_DB_NAME', 'dasp'); // dasp ડેટાબેઝનું નામ

// dasp ડેટાબેઝ કનેક્શન બનાવો
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// કનેક્શન તપાસો
if ($conn->connect_error) {
    die("કનેક્શન નિષ્ફળ થયું: " . $conn->connect_error);
}

// dasp ડેટાબેઝ કનેક્શન બનાવો (મશીન ડેટા માટે)
$machine_conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, MACHINE_DB_NAME);

// કનેક્શન તપાસો
if ($machine_conn->connect_error) {
    die("મશીન ડેટા કનેક્શન નિષ્ફળ થયું: " . $machine_conn->connect_error);
}


// --- 2. કાર્યક્ષમતાઓ ---

/**
 * ડેટાબેઝમાં ફેરફારનો ઇતિહાસ લોગ કરે છે.
 * @param int $partId સંબંધિત પાર્ટ ID.
 * @param string $changeType ફેરફારનો પ્રકાર (દા.ત., 'ADD_PART', 'EDIT_PART', 'ADD_PARAM').
 * @param string $description ફેરફારનું સંક્ષિપ્ત વર્ણન.
 * @param mixed $oldValue (વૈકલ્પિક) ફેરફાર પહેલાંનો ડેટા.
 * @param mixed $newValue (વૈકલ્પિક) ફેરફાર પછીનો ડેટા.
 * @param string $changedBy ફેરફાર કરનાર વ્યક્તિ.
 */
function logPartHistory($partId, $changeType, $description, $oldValue = null, $newValue = null, $changedBy = 'System') {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO part_history (part_id, change_type, description, old_value, new_value, changed_by) VALUES (?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        error_log("SQL Prepare Error (logPartHistory): " . $conn->error);
        return false;
    }

    // Convert arrays/objects to JSON strings for storage
    $oldValueJson = is_array($oldValue) || is_object($oldValue) ? json_encode($oldValue) : $oldValue;
    $newValueJson = is_array($newValue) || is_object($newValue) ? json_encode($newValue) : $newValue;

    $stmt->bind_param("isssss", $partId, $changeType, $description, $oldValueJson, $newValueJson, $changedBy);
    if ($stmt->execute()) {
        $stmt->close();
        return true;
    } else {
        error_log("ઇતિહાસ લોગ કરવામાં ભૂલ: " . $stmt->error);
        $stmt->close();
        return false;
    }
}

/**
 * ગ્રાહક પહેલેથી અસ્તિત્વમાં છે કે નહીં તે તપાસે છે, જો નહીં, તો તેને ઉમેરે છે.
 * @param string $customerName ગ્રાહકનું નામ.
 * @return int|false ગ્રાહક ID અથવા નિષ્ફળતા પર false.
 */
function getOrCreateCustomer($customerName) {
    global $conn;
    $stmt = $conn->prepare("SELECT id FROM customers WHERE customer_name = ?");
    if ($stmt === false) {
        error_log("SQL Prepare Error (getOrCreateCustomer - SELECT): " . $conn->error);
        return false;
    }
    $stmt->bind_param("s", $customerName);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $stmt->close();
        return $row['id'];
    } else {
        $stmt->close();
        $stmt = $conn->prepare("INSERT INTO customers (customer_name) VALUES (?)");
        if ($stmt === false) {
            error_log("SQL Prepare Error (getOrCreateCustomer - INSERT): " . $conn->error);
            return false;
        }
        $stmt->bind_param("s", $customerName);
        if ($stmt->execute()) {
            $new_id = $stmt->insert_id;
            $stmt->close();
            return $new_id;
        } else {
            error_log("ગ્રાહક ઉમેરવામાં ભૂલ: " . $stmt->error);
            $stmt->close();
            return false;
        }
    }
}

/**
 * નવો પાર્ટ ઉમેરે છે.
 * @param string $customerName ગ્રાહકનું નામ.
 * @param string $partName પાર્ટનું નામ.
 * @param string $partNumber પાર્ટ નંબર.
 * @param string $partCode પાર્ટ કોડ.
 * @param string|null $drawingRev ડ્રોઈંગ રિવિઝન.
 * @param string|null $gradeAsPerDrawing ડ્રોઈંગ મુજબનો ગ્રેડ. (નવું ફિલ્ડ)
 * @return bool સફળતા પર true, નિષ્ફળતા પર false.
 */
function addPart($customerName, $partName, $partNumber, $partCode, $drawingRev = null, $gradeAsPerDrawing = null) {
    global $conn;
    $customer_id = getOrCreateCustomer($customerName);
    if ($customer_id === false) {
        return false;
    }

    // Check if part_number already exists
    $check_stmt = $conn->prepare("SELECT id FROM parts WHERE part_number = ?");
    if ($check_stmt === false) {
        error_log("SQL Prepare Error (addPart - check): " . $conn->error);
        return false;
    }
    $check_stmt->bind_param("s", $partNumber);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        error_log("પાર્ટ નંબર '" . $partNumber . "' પહેલેથી જ અસ્તિત્વમાં છે.");
        $check_stmt->close();
        return false;
    }
    $check_stmt->close();

    // SQL INSERT statement with grade_as_per_drawing
    $stmt = $conn->prepare("INSERT INTO parts (customer_id, part_name, part_number, part_code, drawing_rev, grade_as_per_drawing) VALUES (?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        error_log("SQL Prepare Error (addPart): " . $conn->error);
        return false;
    }
    $stmt->bind_param("isssss", $customer_id, $partName, $partNumber, $partCode, $drawingRev, $gradeAsPerDrawing);
    if ($stmt->execute()) {
        $newPartId = $stmt->insert_id;
        $stmt->close();
        // logPartHistory with new field
        logPartHistory($newPartId, 'ADD_PART', "નવો પાર્ટ ઉમેરાયો: " . $partName . " (નંબર: " . $partNumber . ")", null, json_encode(['customer_name' => $customerName, 'part_name' => $partName, 'part_number' => $partNumber, 'part_code' => $partCode, 'drawing_rev' => $drawingRev, 'grade_as_per_drawing' => $gradeAsPerDrawing]));
        return true;
    } else {
        error_log("પાર્ટ ઉમેરવામાં ભૂલ: " . $stmt->error);
        $stmt->close();
        return false;
    }
}

/**
 * હાલના પાર્ટને અપડેટ કરે છે.
 * @param int $partId પાર્ટ ID.
 * @param string $customerName ગ્રાહકનું નામ.
 * @param string $partName પાર્ટનું નામ.
 * @param string $partNumber પાર્ટ નંબર.
 * @param string $partCode પાર્ટ કોડ.
 * @param string|null $drawingRev ડ્રોઈંગ રિવિઝન.
 * @param string|null $gradeAsPerDrawing ડ્રોઈંગ મુજબનો ગ્રેડ. (નવું ફિલ્ડ)
 * @return bool સફળતા પર true, નિષ્ફળતા પર false.
 */
function updatePart($partId, $customerName, $partName, $partNumber, $partCode, $drawingRev = null, $gradeAsPerDrawing = null) {
    global $conn;
    $customer_id = getOrCreateCustomer($customerName);
    if ($customer_id === false) {
        return false;
    }

    // Get old part data for logging including grade_as_per_drawing
    $old_part_data_stmt = $conn->prepare("SELECT c.customer_name, p.part_name, p.part_number, p.part_code, p.drawing_rev, p.grade_as_per_drawing FROM parts p JOIN customers c ON p.customer_id = c.id WHERE p.id = ?");
    if ($old_part_data_stmt === false) {
        error_log("SQL Prepare Error (updatePart - SELECT old data): " . $conn->error);
        return false;
    }
    $old_part_data_stmt->bind_param("i", $partId);
    $old_part_data_stmt->execute();
    $old_result = $old_part_data_stmt->get_result();
    $old_data = $old_result->fetch_assoc();
    $old_part_data_stmt->close();

    if (!$old_data) {
        error_log("પાર્ટ અપડેટ કરવામાં નિષ્ફળ: ID " . $partId . " મળ્યું નથી.");
        return false;
    }

    // SQL UPDATE statement with grade_as_per_drawing
    $stmt = $conn->prepare("UPDATE parts SET customer_id = ?, part_name = ?, part_number = ?, part_code = ?, drawing_rev = ?, grade_as_per_drawing = ? WHERE id = ?");
    if ($stmt === false) {
        error_log("SQL Prepare Error (updatePart): " . $conn->error);
        return false;
    }
    $stmt->bind_param("isssssi", $customer_id, $partName, $partNumber, $partCode, $drawingRev, $gradeAsPerDrawing, $partId);
    if ($stmt->execute()) {
        $stmt->close();
        // logPartHistory with old and new values for grade_as_per_drawing
        $old_values = json_encode($old_data);
        $new_values = json_encode(['customer_name' => $customerName, 'part_name' => $partName, 'part_number' => $partNumber, 'part_code' => $partCode, 'drawing_rev' => $drawingRev, 'grade_as_per_drawing' => $gradeAsPerDrawing]);
        logPartHistory($partId, 'EDIT_PART', "પાર્ટની વિગતો અપડેટ થઈ: " . $old_data['part_name'], $old_values, $new_values);
        return true;
    } else {
        error_log("પાર્ટ અપડેટ કરવામાં ભૂલ: " . $stmt->error);
        $stmt->close();
        return false;
    }
}

/**
 * પાર્ટને ડિલીટ કરે છે.
 * @param int $partId પાર્ટ ID.
 * @return bool સફળતા પર true, નિષ્ફળતા પર false.
 */
function deletePart($partId) {
    global $conn;

    // Get part data before deletion for logging
    $part_data_stmt = $conn->prepare("SELECT c.customer_name, p.part_name, p.part_number, p.part_code, p.drawing_rev, p.grade_as_per_drawing FROM parts p JOIN customers c ON p.customer_id = c.id WHERE p.id = ?");
    if ($part_data_stmt === false) {
        error_log("SQL Prepare Error (deletePart - SELECT): " . $conn->error);
        return false;
    }
    $part_data_stmt->bind_param("i", $partId);
    $part_data_stmt->execute();
    $result = $part_data_stmt->get_result();
    $part_info = $result->fetch_assoc();
    $part_data_stmt->close();

    if (!$part_info) {
        error_log("પાર્ટ ડીલીટ કરવામાં નિષ્ફળ: ID " . $partId . " મળ્યું નથી.");
        return false;
    }

    $stmt = $conn->prepare("DELETE FROM parts WHERE id = ?");
    if ($stmt === false) {
        error_log("SQL Prepare Error (deletePart): " . $conn->error);
        return false;
    }
    $stmt->bind_param("i", $partId);
    if ($stmt->execute()) {
        $stmt->close();
        logPartHistory($partId, 'DELETE_PART', "પાર્ટ ડીલીટ થયો: " . $part_info['part_name'] . " (નંબર: " . $part_info['part_number'] . ")", json_encode($part_info), null);
        return true;
    } else {
        error_log("પાર્ટ ડીલીટ કરવામાં ભૂલ: " . $stmt->error);
        $stmt->close();
        return false;
    }
}

/**
 * પાર્ટ પેરામીટર ઉમેરે છે.
 */
function addPartParameter($partId, $parameterName, $setupInfo, $specPositive = null, $specNegative = null, $specification = null, $measurementFrequency = null, $measurementMethod = null, $reactionPlan = null, $responsiblePerson = null, $imte = null) { //
    global $conn;
    $stmt = $conn->prepare("INSERT INTO part_parameters (part_id, parameter_name, setup_info, spec_positive, spec_negative, specification, measurement_frequency, measurement_method, reaction_plan, responsible_person, imte) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"); //
    if ($stmt === false) {
        error_log("SQL Prepare Error (addPartParameter): " . $conn->error);
        return false;
    }
    $stmt->bind_param("issssssssss", $partId, $parameterName, $setupInfo, $specPositive, $specNegative, $specification, $measurementFrequency, $measurementMethod, $reactionPlan, $responsiblePerson, $imte); //
    if ($stmt->execute()) {
        $newParamId = $stmt->insert_id;
        $stmt->close();
        logPartHistory($partId, 'ADD_PARAM', "નવું પેરામીટર ઉમેરાયું: " . $parameterName, null, json_encode(['parameter_name' => $parameterName, 'setup_info' => $setupInfo, 'spec_positive' => $specPositive, 'spec_negative' => $specNegative, 'specification' => $specification, 'measurement_frequency' => $measurementFrequency, 'measurement_method' => $measurementMethod, 'reaction_plan' => $reactionPlan, 'responsible_person' => $responsiblePerson, 'imte' => $imte])); //
        return true;
    } else {
        error_log("પેરામીટર ઉમેરવામાં ભૂલ: " . $stmt->error);
        $stmt->close();
        return false;
    }
}

/**
 * પાર્ટ પેરામીટર અપડેટ કરે છે.
 */
function updatePartParameter($paramId, $parameterName, $setupInfo, $specPositive = null, $specNegative = null, $specification = null, $measurementFrequency = null, $measurementMethod = null, $reactionPlan = null, $responsiblePerson = null) {
    global $conn;

    // Get old parameter data for logging
    $old_param_data_stmt = $conn->prepare("SELECT part_id, parameter_name, setup_info, spec_positive, spec_negative, specification, measurement_frequency, measurement_method, reaction_plan, responsible_person FROM part_parameters WHERE id = ?");
    if ($old_param_data_stmt === false) {
        error_log("SQL Prepare Error (updatePartParameter - SELECT old data): " . $conn->error);
        return false;
    }
    $old_param_data_stmt->bind_param("i", $paramId);
    $old_param_data_stmt->execute();
    $old_result = $old_param_data_stmt->get_result();
    $old_data = $old_result->fetch_assoc();
    $old_param_data_stmt->close();

    if (!$old_data) {
        error_log("પેરામીટર અપડેટ કરવામાં નિષ્ફળ: ID " . $paramId . " મળ્યું નથી.");
        return false;
    }

    $stmt = $conn->prepare("UPDATE part_parameters SET parameter_name = ?, setup_info = ?, spec_positive = ?, spec_negative = ?, specification = ?, measurement_frequency = ?, measurement_method = ?, reaction_plan = ?, responsible_person = ? WHERE id = ?");
    if ($stmt === false) {
        error_log("SQL Prepare Error (updatePartParameter): " . $conn->error);
        return false;
    }
    $stmt->bind_param("sssssssssi", $parameterName, $setupInfo, $specPositive, $specNegative, $specification, $measurementFrequency, $measurementMethod, $reactionPlan, $responsiblePerson, $paramId);
    if ($stmt->execute()) {
        $stmt->close();
        logPartHistory($old_data['part_id'], 'EDIT_PARAM', "પેરામીટર અપડેટ થયું: " . $old_data['parameter_name'], json_encode($old_data), json_encode(['parameter_name' => $parameterName, 'setup_info' => $setupInfo, 'spec_positive' => $specPositive, 'spec_negative' => $specNegative, 'specification' => $specification, 'measurement_frequency' => $measurementFrequency, 'measurement_method' => $measurementMethod, 'reaction_plan' => $reactionPlan, 'responsible_person' => $responsiblePerson]));
        return true;
    } else {
        error_log("પેરામીટર અપડેટ કરવામાં ભૂલ: " . $stmt->error);
        $stmt->close();
        return false;
    }
}

/**
 * પાર્ટ પેરામીટર ડિલીટ કરે છે.
 */
function deletePartParameter($paramId) {
    global $conn;

    // Get parameter data before deletion for logging
    $param_data_stmt = $conn->prepare("SELECT part_id, parameter_name FROM part_parameters WHERE id = ?");
    if ($param_data_stmt === false) {
        error_log("SQL Prepare Error (deletePartParameter - SELECT): " . $conn->error);
        return false;
    }
    $param_data_stmt->bind_param("i", $paramId);
    $param_data_stmt->execute();
    $result = $param_data_stmt->get_result();
    $param_info = $result->fetch_assoc();
    $param_data_stmt->close();

    if (!$param_info) {
        error_log("પેરામીટર ડીલીટ કરવામાં નિષ્ફળ: ID " . $paramId . " મળ્યું નથી.");
        return false;
    }

    $stmt = $conn->prepare("DELETE FROM part_parameters WHERE id = ?");
    if ($stmt === false) {
        error_log("SQL Prepare Error (deletePartParameter): " . $conn->error);
        return false;
    }
    $stmt->bind_param("i", $paramId);
    if ($stmt->execute()) {
        $stmt->close();
        logPartHistory($param_info['part_id'], 'DELETE_PARAM', "પેરામીટર ડીલીટ થયું: " . $param_info['parameter_name'], json_encode($param_info), null);
        return true;
    } else {
        error_log("પેરામીટર ડીલીટ કરવામાં ભૂલ: " . $stmt->error);
        $stmt->close();
        return false;
    }
}



/**
 * બધા પાર્ટ્સ અને તેમના પેરામીટર્સ લાવે છે.
 * @param string $search_query સર્ચ ક્વેરી (વૈકલ્પિક).
 * @return array પાર્ટ્સ અને તેમના પેરામીટર્સનો એરે.
 */
function getAllParts($search_query = '') {
    global $conn;
    $parts = [];
    $sql = "SELECT p.id AS part_id, c.customer_name, p.part_name, p.part_number, p.part_code, p.drawing_rev, p.grade_as_per_drawing
            FROM parts AS p
            JOIN customers AS c ON p.customer_id = c.id";

    if (!empty($search_query)) {
        $search_query_param = "%" . $search_query . "%";
        $sql .= " WHERE p.part_name LIKE ? OR p.part_number LIKE ? OR p.part_code LIKE ? OR c.customer_name LIKE ? OR p.drawing_rev LIKE ? OR p.grade_as_per_drawing LIKE ?";
    }
    $sql .= " ORDER BY c.customer_name, p.part_name";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (getAllParts): " . $conn->error);
        return [];
    }

    if (!empty($search_query)) {
        $stmt->bind_param("ssssss", $search_query_param, $search_query_param, $search_query_param, $search_query_param, $search_query_param, $search_query_param);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $part_id = $row['part_id'];
        $row['parameters'] = getParametersForPart($part_id);
        $parts[] = $row;
    }
    $stmt->close();
    return $parts;
}

/**
 * આપેલ પાર્ટ ID માટેના બધા પેરામીટર્સ લાવે છે.
 * @param int $partId પાર્ટ ID.
 * @return array પેરામીટર્સનો એરે.
 */
function getParametersForPart($partId) {
    global $conn;
    $parameters = [];
    // Select the 'imte' column as well
    $stmt = $conn->prepare("SELECT id, part_id, parameter_name, setup_info, spec_positive, spec_negative, specification, measurement_frequency, measurement_method, reaction_plan, responsible_person, imte FROM part_parameters WHERE part_id = ? ORDER BY parameter_name");
    if ($stmt === false) {
        error_log("SQL Prepare Error (getParametersForPart): " . $conn->error);
        return [];
    }
    $stmt->bind_param("i", $partId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $parameters[] = $row;
    }
    $stmt->close();
    return $parameters;
}
/**
 * આપેલ customer_id પરથી ગ્રાહકનું નામ મેળવે છે.
 *
 * @param int $customerId ગ્રાહકનો ID.
 * @return string|null ગ્રાહકનું નામ અથવા જો ન મળે તો null.
 */
function getCustomerNameById($customerId) {
    global $conn; // ગ્લોબલ કનેક્શન ઓબ્જેક્ટનો ઉપયોગ કરો

    $sql = "SELECT customer_name FROM customers WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $customerId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['customer_name'];
    } else {
        return null; // ગ્રાહક મળ્યો નથી
    }
}


/**
 * 'data_for_phpmyadmin' ટેબલમાંથી ગ્રાહકના નામો લાવે છે.
 */
function getCustomerSuggestions() {
    global $machine_conn;
    $suggestions = [];
    $result = $machine_conn->query("SELECT DISTINCT Customer FROM data_for_phpmyadmin ORDER BY Customer");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $suggestions[] = $row['Customer'];
        }
    } else {
        error_log("ગ્રાહક સૂચનો લાવવામાં ભૂલ: " . $machine_conn->error);
    }
    return $suggestions;
}

/**
 * 'data_for_phpmyadmin' ટેબલમાંથી Ref Number (Part Code) લાવે છે.
 */
function getRefNumberSuggestions() {
    global $machine_conn;
    $suggestions = [];
    $result = $machine_conn->query("SELECT DISTINCT `Ref Number` FROM data_for_phpmyadmin WHERE `Ref Number` IS NOT NULL AND `Ref Number` != '' ORDER BY `Ref Number`");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $suggestions[] = $row['Ref Number'];
        }
    } else {
        error_log("Ref Number સૂચનો લાવવામાં ભૂલ: " . $machine_conn->error);
    }
    return $suggestions;
}

// --- 3. ફોર્મ સબમિશન હેન્ડલિંગ ---
session_start();
$message = '';

// Check for and display messages
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Clear the message after displaying
}

// Determine the current search query for redirection
$current_search_query = isset($_GET['search_query']) ? urlencode($_GET['search_query']) : '';
$redirect_url = 'master_file.php';
if (!empty($current_search_query)) {
    $redirect_url .= '?search_query=' . $current_search_query;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add_part') {
            $customerName = $_POST['customer_name'];
            $partName = $_POST['part_name'];
            $partNumber = $_POST['part_number'];
            $partCode = $_POST['part_code'];
            $drawingRev = $_POST['drawing_rev'] ?? null;
            $gradeAsPerDrawing = $_POST['grade_as_per_drawing'] ?? null; // <<<-- નવું ફિલ્ડ

            if (addPart($customerName, $partName, $partNumber, $partCode, $drawingRev, $gradeAsPerDrawing)) { // <<<-- અહીં $gradeAsPerDrawing પાસ કરો
                $_SESSION['message'] = "<p class='success'>પાર્ટ સફળતાપૂર્વક ઉમેરાયો!</p>";
            } else {
                $_SESSION['message'] = "<p class='error'>પાર્ટ ઉમેરવામાં નિષ્ફળતા. કદાચ પાર્ટ નંબર પહેલેથી જ અસ્તિત્વમાં છે.</p>";
            }
            header("Location: " . $redirect_url);
            exit();
        } elseif ($_POST['action'] == 'update_part') {
            $partId = $_POST['part_id'];
            $customerName = $_POST['customer_name'];
            $partName = $_POST['part_name'];
            $partNumber = $_POST['part_number'];
            $partCode = $_POST['part_code'];
            $drawingRev = $_POST['drawing_rev'] ?? null;
            $gradeAsPerDrawing = $_POST['grade_as_per_drawing'] ?? null; // <<<-- નવું ફિલ્ડ

            if (updatePart($partId, $customerName, $partName, $partNumber, $partCode, $drawingRev, $gradeAsPerDrawing)) { // <<<-- અહીં $gradeAsPerDrawing પાસ કરો
                $_SESSION['message'] = "<p class='success'>પાર્ટ સફળતાપૂર્વક અપડેટ થયો!</p>";
            } else {
                $_SESSION['message'] = "<p class='error'>પાર્ટ અપડેટ કરવામાં નિષ્ફળતા.</p>";
            }
            header("Location: " . $redirect_url);
            exit();
        } elseif ($_POST['action'] == 'delete_part') {
            $partId = $_POST['part_id'];
            if (deletePart($partId)) {
                $_SESSION['message'] = "<p class='success'>પાર્ટ સફળતાપૂર્વક ડીલીટ થયો!</p>";
            } else {
                $_SESSION['message'] = "<p class='error'>પાર્ટ ડીલીટ કરવામાં નિષ્ફળતા.</p>";
            }
            header("Location: " . $redirect_url);
            exit();
        } elseif ($_POST['action'] == 'add_parameter') {
            $partId = $_POST['part_id'];
            $parameterName = $_POST['parameter_name'];
            $setupInfo = $_POST['setup_info'];
            $specPositive = $_POST['spec_positive'] ?? null;
            $specNegative = $_POST['spec_negative'] ?? null;
            $specification = $_POST['specification'] ?? null;
            $measurementFrequency = $_POST['measurement_frequency'] ?? null;
            $measurementMethod = $_POST['measurement_method'] ?? null;
            $reactionPlan = $_POST['reaction_plan'] ?? null;
            $responsiblePerson = $_POST['responsible_person'] ?? null;
            $imte = $_POST['imte'] ?? null; //

            if (addPartParameter($partId, $parameterName, $setupInfo, $specPositive, $specNegative, $specification, $measurementFrequency, $measurementMethod, $reactionPlan, $responsiblePerson, $imte)) { //
                $_SESSION['message'] = "<p class='success'>પેરામીટર સફળતાપૂર્વક ઉમેરાયું!</p>";
            } else {
                $_SESSION['message'] = "<p class='error'>પેરામીટર ઉમેરવામાં નિષ્ફળતા.</p>";
            }
            header("Location: " . $redirect_url . "#part_card_" . $partId);
            exit();
        } elseif ($_POST['action'] == 'update_parameter') {
            $paramId = $_POST['param_id'];
            $partId = $_POST['part_id']; // For redirection
            $parameterName = $_POST['parameter_name'];
            $setupInfo = $_POST['setup_info'];
            $specPositive = $_POST['spec_positive'] ?? null;
            $specNegative = $_POST['spec_negative'] ?? null;
            $specification = $_POST['specification'] ?? null;
            $measurementFrequency = $_POST['measurement_frequency'] ?? null;
            $measurementMethod = $_POST['measurement_method'] ?? null;
            $reactionPlan = $_POST['reaction_plan'] ?? null;
            $responsiblePerson = $_POST['responsible_person'] ?? null;

            if (updatePartParameter($paramId, $parameterName, $setupInfo, $specPositive, $specNegative, $specification, $measurementFrequency, $measurementMethod, $reactionPlan, $responsiblePerson)) {
                $_SESSION['message'] = "<p class='success'>પેરામીટર સફળતાપૂર્વક અપડેટ થયું!</p>";
            } else {
                $_SESSION['message'] = "<p class='error'>પેરામીટર અપડેટ કરવામાં નિષ્ફળતા.</p>";
            }
            header("Location: " . $redirect_url . "#part_card_" . $partId);
            exit();
        } elseif ($_POST['action'] == 'delete_parameter') {
            $paramId = $_POST['param_id'];
            $partId = $_POST['part_id']; // For redirection
            if (deletePartParameter($paramId)) {
                $_SESSION['message'] = "<p class='success'>પેરામીટર સફળતાપૂર્વક ડીલીટ થયું!</p>";
            } else {
                $_SESSION['message'] = "<p class='error'>પેરામીટર ડીલીટ કરવામાં નિષ્ફળતા.</p>";
            }
            header("Location: " . $redirect_url . "#part_card_" . $partId);
            exit();
        }
    }
}

// પાર્ટ્સ અને પેરામીટર્સ લાવવા
$search_query = $_GET['search_query'] ?? '';
$parts = getAllParts($search_query);

// ગ્રાહક અને Ref Number સૂચનો લાવવા
$customerSuggestions = getCustomerSuggestions();
$refNumberSuggestions = getRefNumberSuggestions();

?>

<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>પાર્ટ માસ્ટર ફાઇલ</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Gujarati:wght@400;700&display=swap');

        body {
            font-family: 'Noto Sans Gujarati', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 20px auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 25px;
            border-bottom: 2px solid #e0e0e0;
            padding-bottom: 15px;
            font-weight: 700;
        }

        .message {
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 5px;
            font-weight: bold;
            text-align: center;
            animation: fadeOut 5s forwards;
        }

        .success {
            background-color: #e6ffe6;
            color: #008000;
            border: 1px solid #008000;
        }

        .error {
            background-color: #ffe6e6;
            color: #ff0000;
            border: 1px solid #ff0000;
        }

        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; display: none; }
        }

        .form-section {
            background-color: #f9f9f9;
            padding: 25px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.05);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }

        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group textarea,
        .form-group select {
            width: calc(100% - 20px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
            box-sizing: border-box;
            background-color: #fff;
        }
         .form-group input[type="number"] {
            -moz-appearance: textfield; /* Firefox */
        }
        .form-group input::-webkit-outer-spin-button,
        .form-group input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }


        .form-group input[type="text"]:focus,
        .form-group input[type="number"]:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.25);
            outline: none;
        }

        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s ease;
            margin-right: 10px;
        }

        .btn-green {
            background-color: #28a745;
        }
        .btn-green:hover {
            background-color: #218838;
        }

        .btn-red {
            background-color: #dc3545;
        }
        .btn-red:hover {
            background-color: #c82333;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .btn-secondary {
            background-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }

        .search-bar {
            display: flex;
            margin-bottom: 25px;
            justify-content: center;
            gap: 10px;
        }

        .search-bar input[type="text"] {
            flex-grow: 1;
            max-width: 400px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }

        .part-card {
            background-color: #fff;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            margin-bottom: 20px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }

        .part-card:hover {
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transform: translateY(-3px);
        }

        .part-card h3 {
            color: #007bff;
            margin-top: 0;
            margin-bottom: 10px;
            cursor: pointer;
        }

        .part-card p {
            margin: 5px 0;
            line-height: 1.6;
        }

        .part-card .actions {
            margin-top: 15px;
            border-top: 1px solid #eee;
            padding-top: 15px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .parameter-list {
            border-top: 1px dashed #e0e0e0;
            margin-top: 20px;
            padding-top: 20px;
            display: none; /* Initially hidden */
        }

        .parameter-list h4 {
            color: #28a745;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .parameter-item {
            background-color: #f0f9ff; /* Light blue background for parameters */
            border: 1px solid #d0e9ff;
            border-left: 5px solid #007bff; /* Blue border on the left */
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            display: flex;
            flex-direction: column;
            gap: 5px;
            font-size: 0.95rem;
        }
        .parameter-item strong {
            color: #333;
        }

        .parameter-item .param-actions {
            margin-top: 10px;
            text-align: right;
        }

        .edit-form {
            background-color: #f0f0f0;
            padding: 20px;
            border-radius: 8px;
            margin-top: 15px;
            margin-bottom: 15px;
            display: none; /* Initially hidden */
        }

        .edit-form h4 {
            margin-top: 0;
            color: #007bff;
        }

        .compact-form-horizontal .form-group {
            display: inline-block;
            width: calc(33% - 20px); /* Three columns */
            margin-right: 15px;
            vertical-align: top;
        }
        .compact-form-horizontal .form-group:last-child {
            margin-right: 0;
        }

        @media (max-width: 992px) {
            .compact-form-horizontal .form-group {
                width: calc(50% - 20px); /* Two columns */
            }
        }

        @media (max-width: 768px) {
            .compact-form-horizontal .form-group {
                width: calc(100% - 20px); /* One column */
                margin-right: 0;
            }
        }

        .setup-group-container {
            display: flex;
            flex-wrap: wrap; /* Allow columns to wrap */
            gap: 20px; /* Space between columns */
            margin-top: 20px;
        }

        .setup-column {
            flex: 1; /* Each column takes equal space */
            min-width: 300px; /* Minimum width for columns before wrapping */
            background-color: #f7f7f7;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 15px;
        }

        .setup-column h5 {
            color: #0056b3;
            margin-top: 0;
            margin-bottom: 15px;
            font-size: 1.1rem;
            border-bottom: 1px dashed #d0e0f0;
            padding-bottom: 10px;
        }
        .home-button {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background-color: #0056b3;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .home-button:hover {
            background-color: #003d80;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="inprocess_master.php" class="home-button">હોમ પેજ</a>
        <h1>પાર્ટ માસ્ટર ફાઇલ મેનેજમેન્ટ</h1>

        <?php if (!empty($message)): ?>
            <div class="message <?= strpos($message, 'સફળતા') !== false ? 'success' : 'error' ?>">
                <?= $message ?>
            </div>
        <?php endif; ?>

        <div class="form-section">
            <h2>નવો પાર્ટ ઉમેરો</h2>
            <form action="master_file.php<?php echo !empty($current_search_query) ? '?search_query=' . $current_search_query : ''; ?>" method="POST" class="compact-form-horizontal">
                <input type="hidden" name="action" value="add_part">
                <div class="form-group">
                    <label for="customer_name">ગ્રાહકનું નામ:</label>
                    <input type="text" id="customer_name" name="customer_name" list="customer_suggestions" required placeholder="દા.ત., એબીસી કંપની">
                    <datalist id="customer_suggestions">
                        <?php foreach ($customerSuggestions as $customer): ?>
                            <option value="<?= htmlspecialchars($customer) ?>">
                        <?php endforeach; ?>
                    </datalist>
                </div>
                <div class="form-group">
                    <label for="part_name">પાર્ટનું નામ:</label>
                    <input type="text" id="part_name" name="part_name" required placeholder="દા.ત., ગીયર">
                </div>
                <div class="form-group">
                    <label for="part_number">પાર્ટ નંબર:</label>
                    <input type="text" id="part_number" name="part_number" required placeholder="દા.ત., P001-XYZ">
                </div>
                <div class="form-group">
                    <label for="part_code">
					
					
					
					</label>
                    <input type="text" id="part_code" name="part_code" list="ref_number_suggestions" placeholder="દા.ત., CDE-789">
                    <datalist id="ref_number_suggestions">
                        <?php foreach ($refNumberSuggestions as $refNum): ?>
                            <option value="<?= htmlspecialchars($refNum) ?>">
                        <?php endforeach; ?>
                    </datalist>
                </div>
                <div class="form-group">
                    <label for="drawing_rev">ડ્રોઈંગ રિવિઝન:</label>
                    <input type="text" id="drawing_rev" name="drawing_rev" placeholder="દા.ત., A/01">
                </div>
                <div class="form-group">
                    <label for="grade_as_per_drawing">ગ્રેડ (ડ્રોઈંગ મુજબ):</label>
                    <input type="text" id="grade_as_per_drawing" name="grade_as_per_drawing" placeholder="દા.ત., EN8D">
                </div>

                <div class="form-group" style="width: auto;">
                    <button type="submit" class="btn btn-green">પાર્ટ ઉમેરો</button>
                </div>
            </form>
        </div>

        <div class="data-section">
            <h2>હાલના પાર્ટ્સ અને પેરામીટર્સ</h2>
            <div class="search-bar">
                <input type="text" id="search_input" placeholder="પાર્ટ નામ, નંબર, કોડ, ગ્રાહક નામ અથવા ડ્રોઈંગ રિવિઝન દ્વારા શોધો..." value="<?= htmlspecialchars($search_query) ?>">
                <button class="btn btn-primary" onclick="performSearch()">શોધો</button>
            </div>

            <?php if (empty($parts)): ?>
                <p>કોઈ પાર્ટ્સ મળ્યા નથી. નવો પાર્ટ ઉમેરો.</p>
            <?php else: ?>
                <?php foreach ($parts as $part): ?>
                    <div class="part-card" id="part_card_<?= $part['part_id'] ?>">
                        <h3 onclick="toggleParameters(<?= $part['part_id'] ?>)">
                            <?= htmlspecialchars($part['part_number']) ?> (<?= htmlspecialchars($part['part_name']) ?>)
                        </h3>
                        <p><strong>ગ્રાહક:</strong> <?= htmlspecialchars($part['customer_name']) ?></p>
                        <p><strong>પાર્ટ કોડ:</strong> <?= htmlspecialchars($part['part_code'] ?: 'N/A') ?></p>
                        <p><strong>ડ્રોઈંગ રિવિઝન:</strong> <?= htmlspecialchars($part['drawing_rev'] ?: 'N/A') ?></p>
                        <p><strong>ગ્રેડ (ડ્રોઈંગ મુજબ):</strong> <?= htmlspecialchars($part['grade_as_per_drawing'] ?: 'N/A') ?></p> <div class="actions">
                            <button class="btn btn-primary" onclick="showEditPartForm(
                                <?= $part['part_id'] ?>,
                                '<?= htmlspecialchars($part['customer_name']) ?>',
                                '<?= htmlspecialchars($part['part_name']) ?>',
                                '<?= htmlspecialchars($part['part_number']) ?>',
                                '<?= htmlspecialchars($part['part_code'] ?: '') ?>',
                                '<?= htmlspecialchars($part['drawing_rev'] ?: '') ?>',
                                '<?= htmlspecialchars($part['grade_as_per_drawing'] ?: '') ?>' )">એડિટ કરો</button>

                            <form action="master_file.php<?php echo !empty($current_search_query) ? '?search_query=' . $current_search_query : ''; ?>" method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="delete_part">
                                <input type="hidden" name="part_id" value="<?= $part['part_id'] ?>">
                                <button type="submit" class="btn btn-red" onclick="return confirm('શું તમે ખરેખર આ પાર્ટને ડીલીટ કરવા માંગો છો? આ પાર્ટના બધા પેરામીટર્સ પણ ડીલીટ થઈ જશે!');">ડીલીટ કરો</button>
                            </form>
                            <button class="btn btn-secondary" onclick="showAddParameterForm(<?= $part['part_id'] ?>)">પેરામીટર ઉમેરો</button>
                        </div>

                        <div class="edit-form" id="edit_part_form_<?= $part['part_id'] ?>">
                            <h4>પાર્ટ એડિટ કરો</h4>
                            <form action="master_file.php<?php echo !empty($current_search_query) ? '?search_query=' . $current_search_query : ''; ?>" method="POST" class="compact-form-horizontal">
                                <input type="hidden" name="action" value="update_part">
                                <input type="hidden" name="part_id" value="<?= $part['part_id'] ?>">
                                <div class="form-group">
                                    <label for="edit_customer_name_<?= $part['part_id'] ?>">ગ્રાહકનું નામ:</label>
                                    <input type="text" id="edit_customer_name_<?= $part['part_id'] ?>" name="customer_name" list="customer_suggestions" required>
                                </div>
                                <div class="form-group">
                                    <label for="edit_part_name_<?= $part['part_id'] ?>">પાર્ટનું નામ:</label>
                                    <input type="text" id="edit_part_name_<?= $part['part_id'] ?>" name="part_name" required>
                                </div>
                                <div class="form-group">
                                    <label for="edit_part_number_<?= $part['part_id'] ?>">પાર્ટ નંબર:</label>
                                    <input type="text" id="edit_part_number_<?= $part['part_id'] ?>" name="part_number" required>
                                </div>
                                <div class="form-group">
                                    <label for="edit_part_code_<?= $part['part_id'] ?>">પાર્ટ કોડ:</label>
                                    <input type="text" id="edit_part_code_<?= $part['part_id'] ?>" name="part_code" list="ref_number_suggestions">
                                </div>
                                <div class="form-group">
                                    <label for="edit_drawing_rev_<?= $part['part_id'] ?>">ડ્રોઈંગ રિવિઝન:</label>
                                    <input type="text" id="edit_drawing_rev_<?= $part['part_id'] ?>" name="drawing_rev">
                                </div>
                                <div class="form-group">
                                    <label for="edit_grade_as_per_drawing_<?= $part['part_id'] ?>">ગ્રેડ (ડ્રોઈંગ મુજબ):</label>
                                    <input type="text" id="edit_grade_as_per_drawing_<?= $part['part_id'] ?>" name="grade_as_per_drawing"> </div>
                                <div class="form-group" style="width: auto;">
                                    <button type="submit" class="btn btn-primary">અપડેટ કરો</button>
                                    <button type="button" class="btn btn-secondary" onclick="hideEditPartForm(<?= $part['part_id'] ?>)">રદ કરો</button>
                                </div>
                            </form>
                        </div>

                        <div class="edit-form" id="add_param_form_<?= $part['part_id'] ?>">
                            <h4>નવું પેરામીટર ઉમેરો</h4>
                            <form action="master_file.php<?php echo !empty($current_search_query) ? '?search_query=' . $current_search_query : ''; ?>" method="POST" class="compact-form-horizontal">
                                <input type="hidden" name="action" value="add_parameter">
                                <input type="hidden" name="part_id" value="<?= $part['part_id'] ?>">
                                <div class="form-group">
                                    <label for="add_parameter_name_<?= $part['part_id'] ?>">પેરામીટર નામ:</label>
                                    <input type="text" id="add_parameter_name_<?= $part['part_id'] ?>" name="parameter_name" required>
                                </div>
                                <div class="form-group">
                                    <label for="add_setup_info_<?= $part['part_id'] ?>">સેટઅપ માહિતી:</label>
                                    <input type="text" id="add_setup_info_<?= $part['part_id'] ?>" name="setup_info">
                                </div>
                                <div class="form-group">
                                    <label for="add_spec_positive_<?= $part['part_id'] ?>">સ્પેક +ve:</label>
                                    <input type="text" id="add_spec_positive_<?= $part['part_id'] ?>" name="spec_positive">
                                </div>
                                <div class="form-group">
                                    <label for="add_spec_negative_<?= $part['part_id'] ?>">સ્પેક -ve:</label>
                                    <input type="text" id="add_spec_negative_<?= $part['part_id'] ?>" name="spec_negative">
                                </div>
                                <div class="form-group">
                                    <label for="add_specification_<?= $part['part_id'] ?>">વિશિષ્ટતાઓ:</label>
                                    <input type="text" id="add_specification_<?= $part['part_id'] ?>" name="specification">
                                </div>
                                <div class="form-group">
                                    <label for="add_measurement_frequency_<?= $part['part_id'] ?>">માપન આવર્તન:</label>
                                    <input type="text" id="add_measurement_frequency_<?= $part['part_id'] ?>" name="measurement_frequency">
                                </div>
                                <div class="form-group">
                                    <label for="add_measurement_method_<?= $part['part_id'] ?>">માપન પદ્ધતિ:</label>
                                    <input type="text" id="add_measurement_method_<?= $part['part_id'] ?>" name="measurement_method">
                                </div>
                                <div class="form-group">
                                    <label for="add_reaction_plan_<?= $part['part_id'] ?>">પ્રતિક્રિયા યોજના:</label>
                                    <input type="text" id="add_reaction_plan_<?= $part['part_id'] ?>" name="reaction_plan">
                                </div>
                                <div class="form-group">
                                    <label for="add_responsible_person_<?= $part['part_id'] ?>">જવાબદાર વ્યક્તિ:</label>
                                    <input type="text" id="add_responsible_person_<?= $part['part_id'] ?>" name="responsible_person">
                                </div>
                                <div class="form-group">
                                    <label for="add_imte_<?= $part['part_id'] ?>">IMTE:</label> <input type="text" id="add_imte_<?= $part['part_id'] ?>" name="imte" placeholder="દા.ત., કેલિપર"> </div>
                                <div class="form-group" style="width: auto;">
                                    <button type="submit" class="btn btn-green">પેરામીટર ઉમેરો</button>
                                    <button type="button" class="btn btn-secondary" onclick="hideAddParameterForm(<?= $part['part_id'] ?>)">રદ કરો</button>
                                </div>
                            </form>
                        </div>


                        <div class="parameter-list" id="parameter_list_<?= $part['part_id'] ?>">
                            <h4>પાર્ટ પેરામીટર્સ</h4>
                            <?php if (empty($part['parameters'])): ?>
                                <p>આ પાર્ટ માટે કોઈ પેરામીટર્સ ઉમેરાયા નથી.</p>
                            <?php else: ?>
                                <?php
                                $groupedParameters = [];
                                foreach ($part['parameters'] as $param) {
                                    $setupInfoKey = $param['setup_info'] ?: 'સામાન્ય (General)';
                                    if (!isset($groupedParameters[$setupInfoKey])) {
                                        $groupedParameters[$setupInfoKey] = [];
                                    }
                                    $groupedParameters[$setupInfoKey][] = $param;
                                }
                                ?>
                                <div class="setup-group-container">
                                    <?php foreach ($groupedParameters as $setupInfo => $params): ?>
                                        <div class="setup-column">
                                            <h5>સેટઅપ માહિતી: <?= htmlspecialchars($setupInfo) ?></h5>
                                            <?php foreach ($params as $param): ?>
                                                <div class="parameter-item">
                                                    <p><strong>પેરામીટર:</strong> <?= htmlspecialchars($param['parameter_name']) ?></p>
                                                    <p><strong>સ્પેક +ve:</strong> <?= htmlspecialchars($param['spec_positive'] ?: 'N/A') ?></p>
                                                    <p><strong>સ્પેક -ve:</strong> <?= htmlspecialchars($param['spec_negative'] ?: 'N/A') ?></p>
                                                    <p><strong>વિશિષ્ટતાઓ:</strong> <?= htmlspecialchars($param['specification'] ?: 'N/A') ?></p>
                                                    <p><strong>માપન આવર્તન:</strong> <?= htmlspecialchars($param['measurement_frequency'] ?: 'N/A') ?></p>
                                                    <p><strong>માપન પદ્ધતિ:</strong> <?= htmlspecialchars($param['measurement_method'] ?: 'N/A') ?></p>
                                                    <p><strong>પ્રતિક્રિયા યોજના:</strong> <?= htmlspecialchars($param['reaction_plan'] ?: 'N/A') ?></p>
                                                    <p><strong>જવાબદાર વ્યક્તિ:</strong> <?= htmlspecialchars($param['responsible_person'] ?: 'N/A') ?></p>
                                                    <p><strong>IMTE:</strong> <?= htmlspecialchars($param['imte'] ?: 'N/A') ?></p> <div class="param-actions">
                                                        <button class="btn btn-primary btn-sm" onclick="showEditParameterForm(
                                                            <?= $param['id'] ?>,
                                                            <?= $part['part_id'] ?>,
                                                            '<?= htmlspecialchars($param['parameter_name']) ?>',
                                                            '<?= htmlspecialchars($param['setup_info'] ?: '') ?>',
                                                            '<?= htmlspecialchars($param['spec_positive'] ?: '') ?>',
                                                            '<?= htmlspecialchars($param['spec_negative'] ?: '') ?>',
                                                            '<?= htmlspecialchars($param['specification'] ?: '') ?>',
                                                            '<?= htmlspecialchars($param['measurement_frequency'] ?: '') ?>',
                                                            '<?= htmlspecialchars($param['measurement_method'] ?: '') ?>',
                                                            '<?= htmlspecialchars($param['reaction_plan'] ?: '') ?>',
                                                            '<?= htmlspecialchars($param['responsible_person'] ?: '') ?>',
                                                            '<?= htmlspecialchars($param['imte'] ?: '') ?>' )">એડિટ</button> <form action="master_file.php<?php echo !empty($current_search_query) ? '?search_query=' . $current_search_query : ''; ?>" method="POST" style="display:inline;">
                                                            <input type="hidden" name="action" value="delete_parameter">
                                                            <input type="hidden" name="param_id" value="<?= $param['id'] ?>">
                                                            <input type="hidden" name="part_id" value="<?= $part['part_id'] ?>">
                                                            <button type="submit" class="btn btn-red btn-sm" onclick="return confirm('શું તમે ખરેખર આ પેરામીટરને ડીલીટ કરવા માંગો છો?');">ડીલીટ</button>
                                                        </form>
                                                    </div>
                                                </div>

                                                <div class="edit-form" id="edit_form_<?= $param['id'] ?>">
                                                    <h5>પેરામીટર એડિટ કરો</h5>
                                                    <form action="master_file.php<?php echo !empty($current_search_query) ? '?search_query=' . $current_search_query : ''; ?>" method="POST" class="compact-form-horizontal">
                                                        <input type="hidden" name="action" value="update_parameter">
                                                        <input type="hidden" name="param_id" value="<?= $param['id'] ?>">
                                                        <input type="hidden" name="part_id" value="<?= $part['part_id'] ?>">
                                                        <div class="form-group">
                                                            <label for="edit_parameter_name_<?= $param['id'] ?>">પેરામીટર નામ:</label>
                                                            <input type="text" id="edit_parameter_name_<?= $param['id'] ?>" name="parameter_name" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="edit_setup_info_<?= $param['id'] ?>">સેટઅપ માહિતી:</label>
                                                            <input type="text" id="edit_setup_info_<?= $param['id'] ?>" name="setup_info">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="edit_spec_positive_<?= $param['id'] ?>">સ્પેક +ve:</label>
                                                            <input type="text" id="edit_spec_positive_<?= $param['id'] ?>" name="spec_positive">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="edit_spec_negative_<?= $param['id'] ?>">સ્પેક -ve:</label>
                                                            <input type="text" id="edit_spec_negative_<?= $param['id'] ?>" name="spec_negative">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="edit_specification_<?= $param['id'] ?>">વિશિષ્ટતાઓ:</label>
                                                            <input type="text" id="edit_specification_<?= $param['id'] ?>" name="specification">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="edit_measurement_frequency_<?= $param['id'] ?>">માપન આવર્તન:</label>
                                                            <input type="text" id="edit_measurement_frequency_<?= $param['id'] ?>" name="measurement_frequency">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="edit_measurement_method_<?= $param['id'] ?>">માપન પદ્ધતિ:</label>
                                                            <input type="text" id="edit_measurement_method_<?= $param['id'] ?>" name="measurement_method">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="edit_reaction_plan_<?= $param['id'] ?>">પ્રતિક્રિયા યોજના:</label>
                                                            <input type="text" id="edit_reaction_plan_<?= $param['id'] ?>" name="reaction_plan">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="edit_responsible_person_<?= $param['id'] ?>">જવાબદાર વ્યક્તિ:</label>
                                                            <input type="text" id="edit_responsible_person_<?= $param['id'] ?>" name="responsible_person">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="edit_imte_<?= $param['id'] ?>">IMTE:</label> <input type="text" id="edit_imte_<?= $param['id'] ?>" name="imte"> </div>
                                                        <div class="form-group" style="width: auto;">
                                                            <button type="submit" class="btn btn-primary">અપડેટ</button>
                                                            <button type="button" class="btn btn-secondary" onclick="hideEditParameterForm(<?= $param['id'] ?>)">રદ કરો</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // પેરામીટર લિસ્ટને ટૉગલ કરવા માટે
        function toggleParameters(partId) {
            const parameterList = document.getElementById('parameter_list_' + partId);
            if (parameterList) {
                if (parameterList.style.display === 'none' || parameterList.style.display === '') {
                    parameterList.style.display = 'block';
                } else {
                    parameterList.style.display = 'none';
                }
            }
        }

        // પાર્ટ એડિટ ફોર્મ બતાવવા અને ડેટા પ્રી-ફિલ કરવા માટે
        function showEditPartForm(partId, customerName, partName, partNumber, partCode, drawingRev, gradeAsPerDrawing) { // <<<-- અહીં gradeAsPerDrawing ઉમેરો
            const form = document.getElementById('edit_part_form_' + partId);
            if (form) {
                // અન્ય ખુલ્લા એડિટ ફોર્મ છુપાવો
                document.querySelectorAll('.edit-form').forEach(f => {
                    if (f.id !== 'edit_part_form_' + partId) { // વર્તમાન ફોર્મ સિવાય
                        f.style.display = 'none';
                    }
                });

                form.style.display = 'block';
                form.querySelector('[name="customer_name"]').value = customerName;
                form.querySelector('[name="part_name"]').value = partName;
                form.querySelector('[name="part_number"]').value = partNumber;
                form.querySelector('[name="part_code"]').value = partCode;
                form.querySelector('[name="drawing_rev"]').value = drawingRev;
                form.querySelector('[name="grade_as_per_drawing"]').value = gradeAsPerDrawing; // <<<-- નવું ફિલ્ડ સેટ કરો
            }
        }

        // પાર્ટ એડિટ ફોર્મ છુપાવવા માટે
        function hideEditPartForm(partId) {
            const form = document.getElementById('edit_part_form_' + partId);
            if (form) {
                form.style.display = 'none';
            }
        }

        // પેરામીટર એડ ફોર્મ બતાવવા માટે
        function showAddParameterForm(partId) {
            const form = document.getElementById('add_param_form_' + partId);
            if (form) {
                 // અન્ય ખુલ્લા એડિટ ફોર્મ છુપાવો
                document.querySelectorAll('.edit-form').forEach(f => {
                    if (f.id !== 'add_param_form_' + partId) { // વર્તમાન ફોર્મ સિવાય
                        f.style.display = 'none';
                    }
                });
                form.style.display = 'block';
                // Clear fields for new entry
                form.querySelector('[name="parameter_name"]').value = '';
                form.querySelector('[name="setup_info"]').value = '';
                form.querySelector('[name="spec_positive"]').value = '';
                form.querySelector('[name="spec_negative"]').value = '';
                form.querySelector('[name="specification"]').value = '';
                form.querySelector('[name="measurement_frequency"]').value = '';
                form.querySelector('[name="measurement_method"]').value = '';
                form.querySelector('[name="reaction_plan"]').value = '';
                form.querySelector('[name="responsible_person"]').value = '';
                form.querySelector('[name="imte"]').value = ''; //
            }
        }

        // પેરામીટર એડ ફોર્મ છુપાવવા માટે
        function hideAddParameterForm(partId) {
            const form = document.getElementById('add_param_form_' + partId);
            if (form) {
                form.style.display = 'none';
            }
        }


        // પેરામીટર એડિટ ફોર્મ બતાવવા અને ડેટા પ્રી-ફિલ કરવા માટે
        function showEditParameterForm(paramId, partId, parameterName, setupInfo, specPos, specNeg, specification, measurementFrequency, measurementMethod, reactionPlan, responsiblePerson, imte) { //
            const form = document.getElementById('edit_form_' + paramId);
            if (form) {
                 // અન્ય ખુલ્લા એડિટ ફોર્મ છુપાવો
                document.querySelectorAll('.edit-form').forEach(f => {
                    if (f.id !== 'edit_form_' + paramId) { // વર્તમાન ફોર્મ સિવાય
                        f.style.display = 'none';
                    }
                });
                form.style.display = 'block';
                form.querySelector('[name="parameter_name"]').value = parameterName;
                form.querySelector('[name="setup_info"]').value = setupInfo;
                form.querySelector('[name="spec_positive"]').value = specPos;
                form.querySelector('[name="spec_negative"]').value = specNeg;
                form.querySelector('[name="specification"]').value = specification;
                form.querySelector('[name="measurement_frequency"]').value = measurementFrequency;
                form.querySelector('[name="measurement_method"]').value = measurementMethod;
                form.querySelector('[name="reaction_plan"]').value = reactionPlan;
                form.querySelector('[name="responsible_person"]').value = responsiblePerson;
                form.querySelector('[name="imte"]').value = imte; //
            }
        }

        // પેરામીટર એડિટ ફોર્મ છુપાવવા માટે
        function hideEditParameterForm(paramId) {
            const form = document.getElementById('edit_form_' + paramId);
            if (form) {
                form.style.display = 'none';
            }
        }

        // સર્ચ કાર્યક્ષમતા
        function performSearch() {
            const searchQuery = document.getElementById('search_input').value;
            window.location.href = '?search_query=' + encodeURIComponent(searchQuery);
        }

        // Enter કી દબાવવા પર સર્ચ ટ્રિગર કરવા માટે
        document.getElementById('search_input').addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                performSearch();
            }
        });
    </script>
</body>
</html>

<?php
// ડેટાબેઝ કનેક્શન્સ બંધ કરો
$conn->close();
$machine_conn->close();
?>