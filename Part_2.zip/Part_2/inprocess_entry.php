<?php

// --- 1. ડેટાબેઝ ગોઠવણી ---
define('DB_SERVER', 'localhost'); // તમારું ડેટાબેઝ સર્વર
define('DB_USERNAME', 'root'); // તમારું ડેટાબેઝ યુઝરનેમ
define('DB_PASSWORD', ''); // તમારો ડેટાબેઝ પાસવર્ડ
define('DB_NAME', 'dasp'); // આપણે બનાવેલા ડેટાબેઝનું નામ

// ડેટાબેઝ કનેક્શન બનાવો
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// કનેક્શન તપાસો
if ($conn->connect_error) {
    die("કનેક્શન નિષ્ફળ થયું: " . $conn->connect_error);
}

// --- 2. કાર્યક્ષમતાઓ ---

/**
 * બધા પાર્ટ નંબર અને તેમના ID મેળવે છે.
 * @return array પાર્ટ રેકોર્ડ્સનો એરે.
 */
function getAllPartNumbers() {
    global $conn;
    $parts = [];
    $sql = "SELECT id AS part_id, part_number, part_name FROM parts ORDER BY part_number";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $parts[] = $row;
        }
    }
    return $parts;
}

/**
 * આપેલ part_id માટે અનન્ય સેટઅપ માહિતી મેળવે છે.
 * @param int $part_id
 * @return array સેટઅપ માહિતીનો એરે.
 */
function getSetupsByPartId($part_id) {
    global $conn;
    $setups = [];
    $sql = "SELECT DISTINCT setup_info FROM part_parameters WHERE part_id = ? AND setup_info IS NOT NULL AND setup_info != '' ORDER BY setup_info";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (Setups): " . $conn->error);
        return [];
    }
    $stmt->bind_param("i", $part_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $setups[] = $row;
    }
    $stmt->close();
    return $setups;
}

/**
 * આપેલ part_id અને setup_info માટે પેરામીટર્સ મેળવે છે.
 * @param int $part_id
 * @param string $setup_info
 * @return array પેરામીટર્સનો એરે.
 */
function getParametersByPartIdAndSetup($part_id, $setup_info) {
    global $conn;
    $parameters = [];
    $sql = "SELECT id AS parameter_id, parameter_name, specification, spec_positive, spec_negative
            FROM part_parameters
            WHERE part_id = ? AND setup_info = ?
            ORDER BY parameter_name";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (Parameters by Setup): " . $conn->error);
        return [];
    }
    $stmt->bind_param("is", $part_id, $setup_info);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $parameters[] = $row;
    }
    $stmt->close();
    return $parameters;
}

/**
 * ઇન-પ્રોસેસ માપન રેકોર્ડ ઉમેરે છે.
 * @param int $part_id
 * @param int $parameter_id
 * @param float|null $measured_value
 * @param float|null $variance
 * @param string $operator_name
 * @param string|null $batch_number
 * @param string|null $machine_id
 * @param bool $is_conforming
 * @param string|null $nonconformity_details
 * @param string|null $corrective_action_taken
 * @return bool સફળતા પર True, નહીંતર false.
 */
function addInProcessMeasurement($part_id, $parameter_id, $measured_value, $variance, $operator_name, $batch_number, $machine_id, $is_conforming, $nonconformity_details, $corrective_action_taken) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO inprocess_measurements (part_id, parameter_id, measured_value, variance, operator_name, batch_number, machine_id, is_conforming, nonconformity_details, corrective_action_taken) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        error_log("ઇન-પ્રોસેસ માપન પ્રિપેર ભૂલ: " . $conn->error);
        return false;
    }
    $stmt->bind_param("iidssbsiss", $part_id, $parameter_id, $measured_value, $variance, $operator_name, $batch_number, $machine_id, $is_conforming, $nonconformity_details, $corrective_action_taken);
    if ($stmt->execute()) {
        $stmt->close();
        return true;
    } else {
        error_log("ઇન-પ્રોસેસ માપન ઉમેરવામાં ભૂલ: " . $stmt->error);
        $stmt->close();
        return false;
    }
}

/**
 * આપેલ part_id અને setup_info માટે ઇન-પ્રોસેસ માપન ડેટા મેળવે છે.
 * @param int $part_id
 * @param string $setup_info
 * @return array માપનોનો એરે.
 */
function getInProcessMeasurementsForReport($part_id, $setup_info) {
    global $conn;
    $measurements = [];
    $sql = "SELECT ipm.id, ipm.measured_value, ipm.variance, ipm.measurement_date, ipm.operator_name, ipm.batch_number, ipm.machine_id,
                   ipm.is_conforming, ipm.nonconformity_details, ipm.corrective_action_taken,
                   pp.parameter_name, pp.specification, pp.spec_positive, pp.spec_negative, pp.setup_info
            FROM inprocess_measurements AS ipm
            JOIN part_parameters AS pp ON ipm.parameter_id = pp.id
            WHERE ipm.part_id = ? AND pp.setup_info = ?
            ORDER BY ipm.measurement_date DESC";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (In-process Report): " . $conn->error);
        return [];
    }
    $stmt->bind_param("is", $part_id, $setup_info);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $measurements[] = $row;
    }
    $stmt->close();
    return $measurements;
}

// --- 3. ફોર્મ સબમિશન હેન્ડલિંગ અને AJAX વિનંતીઓ ---

// AJAX: Part ID ના આધારે સેટઅપ મેળવો
if (isset($_GET['action']) && $_GET['action'] == 'get_setups_for_part') {
    $part_id = $_GET['part_id'] ?? 0;
    $setups = getSetupsByPartId($part_id);
    header('Content-Type: application/json');
    echo json_encode($setups);
    exit;
}

// AJAX: Part ID અને Setup Info ના આધારે પેરામીટર્સ મેળવો
if (isset($_GET['action']) && $_GET['action'] == 'get_parameters_for_setup') {
    $part_id = $_GET['part_id'] ?? 0;
    $setup_info = $_GET['setup_info'] ?? '';
    $parameters = getParametersByPartIdAndSetup($part_id, $setup_info);
    header('Content-Type: application/json');
    echo json_encode($parameters);
    exit;
}

// AJAX: Part ID અને Setup Info ના આધારે In-process Measurements મેળવો
if (isset($_GET['action']) && $_GET['action'] == 'get_inprocess_report_data') {
    $part_id = $_GET['part_id'] ?? 0;
    $setup_info = $_GET['setup_info'] ?? '';
    $report_data = getInProcessMeasurementsForReport($part_id, $setup_info);
    header('Content-Type: application/json');
    echo json_encode($report_data);
    exit;
}


// માપન ઉમેરવા માટેનું ફોર્મ સબમિશન
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'add_inprocess_measurement') {
    $part_id = $_POST['part_id'] ?? 0;
    $parameter_id = $_POST['parameter_id'] ?? 0;
    $measured_value = isset($_POST['measured_value']) && $_POST['measured_value'] !== '' ? (float)$_POST['measured_value'] : null;
    $operator_name = $_POST['operator_name'] ?? '';
    $batch_number = $_POST['batch_number'] ?? null;
    $machine_id = $_POST['machine_id'] ?? null;
    $setup_info_for_report = $_POST['selected_setup_info'] ?? ''; // રિપોર્ટ અપડેટ કરવા માટે

    $parameters = getParametersByPartIdAndSetup($part_id, $setup_info_for_report); // આમાંથી યોગ્ય પેરામીટર શોધી શકાય
    $spec_positive = null;
    $spec_negative = null;
    $specification_value = null;

    foreach ($parameters as $param) {
        if ($param['parameter_id'] == $parameter_id) {
            $spec_positive = (float)$param['spec_positive'];
            $spec_negative = (float)$param['spec_negative'];
            $specification_value = $param['specification'];
            break;
        }
    }

    $is_conforming = true;
    $nonconformity_details = null;
    $corrective_action_taken = null;
    $variance = null;

    if ($measured_value !== null && $spec_positive !== null && $spec_negative !== null) {
        if ($measured_value > $spec_positive || $measured_value < $spec_negative) {
            $is_conforming = false;
            $nonconformity_details = "માપેલ મૂલ્ય (" . $measured_value . ") સ્પષ્ટીકરણની બહાર છે (+" . $spec_positive . "/-" . $spec_negative . ").";
            $nonconformity_details = $_POST['nonconformity_details'] ?? $nonconformity_details;
            $corrective_action_taken = $_POST['corrective_action_taken'] ?? null;
        }
    }

    // વેરિઅન્સની ગણતરી
    if ($measured_value !== null) {
        if (is_numeric($specification_value)) {
            $variance = abs($measured_value - (float)$specification_value);
        } else if ($spec_positive !== null && $spec_negative !== null) {
            // જો nominal specification ન હોય, તો midpoint થી વેરિઅન્સ ગણો
            $midpoint = ($spec_positive + $spec_negative) / 2;
            $variance = abs($measured_value - $midpoint);
        }
    }


    if ($part_id > 0 && $parameter_id > 0 && !empty($operator_name)) {
        if (addInProcessMeasurement($part_id, $parameter_id, $measured_value, $variance, $operator_name, $batch_number, $machine_id, $is_conforming, $nonconformity_details, $corrective_action_taken)) {
            echo "<p class='info-message success'>ઇન-પ્રોસેસ માપન સફળતાપૂર્વક ઉમેરાયું!</p>";
            if (!$is_conforming) {
                echo "<p class='info-message warning'>ચેતવણી: માપેલ મૂલ્ય સ્પષ્ટીકરણની બહાર છે!</p>";
            }
        } else {
            echo "<p class='info-message error'>ઇન-પ્રોસેસ માપન ઉમેરવામાં નિષ્ફળતા.</p>";
        }
    } else {
        echo "<p class='info-message error'>કૃપા કરીને પાર્ટ, પેરામીટર, અને ઓપરેટરનું નામ દાખલ કરો.</p>";
    }
}


$allPartNumbers = getAllPartNumbers(); // પાર્ટ નંબર ડ્રોપડાઉન માટે

?>

<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IATF ઇન-પ્રોસેસ કંટ્રોલ રિપોર્ટ અને એન્ટ્રી</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
            color: #333;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1, h2 {
            color: #0056b3;
        }
        .section {
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group select,
        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group textarea {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .parameter-row {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
            border: 1px solid #eee;
            padding: 8px;
            border-radius: 4px;
            background-color: #fff;
        }
        .parameter-row > div {
            flex: 1;
            padding: 0 5px;
        }
        .parameter-row .param-label {
            flex: 2;
            font-weight: bold;
        }
        .parameter-row .input-field {
            flex: 1;
        }
        .parameter-row .status-check {
            flex: 0.5;
            text-align: center;
        }
        .parameter-row button {
            background-color: #28a745;
            color: white;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            white-space: nowrap;
        }
        .parameter-row button:hover {
            opacity: 0.9;
        }
        .status-ok {
            color: green;
            font-weight: bold;
        }
        .status-ng {
            color: red;
            font-weight: bold;
        }
        .variance-display {
            font-weight: bold;
            color: #007bff;
        }
        #non_conforming_fields {
            display: none; /* Initially hidden */
            border: 1px dashed #dc3545;
            padding: 10px;
            margin-top: 10px;
            background-color: #ffe0e0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        table th {
            background-color: #0056b3;
            color: white;
        }
        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .conforming {
            color: green;
            font-weight: bold;
        }
        .non-conforming {
            color: red;
            font-weight: bold;
        }
        .info-message {
            margin: 10px 0;
            padding: 8px;
            border-radius: 4px;
        }
        .info-message.success {
            background-color: #d4edda;
            color: #155724;
            border-color: #c3e6cb;
        }
        .info-message.error {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
        .info-message.warning {
            background-color: #fff3cd;
            color: #856404;
            border-color: #ffeeba;
        }
        .current-parameter-info {
            background-color: #e6f7ff;
            border-left: 5px solid #2196F3;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 15px;
        }
        .current-parameter-info p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>IATF ઇન-પ્રોસેસ કંટ્રોલ રિપોર્ટ અને એન્ટ્રી</h1>

        <div class="section selection-area">
            <h2>માહિતી પસંદ કરો</h2>
            <div class="form-group">
                <label for="part_id">પાર્ટ નંબર:</label>
                <select id="part_id" onchange="loadSetups()">
                    <option value="">-- પાર્ટ નંબર પસંદ કરો --</option>
                    <?php
                    foreach ($allPartNumbers as $part) {
                        echo "<option value='" . htmlspecialchars($part['part_id']) . "'>" . htmlspecialchars($part['part_number']) . " - " . htmlspecialchars($part['part_name']) . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="setup_info">સેટઅપ:</label>
                <select id="setup_info" onchange="loadParametersAndReport()">
                    <option value="">-- સેટઅપ પસંદ કરો --</option>
                </select>
            </div>
        </div>

        <div class="section entry-area" id="entry_area" style="display: none;">
            <h2>માપન એન્ટ્રી</h2>
            <div class="form-group">
                <label for="operator_name">ઓપરેટરનું નામ:</label>
                <input type="text" id="operator_name" placeholder="ઓપરેટરનું નામ દાખલ કરો" required>
            </div>
            <div class="form-group">
                <label for="batch_number">બેચ/લોટ નંબર:</label>
                <input type="text" id="batch_number" placeholder="બેચ અથવા લોટ નંબર">
            </div>
            <div class="form-group">
                <label for="machine_id">મશીન ID:</label>
                <input type="text" id="machine_id" placeholder="મશીન ID દાખલ કરો">
            </div>

            <div id="parameters_list">
                <p>ઉપર પાર્ટ નંબર અને સેટઅપ પસંદ કરો.</p>
            </div>
             <div id="status_message" class="info-message" style="display:none;"></div>
        </div>


        <div class="section report-area" id="report_area" style="display: none;">
            <h2>ઇન-પ્રોસેસ માપન રિપોર્ટ</h2>
            <div id="inprocess_report_table">
                <p>ઇન-પ્રોસેસ રિપોર્ટ અહીં પ્રદર્શિત થશે.</p>
            </div>
        </div>
    </div>

    <script>
        let currentParameters = []; // Stores parameters for the currently selected setup
        let selectedPartId = null;
        let selectedSetupInfo = null;

        // Part Number પસંદ કરવા પર Setup લોડ કરવા
        async function loadSetups() {
            selectedPartId = document.getElementById('part_id').value;
            const setupSelect = document.getElementById('setup_info');
            setupSelect.innerHTML = '<option value="">-- સેટઅપ લોડ થઈ રહ્યા છે --</option>';
            document.getElementById('entry_area').style.display = 'none';
            document.getElementById('report_area').style.display = 'none';
            document.getElementById('parameters_list').innerHTML = '<p>ઉપર પાર્ટ નંબર અને સેટઅપ પસંદ કરો.</p>';
            document.getElementById('inprocess_report_table').innerHTML = '<p>ઇન-પ્રોસેસ રિપોર્ટ અહીં પ્રદર્શિત થશે.</p>';

            if (selectedPartId) {
                try {
                    const response = await fetch(`inprocess_report_entry.php?action=get_setups_for_part&part_id=${selectedPartId}`);
                    const setups = await response.json();
                    setupSelect.innerHTML = '<option value="">-- સેટઅપ પસંદ કરો --</option>';
                    if (setups.length > 0) {
                        setups.forEach(setup => {
                            setupSelect.innerHTML += `<option value="${encodeURIComponent(setup.setup_info)}">${htmlspecialchars(setup.setup_info)}</option>`;
                        });
                    } else {
                        setupSelect.innerHTML = '<option value="">-- આ પાર્ટ માટે કોઈ સેટઅપ નથી --</option>';
                    }
                } catch (error) {
                    console.error("સેટઅપ લોડ કરવામાં ભૂલ:", error);
                    setupSelect.innerHTML = '<option value="">-- સેટઅપ લોડ થઈ શક્યા નથી --</option>';
                }
            } else {
                setupSelect.innerHTML = '<option value="">-- સેટઅપ પસંદ કરો --</option>';
            }
        }

        // Setup પસંદ કરવા પર પેરામીટર્સ અને રિપોર્ટ લોડ કરવા
        async function loadParametersAndReport() {
            selectedSetupInfo = decodeURIComponent(document.getElementById('setup_info').value);
            const parametersListDiv = document.getElementById('parameters_list');
            parametersListDiv.innerHTML = '<p>પેરામીટર્સ લોડ થઈ રહ્યા છે...</p>';
            document.getElementById('entry_area').style.display = 'block';
            document.getElementById('report_area').style.display = 'block';
            document.getElementById('status_message').style.display = 'none';

            if (selectedPartId && selectedSetupInfo) {
                try {
                    const response = await fetch(`inprocess_report_entry.php?action=get_parameters_for_setup&part_id=${selectedPartId}&setup_info=${encodeURIComponent(selectedSetupInfo)}`);
                    currentParameters = await response.json();
                    
                    renderParametersForEntry();
                    loadInProcessReport(); // Load report after parameters are loaded
                } catch (error) {
                    console.error("પેરામીટર્સ લોડ કરવામાં ભૂલ:", error);
                    parametersListDiv.innerHTML = '<p>પેરામીટર્સ લોડ થઈ શક્યા નથી.</p>';
                }
            } else {
                parametersListDiv.innerHTML = '<p>ઉપર પાર્ટ નંબર અને સેટઅપ પસંદ કરો.</p>';
                document.getElementById('entry_area').style.display = 'none';
                document.getElementById('report_area').style.display = 'none';
            }
        }

        // પેરામીટર્સને એન્ટ્રી ફોર્મમાં રેન્ડર કરવા
        function renderParametersForEntry() {
            const parametersListDiv = document.getElementById('parameters_list');
            parametersListDiv.innerHTML = ''; // Clear previous content

            if (currentParameters.length === 0) {
                parametersListDiv.innerHTML = '<p>આ સેટઅપ માટે કોઈ પેરામીટર્સ મળ્યા નથી.</p>';
                return;
            }

            currentParameters.forEach(param => {
                const paramRow = document.createElement('div');
                paramRow.className = 'parameter-row';
                paramRow.setAttribute('data-parameter-id', param.parameter_id);
                paramRow.setAttribute('data-spec-positive', param.spec_positive);
                paramRow.setAttribute('data-spec-negative', param.spec_negative);
                paramRow.setAttribute('data-specification', param.specification); // Store specification for variance

                let varianceHtml = '<span class="variance-display">Variance: N/A</span>';
                let statusHtml = '<span class="status-check"></span>'; // Placeholder for OK/NG

                paramRow.innerHTML = `
                    <div class="param-label">${htmlspecialchars(param.parameter_name)}</div>
                    <div><label>સ્પષ્ટીકરણ:</label> ${htmlspecialchars(param.specification || 'N/A')}</div>
                    <div><label>ટોલરન્સ:</label> +${htmlspecialchars(param.spec_positive || 'N/A')} / ${htmlspecialchars(param.spec_negative || 'N/A')}</div>
                    <div class="input-field">
                        <label>માપેલ મૂલ્ય:</label>
                        <input type="number" step="0.001" placeholder="મૂલ્ય"
                               oninput="checkMeasurement('${param.parameter_id}', this.value)"
                               id="measured_value_${param.parameter_id}">
                    </div>
                    <div class="status-check" id="status_${param.parameter_id}"></div>
                    <div class="variance-display" id="variance_${param.parameter_id}"></div>
                    <div><button onclick="addMeasurement(${param.parameter_id})">Add</button></div>
                `;
                parametersListDiv.appendChild(paramRow);
            });
        }

        // માપેલ મૂલ્યની સુસંગતતા તપાસવા અને વેરિઅન્સ ગણવા
        function checkMeasurement(parameterId, measuredValue) {
            const param = currentParameters.find(p => p.parameter_id == parameterId);
            const statusDiv = document.getElementById(`status_${parameterId}`);
            const varianceDiv = document.getElementById(`variance_${parameterId}`);
            statusDiv.className = 'status-check'; // Reset classes
            statusDiv.textContent = '';
            varianceDiv.textContent = 'Variance: N/A';

            if (param && measuredValue !== '') {
                const val = parseFloat(measuredValue);
                const specPositive = parseFloat(param.spec_positive);
                const specNegative = parseFloat(param.spec_negative);
                const specificationValue = parseFloat(param.specification); // Assuming specification is nominal for variance

                let isConforming = true;
                if (specPositive !== null && specNegative !== null && !isNaN(val)) {
                    if (val > specPositive || val < specNegative) {
                        isConforming = false;
                    }
                }

                if (isConforming) {
                    statusDiv.classList.add('status-ok');
                    statusDiv.textContent = 'OK';
                } else {
                    statusDiv.classList.add('status-ng');
                    statusDiv.textContent = 'NG';
                }

                // Calculate Variance
                if (!isNaN(val) && !isNaN(specificationValue)) {
                    const variance = Math.abs(val - specificationValue).toFixed(3);
                    varianceDiv.textContent = `Variance: ${variance}`;
                } else if (!isNaN(val) && !isNaN(specPositive) && !isNaN(specNegative)) {
                    const midpoint = (specPositive + specNegative) / 2;
                    const variance = Math.abs(val - midpoint).toFixed(3);
                    varianceDiv.textContent = `Variance: ${variance} (from midpoint)`;
                }
            }
        }

        // Add બટન ક્લિક કરવા પર માપન ડેટા સેવ કરવા
        async function addMeasurement(parameterId) {
            const partId = selectedPartId;
            const setupInfo = selectedSetupInfo;
            const measuredValueInput = document.getElementById(`measured_value_${parameterId}`);
            const measuredValue = measuredValueInput.value;
            const operatorName = document.getElementById('operator_name').value;
            const batchNumber = document.getElementById('batch_number').value;
            const machineId = document.getElementById('machine_id').value;
            const statusMessageDiv = document.getElementById('status_message');

            if (!operatorName) {
                showMessage("કૃપા કરીને ઓપરેટરનું નામ દાખલ કરો.", "error");
                return;
            }
            if (measuredValue === '') {
                showMessage("કૃપા કરીને માપેલ મૂલ્ય દાખલ કરો.", "error");
                return;
            }

            const param = currentParameters.find(p => p.parameter_id == parameterId);
            if (!param) {
                showMessage("પેરામીટર માહિતી ઉપલબ્ધ નથી.", "error");
                return;
            }

            const val = parseFloat(measuredValue);
            const specPositive = parseFloat(param.spec_positive);
            const specNegative = parseFloat(param.spec_negative);
            const specificationValue = parseFloat(param.specification);

            let isConforming = true;
            let nonconformityDetails = null;
            let variance = null;

             if (specPositive !== null && specNegative !== null && !isNaN(val)) {
                if (val > specPositive || val < specNegative) {
                    isConforming = false;
                    nonconformityDetails = `માપેલ મૂલ્ય (${val}) સ્પષ્ટીકરણની બહાર છે (+${specPositive}/-${specNegative}).`;
                }
            }

            if (!isNaN(val) && !isNaN(specificationValue)) {
                variance = Math.abs(val - specificationValue).toFixed(3);
            } else if (!isNaN(val) && !isNaN(specPositive) && !isNaN(specNegative)) {
                const midpoint = (specPositive + specNegative) / 2;
                variance = Math.abs(val - midpoint).toFixed(3);
            }


            const formData = new FormData();
            formData.append('action', 'add_inprocess_measurement');
            formData.append('part_id', partId);
            formData.append('parameter_id', parameterId);
            formData.append('measured_value', measuredValue);
            formData.append('variance', variance);
            formData.append('operator_name', operatorName);
            formData.append('batch_number', batchNumber);
            formData.append('machine_id', machineId);
            formData.append('is_conforming', isConforming ? 1 : 0);
            formData.append('nonconformity_details', nonconformityDetails || '');
            formData.append('corrective_action_taken', ''); // For this demo, assume no corrective action taken at entry

            formData.append('selected_setup_info', setupInfo);


            try {
                const response = await fetch('inprocess_report_entry.php', {
                    method: 'POST',
                    body: formData
                });
                const resultText = await response.text();
                const parser = new DOMParser();
                const doc = parser.parseFromString(resultText, 'text/html');
                const messageP = doc.querySelector('.info-message'); // Find the message paragraph
                
                if (messageP) {
                    const messageClass = messageP.classList.contains('success') ? 'success' : (messageP.classList.contains('error') ? 'error' : 'warning');
                    showMessage(messageP.textContent, messageClass);
                } else {
                    showMessage("માપન ઉમેરવામાં અજ્ઞાત પ્રતિભાવ મળ્યો.", "error");
                }

                if (response.ok) {
                    measuredValueInput.value = ''; // Clear the input field
                    checkMeasurement(parameterId, ''); // Reset status/variance
                    loadInProcessReport(); // Reload the report table
                }

            } catch (error) {
                console.error("માપન ઉમેરવામાં ભૂલ:", error);
                showMessage("માપન ઉમેરતી વખતે નેટવર્ક અથવા સર્વર ભૂલ.", "error");
            }
        }


        // ઇન-પ્રોસેસ રિપોર્ટ ટેબલ લોડ કરવા
        async function loadInProcessReport() {
            const reportTableDiv = document.getElementById('inprocess_report_table');
            reportTableDiv.innerHTML = '<p>રિપોર્ટ લોડ થઈ રહ્યો છે...</p>';

            if (selectedPartId && selectedSetupInfo) {
                try {
                    const response = await fetch(`inprocess_report_entry.php?action=get_inprocess_report_data&part_id=${selectedPartId}&setup_info=${encodeURIComponent(selectedSetupInfo)}`);
                    const reportData = await response.json();

                    if (reportData.length > 0) {
                        let tableHtml = `
                            <table>
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>તારીખ</th>
                                        <th>ઓપરેટર</th>
                                        <th>બેચ/લોટ નંબર</th>
                                        <th>મશીન ID</th>
                                        <th>પેરામીટર</th>
                                        <th>સ્પષ્ટીકરણ</th>
                                        <th>ટોલરન્સ (+/-)</th>
                                        <th>માપેલ મૂલ્ય</th>
                                        <th>વેરિઅન્સ</th>
                                        <th>સ્થિતિ</th>
                                        <th>નોન-કન્ફોર્મિટી વિગતો</th>
                                        <th>સુધારાત્મક કાર્યવાહી</th>
                                    </tr>
                                </thead>
                                <tbody>
                        `;
                        reportData.forEach(item => {
                            const conformingClass = item.is_conforming ? 'conforming' : 'non-conforming';
                            const conformingText = item.is_conforming ? 'OK' : 'NG';
                            tableHtml += `
                                <tr>
                                    <td>${htmlspecialchars(item.id)}</td>
                                    <td>${new Date(item.measurement_date).toLocaleString()}</td>
                                    <td>${htmlspecialchars(item.operator_name || 'N/A')}</td>
                                    <td>${htmlspecialchars(item.batch_number || 'N/A')}</td>
                                    <td>${htmlspecialchars(item.machine_id || 'N/A')}</td>
                                    <td>${htmlspecialchars(item.parameter_name || 'N/A')}</td>
                                    <td>${htmlspecialchars(item.specification || 'N/A')}</td>
                                    <td>+${htmlspecialchars(item.spec_positive || 'N/A')} / ${htmlspecialchars(item.spec_negative || 'N/A')}</td>
                                    <td>${htmlspecialchars(item.measured_value !== null ? item.measured_value : 'N/A')}</td>
                                    <td>${htmlspecialchars(item.variance !== null ? parseFloat(item.variance).toFixed(3) : 'N/A')}</td>
                                    <td class="${conformingClass}">${conformingText}</td>
                                    <td>${htmlspecialchars(item.nonconformity_details || 'N/A')}</td>
                                    <td>${htmlspecialchars(item.corrective_action_taken || 'N/A')}</td>
                                </tr>
                            `;
                        });
                        tableHtml += `</tbody></table>`;
                        reportTableDiv.innerHTML = tableHtml;
                    } else {
                        reportTableDiv.innerHTML = '<p>આ પાર્ટ અને સેટઅપ માટે કોઈ ઇન-પ્રોસેસ માપન રેકોર્ડ મળ્યા નથી.</p>';
                    }
                } catch (error) {
                    console.error("રિપોર્ટ લોડ કરવામાં ભૂલ:", error);
                    reportTableDiv.innerHTML = '<p>રિપોર્ટ લોડ કરવામાં નિષ્ફળ.</p>';
                }
            } else {
                reportTableDiv.innerHTML = '<p>ઇન-પ્રોસેસ રિપોર્ટ અહીં પ્રદર્શિત થશે.</p>';
            }
        }

        // HTML માં ખાસ અક્ષરોને એસ્કેપ કરવા માટે (સુરક્ષા માટે)
        function htmlspecialchars(str) {
            if (typeof str !== 'string') {
                return str;
            }
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return str.replace(/[&<>"']/g, function(m) { return map[m]; });
        }

        // સ્ટેટસ મેસેજ પ્રદર્શિત કરવા માટે
        function showMessage(message, type) {
            const msgDiv = document.getElementById('status_message');
            msgDiv.textContent = message;
            msgDiv.className = `info-message ${type}`;
            msgDiv.style.display = 'block';
            setTimeout(() => {
                msgDiv.style.display = 'none';
            }, 5000); // Hide after 5 seconds
        }
    </script>
</body>
</html>

<?php
// ડેટાબેઝ કનેક્શન બંધ કરો
$conn->close();
?>