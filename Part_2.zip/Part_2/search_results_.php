<?php
session_start();

// Check karo ke user logged in chhe ke nahi.
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    // Jo logged in nathi, to login page par redirect karo.
    header("location: login.php");
    exit;
}

// Include your database connection file
require_once "config.php"; // Assuming config.php handles database connection

$results = [];
$search_query_parts = [];
$params = [];
$param_types = "";

// Check if a specific search by ref_number is requested
if (isset($_GET['ref_number']) && !empty(trim($_GET['ref_number']))) {
    $ref_number = trim($_GET['ref_number']);
    $search_query_parts[] = "ref_number = ?";
    $params[] = $ref_number;
    $param_types .= "s";
}

// Existing search parameters (make them optional now)
if (isset($_GET['date']) && !empty(trim($_GET['date']))) {
    $date = trim($_GET['date']);
    $search_query_parts[] = "date = ?";
    $params[] = $date;
    $param_types .= "s";
}

if (isset($_GET['shift']) && !empty(trim($_GET['shift']))) {
    $shift = trim($_GET['shift']);
    $search_query_parts[] = "shift = ?";
    $params[] = $shift;
    $param_types .= "s";
}

if (isset($_GET['machine_number']) && !empty(trim($_GET['machine_number']))) {
    $machine_number = trim($_GET['machine_number']);
    $search_query_parts[] = "machine_number = ?";
    $params[] = $machine_number;
    $param_types .= "s";
}

if (isset($_GET['lot_number']) && !empty(trim($_GET['lot_number']))) {
    $lot_number = trim($_GET['lot_number']);
    $search_query_parts[] = "lot_number = ?";
    $params[] = $lot_number;
    $param_types .= "s";
}

if (isset($_GET['operator_name']) && !empty(trim($_GET['operator_name']))) {
    $operator_name = trim($_GET['operator_name']);
    $search_query_parts[] = "operator_name = ?";
    $params[] = $operator_name;
    $param_types .= "s";
}

if (isset($_GET['setter']) && !empty(trim($_GET['setter']))) {
    $setter = trim($_GET['setter']);
    $search_query_parts[] = "setter_name = ?"; // Assuming column name is setter_name
    $params[] = $setter;
    $param_types .= "s";
}


if (!empty($search_query_parts)) {
    $sql = "SELECT * FROM notes WHERE " . implode(" AND ", $search_query_parts);

    if ($stmt = $mysqli->prepare($sql)) {
        // Dynamically bind parameters
        call_user_func_array([$stmt, 'bind_param'], array_merge([$param_types], refValues($params)));

        if ($stmt->execute()) {
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $results[] = $row;
            }
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
} else {
    echo "Please provide at least one search criterion.";
}

// Helper function for bind_param
function refValues($arr){
    if (strnatcmp(phpversion(),'5.3') >= 0) //Reference is required for PHP 5.3+
    {
        $refs = array();
        foreach($arr as $key => $value)
            $refs[$key] = &$arr[$key];
        return $refs;
    }
    return $arr;
}

$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Results</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        /* Add your Facebook Theme CSS here, similar to note_search.php */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            margin: 20px auto;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            max-width: 1280px;
        }
        h2 {
            text-align: center;
            color: #1877f2;
            margin-bottom: 25px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #1877f2;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .no-results {
            text-align: center;
            color: #555;
            margin-top: 20px;
        }
        .back-button {
            display: block;
            width: fit-content;
            margin: 20px auto;
            background-color: #28a745;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: background-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
<div class="container">
    <a href="note_search.php" class="back-button">BACK TO SEARCH</a>
    <h2>Search Results</h2>
    <?php if (!empty($results)): ?>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Shift</th>
                    <th>Machine Number</th>
                    <th>Part Code</th>
                    <th>Lot Number</th>
                    <th>Operator</th>
                    <th>Setter</th>
                    </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['date']); ?></td>
                        <td><?php echo htmlspecialchars($row['shift']); ?></td>
                        <td><?php echo htmlspecialchars($row['machine_number']); ?></td>
                        <td><?php echo htmlspecialchars($row['ref_number']); ?></td>
                        <td><?php echo htmlspecialchars($row['lot_number']); ?></td>
                        <td><?php echo htmlspecialchars($row['operator_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['setter_name']); ?></td>
                        </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="no-results">No notes found for the given criteria.</p>
    <?php endif; ?>
</div>
</body>
</html>