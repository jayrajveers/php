let currentParameters = []; // હાલમાં પસંદ કરેલ સેટઅપ માટેના પેરામીટર્સ સંગ્રહિત કરે છે
let selectedPartId = null;
let selectedSetupInfo = null;

// Part Number પસંદ કરવા પર Setup લોડ કરવા
async function loadSetups() {
    selectedPartId = document.getElementById('part_id').value;
    const setupSelect = document.getElementById('setup_info');
    setupSelect.innerHTML = '<option value="">-- સેટઅપ લોડ થઈ રહ્યા છે --</option>';
    document.getElementById('entry_area').style.display = 'none';
    document.getElementById('report_area').style.display = 'none';
    document.getElementById('parameters_list').innerHTML = '<p>ઉપર પાર્ટ નંબર અને સેટઅપ પસંદ કરો.</p>';
    document.getElementById('inprocess_report_table').innerHTML = '<p>ઇન-પ્રોસેસ રિપોર્ટ અહીં પ્રદર્શિત થશે.</p>';
    document.getElementById('status_message').style.display = 'none'; // કોઈપણ અગાઉના મેસેજને સાફ કરો

    if (selectedPartId) {
        try {
            const response = await fetch(`inprocess_report_entry.php?action=get_setups_for_part&part_id=${selectedPartId}`);
            const setups = await response.json();
            setupSelect.innerHTML = '<option value="">-- સેટઅપ પસંદ કરો --</option>';
            if (setups.length > 0) {
                setups.forEach(setup => {
                    setupSelect.innerHTML += `<option value="${encodeURIComponent(setup.setup_info)}">${htmlspecialchars(setup.setup_info)}</option>`;
                });
            } else {
                setupSelect.innerHTML = '<option value="">-- આ પાર્ટ માટે કોઈ સેટઅપ નથી --</option>';
            }
        } catch (error) {
            console.error("સેટઅપ લોડ કરવામાં ભૂલ:", error);
            setupSelect.innerHTML = '<option value="">-- સેટઅપ લોડ થઈ શક્યા નથી --</option>';
        }
    } else {
        setupSelect.innerHTML = '<option value="">-- સેટઅપ પસંદ કરો --</option>';
    }
}

// Setup પસંદ કરવા પર પેરામીટર્સ અને રિપોર્ટ લોડ કરવા
async function loadParametersAndReport() {
    selectedSetupInfo = decodeURIComponent(document.getElementById('setup_info').value);
    const parametersListDiv = document.getElementById('parameters_list');
    parametersListDiv.innerHTML = '<p>પેરામીટર્સ લોડ થઈ રહ્યા છે...</p>';
    document.getElementById('entry_area').style.display = 'block';
    document.getElementById('report_area').style.display = 'block';
    document.getElementById('status_message').style.display = 'none';

    if (selectedPartId && selectedSetupInfo) {
        try {
            const response = await fetch(`inprocess_report_entry.php?action=get_parameters_for_setup&part_id=${selectedPartId}&setup_info=${encodeURIComponent(selectedSetupInfo)}`);
            currentParameters = await response.json();

            renderParametersForEntry();
            loadInProcessReport(); // Parameters લોડ થયા પછી રિપોર્ટ લોડ કરો
        } catch (error) {
            console.error("પેરામીટર્સ લોડ કરવામાં ભૂલ:", error);
            parametersListDiv.innerHTML = '<p>પેરામીટર્સ લોડ થઈ શક્યા નથી.</p>';
        }
    } else {
        parametersListDiv.innerHTML = '<p>ઉપર પાર્ટ નંબર અને સેટઅપ પસંદ કરો.</p>';
        document.getElementById('entry_area').style.display = 'none';
        document.getElementById('report_area').style.display = 'none';
    }
}

// પેરામીટર્સને એન્ટ્રી ફોર્મમાં રેન્ડર કરવા
function renderParametersForEntry() {
    const parametersListDiv = document.getElementById('parameters_list');
    parametersListDiv.innerHTML = ''; // અગાઉની સામગ્રી સાફ કરો

    if (currentParameters.length === 0) {
        parametersListDiv.innerHTML = '<p>આ સેટઅપ માટે કોઈ પેરામીટર્સ મળ્યા નથી.</p>';
        return;
    }

    currentParameters.forEach(param => {
        const paramRow = document.createElement('div');
        paramRow.className = 'parameter-row';
        paramRow.setAttribute('data-parameter-id', param.parameter_id);
        // નલ (null) મૂલ્યો માટે ડેટા એટ્રિબ્યુટ્સ માટે ડિફોલ્ટ ખાલી સ્ટ્રિંગ સુનિશ્ચિત કરો
        paramRow.setAttribute('data-spec-positive', param.spec_positive !== null ? param.spec_positive : '');
        paramRow.setAttribute('data-spec-negative', param.spec_negative !== null ? param.spec_negative : '');
        paramRow.setAttribute('data-specification', param.specification !== null ? param.specification : '');

        const specDisplay = htmlspecialchars(param.specification || 'N/A');
        let toleranceDisplay = '';

        if (param.spec_positive !== null && param.spec_negative !== null) {
            toleranceDisplay = `+${htmlspecialchars(param.spec_positive)} / -${htmlspecialchars(param.spec_negative)}`; // બંને હકારાત્મક અને નકારાત્મક સંપૂર્ણ મૂલ્ય દર્શાવો
        } else if (param.spec_positive !== null) {
            toleranceDisplay = `+${htmlspecialchars(param.spec_positive)}`;
        } else if (param.spec_negative !== null) {
            toleranceDisplay = `-${htmlspecialchars(param.spec_negative)}`; // નકારાત્મક સંપૂર્ણ મૂલ્ય દર્શાવો
        } else {
            toleranceDisplay = 'N/A';
        }


        paramRow.innerHTML = `
            <div class="param-label">${htmlspecialchars(param.parameter_name)}</div>
            <div><label>સ્પષ્ટીકરણ:</label> ${specDisplay}</div>
            <div><label>ટોલરન્સ:</label> ${toleranceDisplay}</div>
            <div class="input-field">
                <label>+:</label>
                <input type="number" step="0.001" placeholder="0.000"
                        oninput="checkMeasurement(${param.parameter_id})"
                        id="measured_value_pos_${param.parameter_id}"
                        name="measured_deviations[${param.parameter_id}][positive]">
                <label>-:</label>
                <input type="number" step="0.001" placeholder="0.000"
                        oninput="checkMeasurement(${param.parameter_id})"
                        id="measured_value_neg_${param.parameter_id}"
                        name="measured_deviations[${param.parameter_id}][negative]">
            </div>
            <div class="status-check" id="status_${param.parameter_id}"></div>
            <div class="variance-display" id="variance_${param.parameter_id}"></div>
            <div><button onclick="addSingleMeasurement(${param.parameter_id})">Add</button></div>
        `;
        parametersListDiv.appendChild(paramRow);
    });
}

// માપેલ મૂલ્યની સુસંગતતા તપાસવા અને વેરિઅન્સ ગણવા (Client-side logic)
function checkMeasurement(parameterId) {
    const statusDiv = document.getElementById(`status_${parameterId}`);
    const varianceDiv = document.getElementById(`variance_${parameterId}`);
    const positiveInput = document.getElementById(`measured_value_pos_${parameterId}`);
    const negativeInput = document.getElementById(`measured_value_neg_${parameterId}`);

    if (!statusDiv || !varianceDiv || !positiveInput || !negativeInput) {
        console.error(`Error: Required elements for parameterId ${parameterId} not found.`);
        return;
    }

    // શરૂઆતમાં હંમેશા સ્ટેટસ અને વેરિઅન્સ સાફ કરો
    statusDiv.className = '';
    statusDiv.textContent = '';
    varianceDiv.textContent = 'વેરિઅન્સ: N/A';

    const param = currentParameters.find(p => p.parameter_id == parameterId);

    if (!param) {
        return;
    }

    const measuredValuePosStr = positiveInput.value;
    const measuredValueNegStr = negativeInput.value;

    const positiveDeviationInput = (measuredValuePosStr !== '') ? parseFloat(measuredValuePosStr) : null;
    const negativeDeviationInput = (measuredValueNegStr !== '') ? parseFloat(measuredValueNegStr) : null;

    // --- તબક્કો 1: કોઈ ઇનપુટ ન હોય ત્યારે સંભાળો ---
    if (positiveDeviationInput === null && negativeDeviationInput === null) {
        statusDiv.classList.add('status-ok');
        statusDiv.textContent = 'OK';
        return; // કોઈ ઇનપુટ નથી, તેથી ડિફોલ્ટ રૂપે OK. બહાર નીકળો.
    }

    // --- તબક્કો 2: ઇનપુટ માન્યતા (NaN તપાસો) ---
    if ((positiveDeviationInput !== null && isNaN(positiveDeviationInput)) ||
        (negativeDeviationInput !== null && isNaN(negativeDeviationInput))) {
        statusDiv.classList.add('status-ng');
        statusDiv.textContent = 'અમાન્ય ઇનપુટ';
        return; // અમાન્ય ઇનપુટ, NG સેટ કરો અને બહાર નીકળો.
    }

    // --- તબક્કો 3: વાસ્તવિક માપેલ મૂલ્ય અને વેરિઅન્સની ગણતરી કરો ---
    let actualMeasuredValue = null; // Calculated based on spec and deviation input
    let calculatedVariance = null; // Calculated based on deviation inputs

    // Measured Value Calculation (as per dial gauge: Specification +/- Deviation)
    const specificationValue = (param.specification !== null && !isNaN(parseFloat(param.specification))) ? parseFloat(param.specification) : null;

    if (specificationValue !== null) {
        // Preference: If negative deviation is given and non-zero, calculate from it.
        // Else, if positive deviation is given and non-zero, calculate from it.
        // If both are zero, measured_value is spec.
        if (negativeDeviationInput !== null && negativeDeviationInput !== 0.0) {
            actualMeasuredValue = specificationValue - negativeDeviationInput;
        } else if (positiveDeviationInput !== null && positiveDeviationInput !== 0.0) {
            actualMeasuredValue = specificationValue + positiveDeviationInput;
        } else if (positiveDeviationInput === 0.0 && negativeDeviationInput === 0.0) {
            actualMeasuredValue = specificationValue; // Both zero, measured is spec
        } else {
            actualMeasuredValue = null; // Cannot determine single measured_value
        }
    } else {
        // If no specification, measured value is simply the deviation itself
        if (positiveDeviationInput !== null && negativeDeviationInput === null) {
            actualMeasuredValue = positiveDeviationInput;
        } else if (negativeDeviationInput !== null && positiveDeviationInput === null) {
            actualMeasuredValue = negativeDeviationInput;
        } else {
             actualMeasuredValue = null; // Cannot determine a single measured_value without spec
        }
    }

    if (actualMeasuredValue !== null) {
        actualMeasuredValue = parseFloat(actualMeasuredValue.toFixed(3)); // Round to 3 decimal places
    }

    // Variance Calculation (As per image_169d2f.png: abs(Positive_Input - Negative_Input) or abs(single_input))
    if (positiveDeviationInput !== null && negativeDeviationInput !== null) {
        calculatedVariance = Math.abs(positiveDeviationInput - negativeDeviationInput);
    } else if (positiveDeviationInput !== null) {
        calculatedVariance = Math.abs(positiveDeviationInput);
    } else if (negativeDeviationInput !== null) {
        calculatedVariance = Math.abs(negativeDeviationInput);
    } else {
        calculatedVariance = null;
    }
    
    if (calculatedVariance !== null) {
        varianceDiv.textContent = `વેરિઅન્સ: ${calculatedVariance.toFixed(3)}`;
    } else {
        varianceDiv.textContent = 'વેરિઅન્સ: N/A';
    }

    // જો ગણતરી કરેલ actualMeasuredValue NaN હોય, તો તે સ્પષ્ટીકરણ અથવા ગણતરીમાં સમસ્યા છે.
    if (isNaN(actualMeasuredValue) && (positiveDeviationInput !== null || negativeDeviationInput !== null) && specificationValue !== null) {
        statusDiv.classList.add('status-ng');
        statusDiv.textContent = 'અમાન્ય ગણતરી';
        return; // અમાન્ય ગણતરી, NG સેટ કરો અને બહાર નીકળો.
    }


    // --- તબક્કો 4: સુસંગતતા તપાસ (OK/NG લોજિક) ---
    const rawSpecPositive = (param.spec_positive !== null && param.spec_positive !== '') ? parseFloat(param.spec_positive) : null;
    const rawSpecNegative = (param.spec_negative !== null && param.spec_negative !== '') ? parseFloat(param.spec_negative) : null;

    let isConforming = true;
    let nonConformityReason = [];

    // Check positive deviation input against positive tolerance
    if (positiveDeviationInput !== null) {
        if (rawSpecPositive === null || isNaN(rawSpecPositive) || Math.abs(positiveDeviationInput) > rawSpecPositive) {
            isConforming = false;
            nonConformityReason.push("પોઝિટિવ વિચલન ટોલરન્સ કરતા વધારે છે");
        }
    }

    // Check negative deviation input against negative tolerance
    if (negativeDeviationInput !== null) {
        if (rawSpecNegative === null || isNaN(rawSpecNegative) || Math.abs(negativeDeviationInput) > rawSpecNegative) {
            isConforming = false;
            nonConformityReason.push("નેગેટિવ વિચલન ટોલરન્સ કરતા વધારે છે");
        }
    }
    
    // Case where inputs are present but no valid specification or tolerance defined
    if ((positiveDeviationInput !== null || negativeDeviationInput !== null) && 
        (specificationValue === null || isNaN(specificationValue) || 
        ((rawSpecPositive === null || isNaN(rawSpecPositive)) && (rawSpecNegative === null || isNaN(rawSpecNegative))))) {
        // If there are inputs but no valid spec or tolerance to check against, it's NG
        isConforming = false;
        if (nonConformityReason.length === 0) { // Add this reason only if no other reason was found
            nonConformityReason.push("કોઈ સ્પષ્ટીકરણ/ટોલરન્સ નથી");
        }
    }

    // --- તબક્કો 5: અંતિમ સ્થિતિ અપડેટ ---
    if (isConforming) {
        statusDiv.classList.add('status-ok');
        statusDiv.textContent = 'OK';
    } else {
        statusDiv.classList.add('status-ng');
        statusDiv.textContent = 'NG';
        // The nonConformityReason is primarily for internal logic/DB storage,
        // UI only shows NG/OK.
    }
}

// Single measurement add
async function addSingleMeasurement(parameterId) {
    const partId = selectedPartId;
    const setupInfo = selectedSetupInfo;
    const positiveInput = document.getElementById(`measured_value_pos_${parameterId}`);
    const negativeInput = document.getElementById(`measured_value_neg_${parameterId}`);
    const measuredValuePosStr = positiveInput.value;
    const measuredValueNegStr = negativeInput.value;
    const operatorName = document.getElementById('operator_name').value;
    const batchNumber = document.getElementById('batch_number').value;
    const heatNumber = document.getElementById('heat_number').value; 
    const lotQty = document.getElementById('lot_qty').value; // Retrieve Lot Qty
    const machineId = document.getElementById('machine_id').value;
    const inspectorName = document.getElementById('inspector_name').value; // New field
    const shift = document.getElementById('shift').value; // New field

    if (!operatorName) {
        showMessage("કૃપા કરીને ઓપરેટરનું નામ દાખલ કરો.", "error");
        return;
    }
    if (!inspectorName) { // New validation
        showMessage("કૃપા કરીને ઇન્સ્પેક્ટરનું નામ દાખલ કરો.", "error");
        return;
    }
    if (measuredValuePosStr === '' && measuredValueNegStr === '') {
        showMessage("કૃપા કરીને માપેલ મૂલ્ય (પોઝિટિવ અથવા નેગેટીવ) દાખલ કરો.", "error");
        return;
    }

    const formData = new FormData();
    formData.append('action', 'add_inprocess_measurement_single');
    formData.append('part_id', partId);
    formData.append('parameter_id', parameterId);
    formData.append('measured_value_positive_deviation', measuredValuePosStr);
    formData.append('measured_value_negative_deviation', measuredValueNegStr);
    formData.append('operator_name', operatorName);
    formData.append('batch_number', batchNumber);
    formData.append('heat_number', heatNumber);
    formData.append('lot_qty', lotQty); // Add this line
    formData.append('machine_id', machineId);
    formData.append('selected_setup_info', setupInfo);
    formData.append('inspector_name', inspectorName); // New field
    formData.append('shift', shift); // New field

    try {
        const response = await fetch('inprocess_report_entry.php', {
            method: 'POST',
            body: formData
        });
        const resultText = await response.text();
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = resultText;
        const messageP = tempDiv.querySelector('.info-message');

        if (messageP) {
            const messageClass = messageP.classList.contains('success') ? 'success' : (messageP.classList.contains('error') ? 'error' : 'warning');
            showMessage(messageP.textContent, messageClass);
        } else {
            showMessage("માપન ઉમેરવામાં અજ્ઞાત પ્રતિભાવ મળ્યો.", "error");
        }

        if (response.ok) {
            positiveInput.value = '';
            negativeInput.value = '';
            checkMeasurement(parameterId); // Recalculate status for the cleared inputs
            loadInProcessReport();
        }

    } catch (error) {
        console.error("માપન ઉમેરવામાં ભૂલ:", error);
        showMessage("માપન ઉમેરતી વખતે નેટવર્ક અથવા સર્વર ભૂલ.", "error");
    }
}

// Add All Measurements
async function addAllMeasurements() {
    const partId = selectedPartId;
    const setupInfo = selectedSetupInfo;
    const operatorName = document.getElementById('operator_name').value;
    const batchNumber = document.getElementById('batch_number').value;
    const heatNumber = document.getElementById('heat_number').value;
    const lotQty = document.getElementById('lot_qty').value; // Retrieve Lot Qty
    const machineId = document.getElementById('machine_id').value;
    const inspectorName = document.getElementById('inspector_name').value; // New field
    const shift = document.getElementById('shift').value; // New field
    const statusMessageDiv = document.getElementById('status_message');

    if (!operatorName) {
        showMessage("કૃપા કરીને ઓપરેટરનું નામ દાખલ કરો.", "error");
        return;
    }
    if (!inspectorName) { // New validation
        showMessage("કૃપા કરીને ઇન્સ્પેક્ટરનું નામ દાખલ કરો.", "error");
        return;
    }

    const measuredDeviations = {};
    let hasAtLeastOneValue = false;
    document.querySelectorAll('#parameters_list input[type="number"]').forEach(input => {
        const paramId = input.id.split('_')[input.id.split('_').length - 1];
        const type = input.id.includes('_pos_') ? 'positive' : 'negative';

        if (!measuredDeviations[paramId]) {
            measuredDeviations[paramId] = {positive: '', negative: ''};
        }
        if (input.value !== '') {
            measuredDeviations[paramId][type] = input.value;
            hasAtLeastOneValue = true;
        }
    });

    if (!hasAtLeastOneValue) {
        showMessage("કૃપા કરીને ઓછામાં ઓછું એક માપેલ મૂલ્ય (પોઝિટિવ અથવા નેગેટીવ) દાખલ કરો.", "error");
        return;
    }

    const formData = new FormData();
    formData.append('action', 'add_inprocess_measurements_all');
    formData.append('part_id', partId);
    formData.append('operator_name', operatorName);
    formData.append('batch_number', batchNumber);
    formData.append('heat_number', heatNumber);
    formData.append('lot_qty', lotQty); // Add this line
    formData.append('machine_id', machineId);
    formData.append('selected_setup_info', setupInfo);
    formData.append('inspector_name', inspectorName); // New field
    formData.append('shift', shift); // New field

    for (const paramId in measuredDeviations) {
        formData.append(`measured_deviations[${paramId}][positive]`, measuredDeviations[paramId]['positive']);
        formData.append(`measured_deviations[${paramId}][negative]`, measuredDeviations[paramId]['negative']);
    }

    try {
        const response = await fetch('inprocess_report_entry.php', {
            method: 'POST',
            body: formData
        });
        const resultText = await response.text();
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = resultText;
        const messages = tempDiv.querySelectorAll('.info-message');

        statusMessageDiv.innerHTML = '';
        messages.forEach(messageP => {
            const messageClass = messageP.classList.contains('success') ? 'success' : (messageP.classList.contains('error') ? 'error' : 'warning');
            showMessage(messageP.textContent, messageClass);
        });

        if (response.ok) {
            document.querySelectorAll('#parameters_list input[type="number"]').forEach(input => {
                input.value = '';
                const paramId = input.id.split('_')[input.id.split('_').length - 1];
                checkMeasurement(paramId); // Recalculate status for the cleared inputs
            });
            loadInProcessReport();
        }

    } catch (error) {
        console.error("બધા માપન ઉમેરવામાં ભૂલ:", error);
        showMessage("બધા માપન ઉમેરતી વખતે નેટવર્ક અથવા સર્વર ભૂલ.", "error");
    }
}


// ઇન-પ્રોસેસ રિપોર્ટ ટેબલ લોડ કરવા
async function loadInProcessReport() {
    const reportTableDiv = document.getElementById('inprocess_report_table');
    reportTableDiv.innerHTML = '<p>રિપોર્ટ લોડ થઈ રહ્યો છે...</p>';

    if (selectedPartId && selectedSetupInfo) {
        try {
            const response = await fetch(`inprocess_report_entry.php?action=get_inprocess_report_data&part_id=${selectedPartId}&setup_info=${encodeURIComponent(selectedSetupInfo)}`);
            const reportData = await response.json();

            if (reportData.length > 0) {
                let tableHtml = `
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>તારીખ</th>
                                <th>ઓપરેટર</th>
                                <th>ઇન્સ્પેક્ટર</th>
                                <th>શિફ્ટ</th>
                                <th>બેચ/લોટ નંબર</th>
                                <th>હીટ નંબર</th>
                                <th>લોટ Qty</th> <th>મશીન ID</th>
                                <th>પેરામીટર</th>
                                <th>સ્પષ્ટીકરણ</th>
                                <th>ટોલરન્સ (+/-)</th>
                                <th>માપેલ મૂલ્ય</th>
                                <th>+ ઇનપુટ</th>
                                <th>- ઇનપુટ</th>
                                <th>વેરિઅન્સ</th>
                                <th>સ્થિતિ</th>
                                <th>નોન-કન્ફોર્મિટી વિગતો</th>
                            </tr>
                        </thead>
                        <tbody>
                `;
                reportData.forEach(item => {
                    const conformingClass = item.is_conforming ? 'conforming' : 'non-conforming';
                    const conformingText = item.is_conforming ? 'OK' : 'NG'; // અહીં પણ NG પ્રદર્શિત થશે

                    let toleranceDisplay = '';
                    if (item.spec_positive !== null && item.spec_negative !== null) {
                        toleranceDisplay = `+${htmlspecialchars(item.spec_positive)} / -${htmlspecialchars(item.spec_negative)}`;
                    } else if (item.spec_positive !== null) {
                        toleranceDisplay = `+${htmlspecialchars(item.spec_positive)}`;
                    } else if (item.spec_negative !== null) {
                        toleranceDisplay = `-${htmlspecialchars(item.spec_negative)}`;
                    } else {
                        toleranceDisplay = 'N/A';
                    }

                    tableHtml += `
                        <tr>
                            <td>${htmlspecialchars(item.id)}</td>
                            <td>${new Date(item.measurement_date).toLocaleString()}</td>
                            <td>${htmlspecialchars(item.operator_name || 'N/A')}</td>
                            <td>${htmlspecialchars(item.inspector_name || 'N/A')}</td>
                            <td>${htmlspecialchars(item.shift || 'N/A')}</td>
                            <td>${htmlspecialchars(item.batch_number || 'N/A')}</td>
                            <td>${htmlspecialchars(item.heat_number || 'N/A')}</td>
                            <td>${htmlspecialchars(item.lot_qty !== null ? item.lot_qty : 'N/A')}</td> <td>${htmlspecialchars(item.machine_id || 'N/A')}</td>
                            <td>${htmlspecialchars(item.parameter_name || 'N/A')}</td>
                            <td>${htmlspecialchars(item.specification || 'N/A')}</td>
                            <td>${toleranceDisplay}</td>
                            <td>${htmlspecialchars(item.measured_value !== null ? item.measured_value : 'N/A')}</td>
                            <td>${htmlspecialchars(item.positive_deviation_input !== null ? item.positive_deviation_input : 'N/A')}</td>
                            <td>${htmlspecialchars(item.negative_deviation_input !== null ? item.negative_deviation_input : 'N/A')}</td>
                            <td>${htmlspecialchars(item.variance !== null ? parseFloat(item.variance).toFixed(3) : 'N/A')}</td>
                            <td class="${conformingClass}">${conformingText}</td>
                            <td>${htmlspecialchars(item.nonconformity_details || 'N/A')}</td>
                        </tr>
                    `;
                });
                tableHtml += `</tbody></table>`;
                reportTableDiv.innerHTML = tableHtml;
            } else {
                reportTableDiv.innerHTML = '<p>આ પાર્ટ અને સેટઅપ માટે કોઈ ઇન-પ્રોસેસ માપન રેકોર્ડ મળ્યા નથી.</p>';
            }
        } catch (error) {
            console.error("રિપોર્ટ લોડ કરવામાં ભૂલ:", error);
            reportTableDiv.innerHTML = '<p>રિપોર્ટ લોડ કરવામાં નિષ્ફળ.</p>';
        }
    } else {
        reportTableDiv.innerHTML = '<p>ઇન-પ્રોસેસ રિપોર્ટ અહીં પ્રદર્શિત થશે.</p>';
    }
}

// HTML માં ખાસ અક્ષરોને એસ્કેપ કરવા માટે (સુરક્ષા માટે)
function htmlspecialchars(str) {
    if (typeof str !== 'string') {
        return str;
    }
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return str.replace(/[&<>"']/g, function(m) { return map[m]; });
}

// સ્ટેટસ મેસેજ પ્રદર્શિત કરવા માટે
function showMessage(message, type) {
    const msgDiv = document.getElementById('status_message');
    msgDiv.textContent = message;
    msgDiv.className = `info-message ${type}`;
    msgDiv.style.display = 'block';
    setTimeout(() => {
        msgDiv.style.display = 'none';
    }, 5000); // 5 સેકન્ડ પછી છુપાવો
}