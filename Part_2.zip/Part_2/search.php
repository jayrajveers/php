<?php
    session_start();

    // Check karo ke user logged in chhe ke nahi.
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        // Jo logged in nathi, to login page par redirect karo.
        header("location: login.php");
        exit;
    }
?>
		<!DOCTYPE html>
		<html lang="en">
		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<title>Production Records</title>
		  <style>
			body {
				font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
				margin: 20px;
				background-color: #f0f2f5; /* Facebook light grey background */
				color: #1c1e21; /* Facebook dark grey text */
			}

			/* Stylish Add Button */
			.add-button-container {
				margin: 20px 0;
				text-align: center;
			}
			.add-button {
				background-color: #1877F2; /* Facebook blue */
				color: white;
				padding: 12px 25px;
				text-decoration: none;
				border-radius: 6px;
				font-weight: bold;
				font-size: 16px;
				box-shadow: 0 2px 4px rgba(0,0,0,0.1);
				transition: background-color 0.3s ease;
				border: none;
			}
			.add-button:hover {
				background-color: #166fe6;
			}

			/* Search Form */
			.filter-form-container {
				text-align: center;
				margin-top: 20px;
				margin-bottom: 20px;
				background-color: white; /* White background for the form */
				padding: 20px;
				border-radius: 8px;
				box-shadow: 0 2px 4px rgba(0,0,0,0.1);
			}
			.filter-input-group {
				display: flex;
				flex-wrap: wrap;
				justify-content: center;
				gap: 10px;
				margin-bottom: 10px;
			}
			.filter-label {
				font-size: 14px;
				font-weight: bold;
				color: #65676b; /* Facebook grey label text */
			}
			.filter-input {
				padding: 8px;
				font-size: 16px;
				border: 1px solid #ccd0d5; /* Light grey border */
				border-radius: 4px;
				flex-grow: 1; /* Allow inputs to take available space */
				min-width: 150px; /* Minimum width for each input */
			}
			.filter-button-group {
				display: flex;
				justify-content: center;
				gap: 10px;
				margin-top: 15px;
				width: 100%; /* Ensure buttons are on a new line if needed */
			}
			.filter-button, .reset-button, #exportVisibleButton {
				background-color: #1877F2; /* Facebook blue */
				color: white;
				padding: 10px 20px;
				border: none;
				border-radius: 6px;
				font-weight: bold;
				font-size: 16px;
				cursor: pointer;
				transition: background-color 0.3s ease;
			}
			.filter-button:hover {
				background-color: #166fe6;
			}
			.reset-button {
				background-color: #e4e6eb; /* Light grey reset button */
				color: #1c1e21; /* Dark grey text */
			}
			.reset-button:hover {
				background-color: #d8dadf;
			}
			#exportVisibleButton {
				background-color: #4CAF50; /* Green export button */
				margin-left: 10px;
			}
			#exportVisibleButton:hover {
				background-color: #45a049;
			}

			/* Table Styling */
			table {
				width: 100%;
				border-collapse: collapse;
				margin: 20px 0;
				font-family: 'Segoe UI', sans-serif;
				font-size: 14px;
				box-shadow: 0 1px 3px rgba(0,0,0,0.05); /* Lighter shadow */
				border-radius: 8px;
				overflow-x: auto; /* Enable horizontal scrolling for large tables */
				border: 1px solid #e0e0e0; /* Light grey border */
				background-color: white; /* White table background */
				display: block; /* Ensure table takes full width of its container */
			}
			th, td {
				padding: 12px 15px;
				text-align: center;
				border-bottom: 1px solid #e0e0e0;
				white-space: nowrap; /* Prevent text wrapping in cells */
			}
			th {
				background-color: #f5f6f7; /* Light grey header background */
				color: #65676b; /* Grey header text */
				font-weight: bold;
			}
			tr:nth-child(even) {
				background-color: #f9f9f9;
			}
			tr:hover {
				background-color: #edf2fa; /* Light blue on hover */
			}
			a {
				color: #1877F2; /* Facebook blue links */
				text-decoration: none;
			}
			a:hover {
				text-decoration: underline;
			}
			.delete-link {
				color: #dc3545;
			}
			.delete-link:hover {
				color: #c82333;
			}
			.no-records {
				color: #dc3545;
				text-align: center;
				font-weight: bold;
				margin-top: 20px;
			}
			/* Pagination Styling (Top) */
			.pagination-top {
				display: flex;
				justify-content: center;
				align-items: center;
				margin-bottom: 10px;
			}

			.page-button {
				color: #1877F2;
				padding: 6px 10px;
				text-decoration: none;
				border: 1px solid #ddd;
				margin: 0 5px;
				border-radius: 4px;
				font-size: 14px;
			}

			.page-button:hover {
				background-color: #f0f0f0;
			}

			.page-button.active {
				background-color: #1877F2;
				color: white;
				border: 1px solid #1877F2;
			}

			.page-info {
				margin: 0 10px;
				font-size: 20px;
				color: #65676b;
				font-weight: bold;
			}

			/* Hide the older pagination style if you had it */
			.pagination-bottom {
				display: none;
			}
			
		</style>
		</head>
		<body>
		
			<div class="container">
				<div class="add-button-container">
					<a href="view_records.php" class="add-button">
						Home Page
					</a>
				</div>

				<div class="filter-form-container">
					<form method="GET" action="" class="filter-form">
						<div class="filter-input-group">
							<label for="ref_number_filter" class="filter-label">📄 Filter by Ref Number:</label>
							<input type="text" name="ref_number_filter" id="ref_number_filter" placeholder="Enter Ref Number" class="filter-input">	
						
							<label for="date_filter" class="filter-label">📅 Filter by Date:</label>
							<input type="date" name="date_filter" id="date_filter" placeholder="YYYY-MM-DD" class="filter-input">

							<label for="shift_filter" class="filter-label">⚙️ Filter by Shift:</label>
							<input type="text" name="shift_filter" id="shift_filter" placeholder="Enter Shift" class="filter-input">

							<label for="customer_filter" class="filter-label">👤 Filter by Customer:</label>
							<input type="text" name="customer_filter" id="customer_filter" placeholder="Enter Customer" class="filter-input">
									

							<label for="lot_number_filter" class="filter-label">🔢 Filter by Lot Number:</label>
							<input type="text" name="lot_number_filter" id="lot_number_filter" placeholder="Enter Lot #" class="filter-input">
							
							<label for="setup_filter" class="filter-label">⚙️ Filter by Setup:</label>
							<input type="text" name="setup_filter" id="setup_filter" placeholder="Enter Setup" class="filter-input">

							

							<label for="setter_name_filter" class="filter-label">👷 Filter by Setter:</label>
							<input type="text" name="setter_name_filter" id="setter_name_filter" placeholder="Enter Setter Name" class="filter-input">

							<label for="operator_name_filter" class="filter-label">🧑‍🔧 Filter by Operator:</label>
							<input type="text" name="operator_name_filter" id="operator_name_filter" placeholder="Enter Operator Name" class="filter-input">

							<button type="submit" class="filter-button">Filter</button>
							<button type="button" onclick="window.location.href='<?php echo $_SERVER['PHP_SELF']; ?>';" class="reset-button">Reset Filters</button>
						</div>
					</form>
					<button id="exportVisibleButton" class="filter-button">Export Visible Data</button>
				</div>

			 <?php
				include('db_connection.php');

				$records_per_page = 10; // એક પેજ પર દેખાતા રેકોર્ડની સંખ્યા
				if (isset($_GET['page']) && is_numeric($_GET['page'])) {
					$current_page = intval($_GET['page']);
				} else {
					$current_page = 1;
				}
				$offset = ($current_page - 1) * $records_per_page;

				$where_clause = "WHERE 1=1"; // Initial condition
				$filter_params = ""; // ફિલ્ટર પરિમાણો માટે વેરીએબલ

				// Function to sanitize input
				function sanitize_input($data) {
					global $conn;
					return mysqli_real_escape_string($conn, trim($data));
				}

				// Apply filters based on GET parameters
				if (isset($_GET['ref_number_filter']) && !empty($_GET['ref_number_filter'])) {
					$ref_number_filter = sanitize_input($_GET['ref_number_filter']);
					$where_clause .= " AND ref_number LIKE '%$ref_number_filter%'";
					$filter_params .= "&ref_number_filter=" . urlencode($_GET['ref_number_filter']);
				}

				if (isset($_GET['date_filter']) && !empty($_GET['date_filter'])) {
					$date_filter = sanitize_input($_GET['date_filter']);
					$where_clause .= " AND date = '$date_filter'";
					$filter_params .= "&date_filter=" . urlencode($_GET['date_filter']);
				}

				if (isset($_GET['shift_filter']) && !empty($_GET['shift_filter'])) {
					$shift_filter = sanitize_input($_GET['shift_filter']);
					$where_clause .= " AND shift LIKE '%$shift_filter%'";
					$filter_params .= "&shift_filter=" . urlencode($_GET['shift_filter']);
				}

				if (isset($_GET['customer_filter']) && !empty($_GET['customer_filter'])) {
					$customer_filter = sanitize_input($_GET['customer_filter']);
					$where_clause .= " AND customer LIKE '%$customer_filter%'";
					$filter_params .= "&customer_filter=" . urlencode($_GET['customer_filter']);
				}

				if (isset($_GET['setup_filter']) && !empty($_GET['setup_filter'])) {
					$setup_filter = sanitize_input($_GET['setup_filter']);
					$where_clause .= " AND setup LIKE '%$setup_filter%'";
					$filter_params .= "&setup_filter=" . urlencode($_GET['setup_filter']);
				}

				if (isset($_GET['lot_number_filter']) && !empty($_GET['lot_number_filter'])) {
					$lot_number_filter = sanitize_input($_GET['lot_number_filter']);
					$where_clause .= " AND lot_number = '$lot_number_filter'";
					$filter_params .= "&lot_number_filter=" . urlencode($_GET['lot_number_filter']);
				}

				if (isset($_GET['setter_name_filter']) && !empty($_GET['setter_name_filter'])) {
					$setter_name_filter = sanitize_input($_GET['setter_name_filter']);
					$where_clause .= " AND setter_name LIKE '%$setter_name_filter%'";
					$filter_params .= "&setter_name_filter=" . urlencode($_GET['setter_name_filter']);
				}

				if (isset($_GET['operator_name_filter']) && !empty($_GET['operator_name_filter'])) {
					$operator_name_filter = sanitize_input($_GET['operator_name_filter']);
					$where_clause .= " AND operator_name LIKE '%$operator_name_filter%'";
					$filter_params .= "&operator_name_filter=" . urlencode($_GET['operator_name_filter']);
				}

				// કુલ રેકોર્ડની સંખ્યા મેળવો (ફિલ્ટર લાગુ કર્યા પછી)
				$total_records_sql = "SELECT COUNT(*) FROM production $where_clause";
				$total_records_result = $conn->query($total_records_sql);
				$total_records = $total_records_result->fetch_row()[0];
				$total_pages = ceil($total_records / $records_per_page);

				// વર્તમાન પેજના રેકોર્ડ મેળવો (ફિલ્ટર લાગુ કર્યા પછી)
				$sql = "SELECT * FROM production $where_clause LIMIT $offset, $records_per_page";
				$result = $conn->query($sql);

				// પેજિનેશન લિંક્સ (ઉપર)
				echo "<div class='pagination-top'>";
				if ($total_pages > 0) {
					echo "<a href='" . $_SERVER['PHP_SELF'] . "?page=1" . $filter_params . "' class='first-last-button'>First</a>";
				}
				if ($current_page > 1) {
					echo "<a href='" . $_SERVER['PHP_SELF'] . "?page=" . ($current_page - 1) . $filter_params . "' class='page-button'>&lt;</a>";
				}
				echo "<span class='page-info'>" . $current_page . " of " . $total_pages . "</span>";
				if ($current_page < $total_pages) {
					echo "<a href='" . $_SERVER['PHP_SELF'] . "?page=" . ($current_page + 1) . $filter_params . "' class='page-button'>&gt;</a>";
				}
				if ($total_pages > 0) {
					echo "<a href='" . $_SERVER['PHP_SELF'] . "?page=" . $total_pages . $filter_params . "' class='first-last-button'>Last</a>";
				}
				echo "</div>";

				// Check if any records were found
				if ($result->num_rows > 0) {
					// Table Header
					echo "<table>
							<thead>
								<tr>
									<th>ID</th>
									<th>Date</th>
									<th>Shift</th>
									<th>Shift Start Time</th>
									<th>Shift End Time</th>
									<th>Customer</th>
									<th>Machine Number</th>
									<th>Setup</th>
									<th>Cycle Minutes</th>
									<th>Cycle Seconds</th>
									<th>Loading Time</th>
									<th>Hourly Production</th>
									<th>Shift Production</th>
									<th>Setter Name</th>
									<th>Operator Name</th>
									<th>Ref Number</th>
									<th>Drowing & Rev no.</th>
									<th>Lot Number</th>
									<th>Lot Qty</th>
									<th>Heat Number</th>
									<th>Grade</th>
									<th>Part Count 1st</th>
									<th>Part Count 2nd</th>
									<th>Part Count 3rd</th>
									<th>PCWP</th>
									<th>Breakdwon List</th>
									<th>Breakdown Time</th>
									<th>Total Production</th>
									<th>Edit Production</th>
									</tr>
							</thead>
							<tbody>";

					// Display Data
					while($row = $result->fetch_assoc()) {
						echo "<tr>
								<td>" . $row['id'] . "</td>
								<td>" . $row['date'] . "</td>
								<td>" . $row['shift'] . "</td>
								<td>" . $row['shift_start_time'] . "</td>
								<td>" . $row['shift_end_time'] . "</td>
								<td>" . $row['customer'] . "</td>
								<td>" . $row['machine_number'] . "</td>
								<td>" . $row['setup'] . "</td>
								<td>" . $row['cycle_minutes'] . "</td>
								<td>" . $row['cycle_seconds'] . "</td>
								<td>" . $row['loading_time'] . "</td>
								<td>" . $row['hourly_target'] . "</td>
								<td>" . $row['shift_target'] . "</td>
								<td>" . $row['setter_name'] . "</td>
								<td>" . $row['operator_name'] . "</td>
								<td>" . $row['ref_number'] . "</td>
								<td>" . $row['drowing'] . "</td>
								<td>" . $row['lot_number'] . "</td>
								<td>" . $row['lot_qty'] . "</td>
								<td>" . $row['heat_number'] . "</td>
								<td>" . $row['grade'] . "</td>
								<td>" . $row['part_count_1st'] . "</td>
								<td>" . $row['part_count_2nd'] . "</td>
								<td>" . $row['part_count_3rd'] . "</td>
								<td>" . $row['pcwp'] . "</td>
								<td>" . $row['breakdown_list'] . "</td>
								<td>" . $row['breakdown_time'] . "</td>
								<td>" . $row['total_production'] . "</td>
								<td><a href='edit.php?id=" . $row['id'] . "' style='display: inline-block; padding: 8px 12px; font-size: 14px; text-align: center; text-decoration: none; cursor: pointer; border: 1px solid #4CAF50; color: #4CAF50; border-radius: 5px;' onmouseover='this.style.backgroundColor=\"#e0f2f7\"; this.style.borderColor=\"#2196F3\"; this.style.color=\"#2196F3\";' onmouseout='this.style.backgroundColor=\"transparent\"; this.style.borderColor=\"#4CAF50\"; this.style.color=\"#4CAF50\";'>✏️ Edit</a></td>
								</tr>";
					}
					echo "</tbody>
						</table>";
				} else {
					echo "<p class='no-records'>❌ No records found matching your filters.</p>";
				}

				$conn->close();
				?>
			</div>
			<script>
		function exportVisibleDataToExcel() {
		  const table = document.querySelector('table');
		  const thead = table.querySelector('thead');
		  const tbody = table.querySelector('tbody');
		  const visibleRows = Array.from(tbody.querySelectorAll('tr:not([style*="display: none"])')); // Only get visible rows

		  if (!thead || visibleRows.length === 0) {
			alert('No visible data to export.');
			return;
		  }

		  const headers = Array.from(thead.querySelectorAll('th')).map(th => th.textContent);
		  const dataToSend = visibleRows.map(row => {
			const cells = Array.from(row.querySelectorAll('td')).map(cell => cell.textContent);
			return cells;
		  });

		  const exportData = {
			headers: headers,
			data: dataToSend
		  };

		  fetch('export_visible_data.php', {
			method: 'POST',
			headers: {
			  'Content-Type': 'application/json',
			},
			body: JSON.stringify(exportData),
		  })
		  .then(response => response.blob())
		  .then(blob => {
			const url = window.URL.createObjectURL(blob);
			const a = document.createElement('a');
			a.href = url;
			a.download = 'visible_production_data.xls';
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			window.URL.revokeObjectURL(url);
		  })
		  .catch(error => {
			console.error('Error exporting data:', error);
			alert('An error occurred during export.');
		  });
		}

		// Button event listener
		const exportButton = document.getElementById('exportVisibleButton');
		if (exportButton) {
		  exportButton.addEventListener('click', exportVisibleDataToExcel);
		}
		</script>
		<script>
		function loadDropdown(fieldId, columnName) {
		  fetch('getOptions.php?type=' + encodeURIComponent(columnName))
			.then(response => response.json())
			.then(data => {
			  const select = document.getElementById(fieldId);
			  select.innerHTML = '<option value="">Select</option>';
			  data.forEach(item => {
				const option = document.createElement('option');
				option.value = item;
				option.textContent = item;
				select.appendChild(option);
			  });
			})
			.catch(error => {
			  console.error('Error loading ' + columnName + ' options:', error);
			});
		}

		document.addEventListener('DOMContentLoaded', function () {
		  loadDropdown('customer_filter', 'customer_filter');
			loadDropdown('setter_name', 'Setter Name');
		  loadDropdown('operator_name', 'Operator Name');
		  });

		</script>

		</body>
		</html>