<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <meta charset="UTF-8">
    <title>નોંધ શોધો</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        /* Facebook Theme CSS */
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5; /* Facebook's light grey background */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
        }

        .container {
            background-color: #fff; /* White container background */
            margin-top: 40px;
            padding: 30px 40px;
            border-radius: 8px; /* Slightly less rounded corners */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Softer shadow */
            max-width: 1280px;
            width: 95%;
        }

        h2 {
            text-align: center;
            color: #1877f2; /* Facebook's blue color */
            margin-bottom: 25px;
        }

        form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px; /* Slightly reduced gap */
        }

        label {
            font-weight: bold; /* Make labels bold */
            margin-bottom: 5px;
            display: block;
            color: #333; /* Darker text for better readability */
        }

        input, select, textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px; /* Slightly less rounded corners */
            border: 1px solid #ddd; /* Lighter border */
            font-size: 14px;
        }

        .full-width {
            grid-column: 1 / -1;
        }

        button {
            background-color: #1877f2; /* Facebook's blue color */
            color: #fff;
            border: none;
            padding: 10px 20px; /* Slightly reduced padding */
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px; /* Slightly less rounded corners */
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px;
        }

        button:hover {
            background-color: #166fe6; /* Slightly darker blue on hover */
        }
    </style>
</head>
<body>
<div class="container">
    <div style="margin: 20px 0; text-align: center;">
        <a href="view_records.php" style="
            background-color: #28a745;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: background-color 0.3s ease;
        " onmouseover="this.style.backgroundColor='#218838'" onmouseout="this.style.backgroundColor='#28a745'">
            HOME PAGE
        </a>
    </div>
    <h2>NOTE SEARCH</h2>
    <form action="search_results.php" method="GET">
        <label>Date: <input type="date" name="date" id="date"></label> <label>Shift:<select name="shift" id="shift"><option value="">Select shift</option></select></label>
        <label>Machine Number:<select name="machine_number" id="machine_number"><option value="">Select Machine</option></select></label>
        <label>Part Code: <input type="text" name="ref_number" id="ref_number"></label>
        <label>Lot Number: <input type="text" name="lot_number" id="lot_number"></label> <label>Operator: <input type="text" name="operator_name" id="operator_name"></label> <label>Setter: <input type="text" name="setter" id="setter"></label> <div class="full-width" style="margin-top: 20px;">
            <button type="submit">SEARCH</button>
        </div>
    </form>
</div>
<script>
    $(document).ready(function() {
        $('#date').on('change', function() {
            var selectedDate = $(this).val();
            $('#shift').empty().append('<option value="">Select shift</option>');
            $('#machine_number').empty().append('<option value="">Select Machine</option>');
            // Don't clear ref_number if we want to search by it
            // $('#ref_number').val('');
            $('#lot_number').val('');
            $('#operator_name').val('');
            $('#setter').val('');

            if (selectedDate) {
                $.ajax({
                    url: 'get_shifts.php',
                    type: 'POST',
                    data: { date: selectedDate },
                    dataType: 'json',
                    success: function(data) {
                        var shiftSelect = $('#shift');
                        shiftSelect.empty().append('<option value="">Select shift</option>');
                        $.each(data, function(key, value) {
                            shiftSelect.append('<option value="' + value + '">' + value + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching shifts:", error);
                    }
                });
            }
        });

        $('#shift').on('change', function() {
            var selectedShift = $(this).val();
            var selectedDate = $('#date').val();
            $('#machine_number').empty().append('<option value="">Select Machine</option>');
            // Don't clear ref_number
            // $('#ref_number').val('');
            $('#lot_number').val('');
            $('#operator_name').val('');
            $('#setter').val('');

            if (selectedShift && selectedDate) {
                $.ajax({
                    url: 'get_machines.php',
                    type: 'POST',
                    data: { date: selectedDate, shift: selectedShift },
                    dataType: 'json',
                    success: function(data) {
                        var machineSelect = $('#machine_number');
                        machineSelect.empty().append('<option value="">Select Machine</option>');
                        $.each(data, function(key, value) {
                            machineSelect.append('<option value="' + value + '">' + value + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching machines:", error);
                    }
                });
            }
        });

        $('#machine_number').on('change', function() {
            var selectedMachine = $(this).val();
            var selectedDate = $('#date').val();
            var selectedShift = $('#shift').val();
            if (selectedMachine && selectedDate && selectedShift) {
                $.ajax({
                    url: 'get_machine_details.php',
                    type: 'POST',
                    data: { date: selectedDate, machine: selectedMachine, shift: selectedShift },
                    dataType: 'json',
                    success: function(data) {
                        if (data) {
                            $('#ref_number').val(data.ref_number || '');
                            $('#lot_number').val(data.lot_number || '');
                            $('#operator_name').val(data.operator_name || '');
                            $('#setter').val(data.setter_name || '');
                        } else {
                            $('#ref_number').val('');
                            $('#lot_number').val('');
                            $('#operator_name').val('');
                            $('#setter').val('');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching machine details:", error);
                    }
                });
            } else {
                // Don't clear ref_number if we want to search by it independently
                // $('#ref_number').val('');
                $('#lot_number').val('');
                $('#operator_name').val('');
                $('#setter').val('');
            }
        });
    });
</script>
</body>
</html>