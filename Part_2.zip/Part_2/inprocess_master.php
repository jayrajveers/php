<?php
// તમે અહીં સેશન શરૂ કરી શકો છો અથવા અન્ય કોઈ PHP લોજિક ઉમેરી શકો છો
// session_start();
// જો યુઝર લોગ ઇન ન હોય તો રીડાયરેક્ટ કરી શકાય છે.
?>
<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERP ડેશબોર્ડ - પ્રોડક્શન ક્વોલિટી મેનેજમેન્ટ</title>
     <link rel="stylesheet" href="inprocess_report_entry.css"> <style>
        /* General Body and Layout */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; /* SAP-like font */
            margin: 0;
            padding: 0;
            background-color: var(--erp-background-color);
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }

        /* Header */
        .header {
            background-color: var(--erp-primary-color);
            color: #ffffff;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 4px var(--erp-shadow-color);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .header .logo {
            height: 40px; /* Adjust logo size */
            margin-right: 15px;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
			color: #ffffff;
        }

        /* Main Container for Sidebar and Content */
        .main-container {
            display: flex;
            flex: 1;
            width: 100%;
        }

        /* Sidebar Navigation */
        .sidebar {
            width: 250px;
            background-color: var(--erp-card-background);
            box-shadow: 2px 0 5px var(--erp-shadow-color);
            padding-top: 20px;
            flex-shrink: 0; /* Prevent sidebar from shrinking */
        }
        .sidebar h3 {
            color: var(--erp-primary-color);
            text-align: center;
            margin-bottom: 20px;
            padding: 0 15px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 5px;
        }
        .sidebar ul li a {
            display: block;
            padding: 12px 20px;
            color: var(--erp-text-color);
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.3s ease, color 0.3s ease;
            border-left: 5px solid transparent;
        }
        .sidebar ul li a:hover,
        .sidebar ul li a.active {
            background-color: var(--erp-primary-color);
            color: #ffffff;
            border-left-color: var(--erp-accent-color);
        }

        /* Dropdown specific styles within sidebar */
        .sidebar ul li.dropdown a {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .sidebar ul li.dropdown .dropdown-content {
            display: none;
            background-color: var(--erp-background-color); /* Lighter background for dropdown */
            min-width: 100%;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.05); /* Inner shadow for depth */
            z-index: 1;
        }

        .sidebar ul li.dropdown .dropdown-content a {
            color: var(--erp-text-color);
            padding: 10px 20px 10px 30px; /* Indent sub-items */
            text-decoration: none;
            display: block;
            text-align: left;
            font-size: 15px;
            transition: background-color 0.2s ease;
            border-left: 3px solid transparent; /* Subtle border for sub-items */
        }

        .sidebar ul li.dropdown .dropdown-content a:hover {
            background-color: var(--erp-border-color); /* Light hover for sub-items */
            color: var(--erp-primary-color);
            border-left-color: var(--erp-accent-color);
        }

        .sidebar ul li.dropdown.active > .dropdown-content {
            display: block; /* Show dropdown content if parent is active */
        }

        /* Content Area */
        .content-area {
            flex-grow: 1;
            padding: 20px;
            background-color: var(--erp-background-color);
            overflow-y: auto; /* Enable scrolling for content */
        }

        /* Dashboard-like cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            background-color: var(--erp-card-background);
            border-radius: 8px;
            box-shadow: 0 4px 8px var(--erp-shadow-color);
            padding: 25px;
            text-align: center;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            cursor: pointer;
            border-top: 5px solid var(--erp-accent-color);
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.12);
        }
        .card h2 {
            color: var(--erp-primary-color);
            margin-top: 0;
            font-size: 20px;
            margin-bottom: 15px;
        }
        .card p {
            color: var(--erp-light-text-color);
            font-size: 14px;
        }
        .card .icon {
            font-size: 40px;
            color: var(--erp-secondary-color);
            margin-bottom: 15px;
        }

        /* Footer */
        .footer {
            background-color: var(--erp-secondary-color);
            color: #ffffff;
            text-align: center;
            padding: 15px 20px;
            font-size: 14px;
            box-shadow: 0 -2px 4px var(--erp-shadow-color);
            margin-top: auto; /* Pushes footer to the bottom */
        }

        /* Basic Responsive Adjustments */
        @media (max-width: 768px) {
            .main-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                padding-top: 10px;
                box-shadow: 0 2px 5px var(--erp-shadow-color);
            }
            .sidebar ul {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }
            .sidebar ul li {
                margin: 5px;
            }
            .sidebar ul li a {
                padding: 10px 15px;
            }
            .header h1 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>

    <div class="header">
        <h1>પ્રોડક્શન ક્વોલિટી મેનેજમેન્ટ સિસ્ટમ</h1>
    </div>
<div class="main-container">
        <aside class="sidebar">
            <h3>મેનુ</h3>
           <ul>
                <li><a href="home_page.php">HOME PAGE</a></li>
                <li class="button">
                    <a href="add_data.php">&#10010; ADD</a>
              	<li class="button">
                    <a href="inprocess_master.php">&#128202; INPROCESS</a>
					<li class="button">
                  <a href="view_records.php">&#128203; RECORDS</a>
                 <li class="dropdown">
                    <a href="#">LOGOUT</a>
                    <div class="dropdown-content">
                        <a href="logout.php">Logout</a>
                    </div>
                </li>
            </ul>
        </aside>
    

        <main class="content-area">
            <h1>સ્વાગત છે, ERP ડેશબોર્ડમાં!</h1>
          

            <div class="dashboard-cards">
                <div class="card" onclick="window.location.href='master_file.php'">
                    <div class="icon">&#9881;</div> <h2>પાર્ટ માસ્ટર</h2>
                    <p>પાર્ટની વિગતો અને ગુણધર્મોનું સંચાલન કરો.</p>
                </div>
                <div class="card" onclick="window.location.href='inprocess_report_entry.php'">
                    <div class="icon">&#128221;</div> <h2>ઇન-પ્રોસેસ એન્ટ્રી</h2>
                    <p>ઇન-પ્રોસેસ માપન ડેટા દાખલ કરો.</p>
                </div>
                <div class="card" onclick="window.location.href='inprocess_report_view.php'">
                    <div class="icon">&#128202;</div> <h2>ઇન-પ્રોસેસ રિપોર્ટ</h2>
                    <p>ઇન-પ્રોસેસ માપન રિપોર્ટ્સ જુઓ.</p>
                </div>
                <div class="card" onclick="window.location.href='view_history.php'">
                    <div class="icon">&#128198;</div> <h2>લોગ હિસ્ટરી</h2>
                    <p>સિસ્ટમમાં થયેલા ફેરફારોની હિસ્ટરી જુઓ.</p>
                </div>
            </div>
        </main>
    </div>

    <footer class="footer">
        <p>&copy; <?php echo date("Y"); ?> Duhee Allowy Steel All rights reserved.</p>
    </footer>

    <script>
        // JavaScript for active link highlighting (optional)
        document.addEventListener('DOMContentLoaded', function() {
            const currentPath = window.location.pathname.split('/').pop();
            const sidebarLinks = document.querySelectorAll('.sidebar ul li a');

            sidebarLinks.forEach(link => {
                if (link.getAttribute('href') === currentPath) {
                    link.classList.add('active');
                } else if (currentPath === '' && link.getAttribute('href') === 'index.php') {
                    // For the root index page
                    link.classList.add('active');
                }
            });
        });
    </script>
</body>
</html>