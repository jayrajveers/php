<?php
/**
 * CNC પ્રોગ્રામમાંથી કુલ ટ્રાવેલ ડિસ્ટન્સ અને અંદાજિત સાયકલ ટાઇમની ગણતરી કરે છે.
 *
 * @param string $program CNC G-code પ્રોગ્રામ.
 * @param float $rapidRate મશીનની રેપિડ ટ્રાવર્સ રેટ (mm/min).
 * @param float $toolChangeTime સરેરાશ ટૂલ ચેન્જ ટાઈમ (સેકન્ડ).
 * @param float $defaultFeedrate જો F-code ન મળે તો વપરાયેલ ડિફોલ્ટ ફીડરેટ (mm/rev).
 * @param float $defaultSpindleSpeed જો S-code ન મળે તો વપરાયેલ ડિફોલ્ટ સ્પિન્ડલ સ્પીડ (RPM).
 * @return array જેમાં 'totalDistance' અને 'totalTime' હોય છે.
 */
function calculateCycleTime($program, $rapidRate, $toolChangeTime, $defaultFeedrate, $defaultSpindleSpeed) {
    $lines = explode("\n", strtoupper($program)); // પ્રોગ્રામને લાઇનમાં વિભાજીત કરો અને અપરકેસમાં કન્વર્ટ કરો
    $lastX = 0; // છેલ્લો X પોઝિશન
    $lastZ = 0; // છેલ્લો Z પોઝિશન
    $currentFeedrate = $defaultFeedrate; // વર્તમાન ફીડરેટ, શરૂઆતમાં ડિફોલ્ટ પર સેટ
    $currentSpindleSpeed = $defaultSpindleSpeed; // વર્તમાન સ્પિન્ડલ સ્પીડ, શરૂઆતમાં ડિફોલ્ટ પર સેટ
    $totalTime = 0.0; // કુલ સાયકલ ટાઈમ
    $totalDistance = 0.0; // કુલ ટ્રાવેલ ડિસ્ટન્સ (G00 અને G01 બંને માટે)

    foreach ($lines as $line) {
        // વર્તમાન લાઇનમાંથી X અને Z પોઝિશન પાર્સ કરો
        $x = $lastX; // જો X ન મળે, તો છેલ્લી X પોઝિશનનો ઉપયોગ કરો
        $z = $lastZ; // જો Z ન મળે, તો છેલ્લી Z પોઝિશનનો ઉપયોગ કરો

        if (preg_match('/X([\-\d\.]+)/', $line, $xm)) {
            $x = floatval($xm[1]);
        }
        if (preg_match('/Z([\-\d\.]+)/', $line, $zm)) {
            $z = floatval($zm[1]);
        }

        // વર્તમાન લાઇનમાંથી F (Feedrate) પાર્સ કરો
        if (preg_match('/F([\d\.]+)/', $line, $fm)) {
            $currentFeedrate = floatval($fm[1]);
        }

        // વર્તમાન લાઇનમાંથી S (Spindle Speed) પાર્સ કરો
        if (preg_match('/S([\d\.]+)/', $line, $sm)) {
            $currentSpindleSpeed = floatval($sm[1]);
        }

        // --- G01 (Linear Interpolation - Cutting Move) ---
        if (strpos($line, 'G01') !== false || strpos($line, 'G1') !== false) {
            $dist = sqrt(pow($x - $lastX, 2) + pow($z - $lastZ, 2)); // Euclidean distance ગણતરી
            $totalDistance += $dist; // કુલ ડિસ્ટન્સમાં ઉમેરો

            if ($dist > 0 && $currentFeedrate > 0 && $currentSpindleSpeed > 0) {
                // ફીડરેટ (mm/rev) અને સ્પિન્ડલ સ્પીડ (RPM) નો ઉપયોગ કરીને લીનિયર ફીડરેટ (mm/min) ગણતરી કરો
                $linearFeedRate = $currentFeedrate * $currentSpindleSpeed;
                // સમયની ગણતરી કરો (સેકન્ડમાં), mm/min ને mm/sec માં રૂપાંતરિત કરો
                $time = $dist / ($linearFeedRate / 60);
                $totalTime += $time;
            }
        }
        // --- G00 (Rapid Traverse - Non-Cutting Move) ---
        else if (strpos($line, 'G00') !== false || strpos($line, 'G0') !== false) {
            $dist = sqrt(pow($x - $lastX, 2) + pow($z - $lastZ, 2)); // Euclidean distance ગણતરી
            $totalDistance += $dist; // કુલ ડિસ્ટન્સમાં ઉમેરો

            if ($dist > 0 && $rapidRate > 0) {
                // રેપિડ રેટનો ઉપયોગ કરીને સમયની ગણતરી કરો (સેકન્ડમાં), mm/min ને mm/sec માં રૂપાંતરિત કરો
                $time = $dist / ($rapidRate / 60);
                $totalTime += $time;
            }
        }
        // --- G04 (Dwell) ---
        else if (strpos($line, 'G04') !== false) {
            if (preg_match('/P([\d\.]+)/', $line, $pm) || preg_match('/X([\d\.]+)/', $line, $pm)) {
                $dwellTime = floatval($pm[1]);
                // સામાન્ય રીતે G04 Px એટલે x મિલિસેકન્ડ્સ, G04 Xx એટલે x સેકન્ડ્સ.
                // અહીં P ને મિલિસેકન્ડ્સ અને X ને સેકન્ડ્સ તરીકે ધારીએ છીએ.
                if (strpos($line, 'P') !== false) {
                    $dwellTime /= 1000; // મિલિસેકન્ડ્સને સેકન્ડ્સમાં રૂપાંતરિત કરો
                }
                $totalTime += $dwellTime; // કુલ સમયમાં ડ્વેલ ટાઈમ ઉમેરો
            }
        }
        // --- M06 (Tool Change) ---
        else if (strpos($line, 'M06') !== false) {
            $totalTime += $toolChangeTime; // કુલ સમયમાં ટૂલ ચેન્જ ટાઈમ ઉમેરો
        }
        // અન્ય M-કોડ્સ/G-કોડ્સ અહીં ઉમેરી શકાય છે

        // વર્તમાન પોઝિશનને આગામી ઇટરેશન માટે છેલ્લી પોઝિશન તરીકે સેટ કરો
        $lastX = $x;
        $lastZ = $z;
    }
    return ['totalDistance' => $totalDistance, 'totalTime' => $totalTime];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>CNC Cycle Time Calculator (Improved)</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f4f4f4; }
        h2 { color: #333; }
        form { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        label { display: block; margin-bottom: 8px; font-weight: bold; }
        textarea, input[type="number"], select { width: calc(100% - 22px); padding: 10px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 4px; }
        input[type="submit"] { background-color: #4CAF50; color: white; padding: 12px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        input[type="submit"]:hover { background-color: #45a049; }
        div.result { margin-top: 20px; padding: 15px; background: #e9e9e9; border-left: 5px solid #007bff; border-radius: 4px; }
        div.result strong { color: #333; }
    </style>
</head>
<body>
    <h2>CNC Cycle Time Calculator (Improved)</h2>
    <form method="post">
        <label for="program">તમારો CNC પ્રોગ્રામ અહીં પેસ્ટ કરો:</label><br>
        <textarea name="program" id="program" rows="20" cols="100"><?php echo isset($_POST['program']) ? htmlspecialchars($_POST['program']) : ''; ?></textarea><br><br>

        <label for="default_feedrate">સરેરાશ ફીડરેટ પસંદ કરો (mm/rev - જો F-code ન હોય તો ડિફોલ્ટ):</label>
        <select name="default_feedrate" id="default_feedrate">
            <?php
            $feedInput = isset($_POST["default_feedrate"]) ? $_POST["default_feedrate"] : "1.0";
            foreach ([0.1, 0.25, 0.5, 1.0, 1.5, 2.0, 3.0, 5.0] as $rate) { // વધુ વિકલ્પો ઉમેર્યા
                echo "<option value='$rate'" . ($feedInput == $rate ? " selected" : "") . ">$rate</option>";
            }
            ?>
        </select><br><br>

        <label for="default_spindle_speed">ડિફોલ્ટ સ્પિન્ડલ સ્પીડ (RPM - જો S-code ન હોય તો ડિફોલ્ટ):</label>
        <input type="number" step="1" name="default_spindle_speed" id="default_spindle_speed" value="<?php echo isset($_POST['default_spindle_speed']) ? htmlspecialchars($_POST['default_spindle_speed']) : '1000'; ?>"><br><br>

        <label for="rapid_traverse_rate">મશીન રેપિડ ટ્રાવર્સ રેટ (mm/min):</label>
        <input type="number" step="100" name="rapid_traverse_rate" id="rapid_traverse_rate" value="<?php echo isset($_POST['rapid_traverse_rate']) ? htmlspecialchars($_POST['rapid_traverse_rate']) : '30000'; ?>"><br><br>

        <label for="tool_change_time">સરેરાશ ટૂલ ચેન્જ ટાઈમ (સેકન્ડ):</label>
        <input type="number" step="0.5" name="tool_change_time" id="tool_change_time" value="<?php echo isset($_POST['tool_change_time']) ? htmlspecialchars($_POST['tool_change_time']) : '10'; ?>"><br><br>

        <input type="submit" value="સાયકલ ટાઈમ ગણતરી કરો">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // ફોર્મમાંથી ઇનપુટ્સ મેળવો
        $program = $_POST["program"];
        $defaultFeedrate = floatval($_POST["default_feedrate"]);
        $defaultSpindleSpeed = floatval($_POST["default_spindle_speed"]);
        $rapidTraverseRate = floatval($_POST["rapid_traverse_rate"]);
        $toolChangeTime = floatval($_POST["tool_change_time"]);

        // calculateCycleTime ફંક્શનને કોલ કરો
        $results = calculateCycleTime($program, $rapidTraverseRate, $toolChangeTime, $defaultFeedrate, $defaultSpindleSpeed);
        $distance = $results['totalDistance'];
        $cycleTime = $results['totalTime'];

        // પરિણામો દર્શાવો
        echo "<div class='result'>
        <strong>ગણતરી કરેલ કુલ ટ્રાવેલ ડિસ્ટન્સ (G00/G01):</strong> " . round($distance, 2) . " mm<br>
        <strong>અંદાજિત સાયકલ ટાઈમ:</strong> " . round($cycleTime, 2) . " સેકન્ડ
        </div>";
    }
    ?>
</body>
</html>