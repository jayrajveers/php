<?php
// Database connection details
$servername = "localhost"; // Tamaro server name
$username = "root"; // Tamaro database username
$password = ""; // Tamaro database password
$dbname = "dasp"; // Tamaro database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get data from the form
$date = $_POST['date'];
$shift = $_POST['shift'];
$machine_number = $_POST['machine_number'];
$ref_number = $_POST['ref_number'];
$lot_number = $_POST['lot_number'];
$operator_name = $_POST['operator_name'];
$setter = $_POST['setter'];

// Forging section
$FORGING_OD_UNFILL = $_POST['FORGING_OD_UNFILL'];
$FORGING_OD_LAPING = $_POST['FORGING_OD_LAPING'];
$FORGING_OD_CRAKE = $_POST['FORGING_OD_CRAKE'];
$FORGING_BORE_UNFILL = $_POST['FORGING_BORE_UNFILL'];
$FORGING_BORE_LAPING = $_POST['FORGING_BORE_LAPING'];
$FORGING_BORE_CRAKE = $_POST['FORGING_BORE_CRAKE'];
$FORGING_WIDTH_UNFILL = $_POST['FORGING_WIDTH_UNFILL'];
$FORGING_WIDTH_LAPING = $_POST['FORGING_WIDTH_LAPING'];
$FORGING_WIDTH_CRAKE = $_POST['FORGING_WIDTH_CRAKE'];
$FORGING_TRACK_UNFILL = $_POST['FORGING_TRACK_UNFILL'];
$FORGING_TRACK_LAPING = $_POST['FORGING_TRACK_LAPING'];
$FORGING_TRACK_CARKE = $_POST['FORGING_TRACK_CARKE'];
$FORGING_TOTAL = $_POST['FORGING_TOTAL'];

// Inhouse & Vendor section
$INHOUSE = $_POST['INHOUSE'];
$VendorName = $_POST['VendorName'];
$Vendornos = $_POST['Vendornos'];
$VENDOR_TOTAL = $_POST['VENDOR_TOTAL'];

// CNC section
$CNC_WIDTH = $_POST['CNC_WIDTH'];
$CNC_ID = $_POST['CNC_ID'];
$CNC_OD = $_POST['CNC_OD'];
$CNC_TRACK = $_POST['CNC_TRACK'];
$CNC_LOCATION = $_POST['CNC_LOCATION'];
$CNC_LOADING_MISTAKE = $_POST['CNC_LOADING_MISTAKE'];
$CNC_GROOVE = $_POST['CNC_GROOVE'];
$CNC_SETTING = $_POST['CNC_SETTING'];
$CNC_OTHER = $_POST['CNC_OTHER'];
$CNC_Total = $_POST['CNC_Total'];

// Total
$TOTAL = $_POST['TOTAL'];

// SQL query to insert data into your table (badalvani rahese)
$sql = "INSERT INTO rejectiondata (
entrydate, shift, machinenumber, partcode, lot_number, operator, setter,
FORGING_OD_UNFILL, FORGING_OD_LAPING, FORGING_OD_CRAKE,
FORGING_BORE_UNFILL, FORGING_BORE_LAPING, FORGING_BORE_CRAKE,
FORGING_WIDTH_UNFILL, FORGING_WIDTH_LAPING, FORGING_WIDTH_CRAKE,
FORGING_TRACK_UNFILL, FORGING_TRACK_LAPING, FORGING_TRACK_CARKE, FORGING_TOTAL,
INHOUSE, VendorName, vendor_nos, VENDOR_TOTAL,
CNC_WIDTH, CNC_ID, CNC_OD, CNC_TRACK, CNC_LOCATION, CNC_LOADING_MISTAKE, CNC_GROOVE, CNC_SETTING, CNC_OTHER, CNC_Total,
TOTAL
) VALUES (
'$date', '$shift', '$machine_number', '$ref_number', '$lot_number', '$operator_name', '$setter',
'$FORGING_OD_UNFILL', '$FORGING_OD_LAPING', '$FORGING_OD_CRAKE',
'$FORGING_BORE_UNFILL', '$FORGING_BORE_LAPING', '$FORGING_BORE_CRAKE',
'$FORGING_WIDTH_UNFILL', '$FORGING_WIDTH_LAPING', '$FORGING_WIDTH_CRAKE',
'$FORGING_TRACK_UNFILL', '$FORGING_TRACK_LAPING', '$FORGING_TRACK_CARKE', '$FORGING_TOTAL',
'$INHOUSE', '$VendorName', '$Vendornos', '$VENDOR_TOTAL',
'$CNC_WIDTH', '$CNC_ID', '$CNC_OD', '$CNC_TRACK', '$CNC_LOCATION', '$CNC_LOADING_MISTAKE', '$CNC_GROOVE', '$CNC_SETTING', '$CNC_OTHER', '$CNC_Total',
'$TOTAL'
)";

if ($conn->query($sql) === TRUE) {
    echo "<p style='color: green; font-weight: bold;'>Data successfully entered!</p>";
    echo "<button onclick=\"window.location.href='rejection_.php'\">Go back to form</button>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    echo "<button onclick=\"window.location.href='rejection_.php'\">Try again</button>";
}

$conn->close();

?>