<?php
// PHP error reporting (for debugging, remove in production)
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

header('Content-Type: application/json');

// Your base upload directory path
$baseUploadDir = 'uploads/';

$response = ['status' => 'error', 'message' => 'Invalid request.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['path'])) {
    $itemPath = urldecode($_POST['path']); // Path to item to delete

    // Security check: Ensure path is within baseUploadDir
    if (strpos($itemPath, $baseUploadDir) !== 0) {
        $response['message'] = 'Security warning: Invalid path.';
        echo json_encode($response);
        exit;
    }

    // Prevent deleting the base upload directory itself
    if ($itemPath === rtrim($baseUploadDir, '/') || $itemPath === $baseUploadDir) {
        $response['message'] = 'The main upload directory cannot be deleted.';
        echo json_encode($response);
        exit;
    }

    if (file_exists($itemPath)) {
        if (is_file($itemPath)) {
            // Delete file
            if (unlink($itemPath)) {
                $response['status'] = 'success';
                $response['message'] = htmlspecialchars(basename($itemPath)) . ' file deleted successfully.';
            } else {
                $response['message'] = 'Error deleting file.';
            }
        } elseif (is_dir($itemPath)) {
            // Delete folder (must be empty)
            // rmdir() only deletes empty directories.
            // For simplicity, we'll use rmdir() and return an error if not empty.
            if (count(array_diff(scandir($itemPath), array('.', '..'))) == 0) { // Check if folder is empty
                if (rmdir($itemPath)) {
                    $response['status'] = 'success';
                    $response['message'] = htmlspecialchars(basename($itemPath)) . ' folder deleted successfully.';
                } else {
                    $response['message'] = 'Error deleting folder.';
                }
            } else {
                $response['message'] = 'Folder is not empty. Please delete all files and sub-folders inside it first.';
            }
        }
    } else {
        $response['message'] = 'Item does not exist.';
    }
}

echo json_encode($response);
?>
