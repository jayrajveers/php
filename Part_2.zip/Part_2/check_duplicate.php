<?php
$servername = "localhost"; // Tamaro server name
$username = "root"; // Tamaro database username
$password = ""; // Tamaro database password
$dbname = "dasp"; // Tamaro database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$date = $_POST['date'];
$shift = $_POST['shift'];
$machine_number = $_POST['machine_number'];

$sql = "SELECT COUNT(*) FROM production WHERE date = '$date' AND shift = '$shift' AND machine_number = '$machine_number'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  if ($row['COUNT(*)'] > 0) {
    echo 'duplicate';
  } else {
    echo 'unique';
  }
} else {
  echo 'unique'; // Or handle database error appropriately
}

$conn->close();
?>