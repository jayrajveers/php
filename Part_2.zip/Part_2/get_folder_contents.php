<?php
// get_folder_contents.php
$path = isset($_GET['path']) ? $_GET['path'] : 'uploads/';

if (!is_dir($path)) {
    echo '<p class="message error">Folder not found.</p>';
    exit;
}

// Sanitize path to prevent directory traversal
$basePath = realpath('uploads/');
$requestedPath = realpath($path);

if ($requestedPath === false || strpos($requestedPath, $basePath) !== 0) {
    echo '<p class="message error">Invalid path.</p>';
    exit;
}

$items = scandir($path);
$items = array_diff($items, array('.', '..')); // Remove . and ..

// Sort items: folders first, then files, both alphabetically
usort($items, function($a, $b) use ($path) {
    $pathA = $path . '/' . $a;
    $pathB = $path . '/' . $b;

    // Compare directories vs files
    if (is_dir($pathA) && !is_dir($pathB)) return -1; // Folder comes before file
    if (!is_dir($pathA) && is_dir($pathB)) return 1;  // File comes after folder

    // If both are same type, compare alphabetically
    return strcasecmp($a, $b);
});

echo '<div class="right-panel-header">';
echo '<h2>' . htmlspecialchars(basename($path) === '' ? 'My Drive' : basename($path)) . '</h2>'; // Show folder name
echo '<div class="action-buttons">';
echo '<button id="addFileButton" class="add-file-btn"><i class="fas fa-upload"></i> Upload File</button>';
echo '<button class="add-folder-btn add-subfolder-btn" data-parent-path="' . htmlspecialchars($path) . '"><i class="fas fa-plus"></i> New Subfolder</button>';
echo '</div>'; // .action-buttons
echo '</div>'; // .right-panel-header

// File Upload Form (initially hidden)
echo '<div id="fileUploadForm" class="upload-form" style="display: none;">';
echo '<form action="upload_file.php" method="post" enctype="multipart/form-data">';
echo '<input type="file" name="fileToUpload" id="fileToUpload" required>';
echo '<input type="hidden" name="upload_path" value="' . htmlspecialchars($path) . '">';
echo '<input type="submit" value="Upload" name="submit">';
echo '</form>';
echo '</div>'; // .upload-form

if (empty($items)) {
    echo '<p class="no-items-message">This folder is empty.</p>';
} else {
    echo '<div class="file-list-container">';
    echo '<ul>';
    foreach ($items as $item) {
        $itemPath = $path . '/' . $item;
        $itemName = htmlspecialchars($item);
        $iconClass = '';
        $link = '';
        $target = '_self'; // Default for folders
        $dataType = '';

        if (is_dir($itemPath)) {
            $iconClass = 'fas fa-folder';
            $link = '#'; // Folder names should not be direct links, handled by JS click
            $dataType = 'folder';
        } else {
            $fileExtension = pathinfo($item, PATHINFO_EXTENSION);
            switch (strtolower($fileExtension)) {
                case 'pdf': $iconClass = 'fas fa-file-pdf'; break;
                case 'doc':
                case 'docx': $iconClass = 'fas fa-file-word'; break;
                case 'xls':
                case 'xlsx': $iconClass = 'fas fa-file-excel'; break;
                case 'ppt':
                case 'pptx': $iconClass = 'fas fa-file-powerpoint'; break;
                case 'zip':
                case 'rar': $iconClass = 'fas fa-file-archive'; break;
                case 'jpg':
                case 'jpeg':
                case 'png':
                case 'gif': $iconClass = 'fas fa-file-image'; break;
                case 'mp3':
                case 'wav': $iconClass = 'fas fa-file-audio'; break;
                case 'mp4':
                case 'avi':
                case 'mov': $iconClass = 'fas fa-file-video'; break;
                case 'txt': $iconClass = 'fas fa-file-alt'; break;
                case 'html':
                case 'htm': $iconClass = 'fas fa-file-code'; break;
                default: $iconClass = 'fas fa-file'; break;
            }
            $link = 'download_file.php?path=' . urlencode($itemPath);
            $target = '_blank'; // Open files in a new tab
            $dataType = 'file';
        }

        echo '<li class="item-row" data-path="' . htmlspecialchars($itemPath) . '" data-type="' . $dataType . '">';
        echo '<div class="item-icon"><i class="' . $iconClass . '"></i></div>';
        echo '<a href="' . $link . '" target="' . $target . '">' . $itemName . '</a>';
        echo '<div class="item-actions">';
        echo '<button class="delete-btn" data-path="' . htmlspecialchars($itemPath) . '" data-type="' . $dataType . '"><i class="fas fa-trash"></i> Delete</button>';
        echo '</div>';
        echo '</li>';
    }
    echo '</ul>';
    echo '</div>';
}
?>