<?php
// PHP error reporting (for debugging, remove in production)
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

$baseUploadDir = 'uploads/'; // Your base upload directory path

// Set content type for AJAX response
header('Content-Type: application/json');
$response = ['status' => 'error', 'message' => 'Invalid request.'];

if (isset($_FILES['filesToUpload']) && isset($_POST['target_folder_path'])) {
    $targetFolder = $_POST['target_folder_path'];

    // Security check: Ensure $targetFolder starts with $baseUploadDir
    if (strpos($targetFolder, $baseUploadDir) !== 0) {
        $response['message'] = 'Security warning: Invalid upload folder path.';
        echo json_encode($response);
        exit;
    }

    if (!is_dir($targetFolder)) {
        mkdir($targetFolder, 0777, true); // Create if it doesn't exist
    }

    $uploadedCount = 0;
    $failedFiles = [];

    // Loop through each uploaded file
    foreach ($_FILES['filesToUpload']['name'] as $key => $fileName) {
        $tmpName = $_FILES['filesToUpload']['tmp_name'][$key];
        $error = $_FILES['filesToUpload']['error'][$key];

        if ($error === UPLOAD_ERR_OK) {
            $targetFilePath = $targetFolder . '/' . basename($fileName);

            if (move_uploaded_file($tmpName, $targetFilePath)) {
                $uploadedCount++;
            } else {
                $failedFiles[] = htmlspecialchars($fileName);
            }
        } else {
            $failedFiles[] = htmlspecialchars($fileName) . ' (Error code: ' . $error . ')';
        }
    }

    if ($uploadedCount > 0) {
        $response['status'] = 'success';
        $response['message'] = $uploadedCount . ' file(s) uploaded successfully.';
        if (!empty($failedFiles)) {
            $response['message'] .= ' Some files failed to upload: ' . implode(', ', $failedFiles) . '.';
        }
    } else {
        $response['message'] = 'No files were uploaded or all uploads failed.';
        if (!empty($failedFiles)) {
            $response['message'] .= ' Details: ' . implode(', ', $failedFiles) . '.';
        }
    }
}

echo json_encode($response);
?>