<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dasp";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$date = $_POST['date'];
$shift = $_POST['shift'];
$machine_number = $_POST['machine_number'];

// Prepared statement બનાવો
$sql = "SELECT COUNT(*) AS count FROM rejectiondata WHERE EntryDate = ? AND Shift = ? AND MachineNumber = ?";
$stmt = $conn->prepare($sql);

if ($stmt) {
    // પેરામીટર્સને બાંધો
    $stmt->bind_param("sss", $date, $shift, $machine_number);

    // ક્વેરી એક્ઝિક્યુટ કરો
    $stmt->execute();

    // પરિણામ મેળવો
    $result = $stmt->get_result();

    if ($result) {
        $row = $result->fetch_assoc();
        if ($row['count'] > 0) {
            echo 'duplicate';
        } else {
            echo 'unique';
        }
    } else {
        echo 'error';
    }

    // સ્ટેટમેન્ટ બંધ કરો
    $stmt->close();
} else {
    echo "Error preparing statement: " . $conn->error;
}

$conn->close();
?>