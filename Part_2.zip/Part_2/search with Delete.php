<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Production Records</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
       
        /* Stylish Add Button */
        .add-button-container {
            margin: 20px 0;
            text-align: center;
        }
        .add-button {
            background-color: #28a745;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: background-color 0.3s ease;
        }
        .add-button:hover {
            background-color: #218838;
        }
        /* Search Form */
        .filter-form-container {
            text-align: center;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        .filter-input-group {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
            margin-bottom: 10px;
        }
        .filter-label {
            font-size: 14px;
            font-weight: bold;
        }
        .filter-input {
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .filter-button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .filter-button:hover {
            background-color: #0056b3;
        }
        .reset-button {
            background-color: #6c757d;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .reset-button:hover {
            background-color: #545b62;
        }
        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border-radius: 4px;
            overflow: hidden;
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #343a40;
            color: #fff;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #e9f7ef;
        }
        a {
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .delete-link {
            color: #dc3545;
        }
        .delete-link:hover {
            color: #c82333;
        }
        .no-records {
            color: red;
            text-align: center;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="add-button-container">
            <a href="form.html" class="add-button">
                ➕ Add New Record
            </a>
        </div>

        <div class="filter-form-container">
            <form method="GET" action="" class="filter-form">
                <div class="filter-input-group">
					<label for="ref_number_filter" class="filter-label">📄 Filter by Ref Number:</label>
					<input type="text" name="ref_number_filter" id="ref_number_filter" placeholder="Enter Ref Number" class="filter-input">	
				
                    <label for="date_filter" class="filter-label">📅 Filter by Date:</label>
                    <input type="date" name="date_filter" id="date_filter" placeholder="YYYY-MM-DD" class="filter-input">

                    <label for="shift_filter" class="filter-label">⚙️ Filter by Shift:</label>
                    <input type="text" name="shift_filter" id="shift_filter" placeholder="Enter Shift" class="filter-input">

                    <label for="customer_filter" class="filter-label">👤 Filter by Customer:</label>
                    <input type="text" name="customer_filter" id="customer_filter" placeholder="Enter Customer" class="filter-input">
							

                    <label for="lot_number_filter" class="filter-label">🔢 Filter by Lot Number:</label>
                    <input type="text" name="lot_number_filter" id="lot_number_filter" placeholder="Enter Lot #" class="filter-input">
					
					<label for="setup_filter" class="filter-label">⚙️ Filter by Setup:</label>
					<input type="text" name="setup_filter" id="setup_filter" placeholder="Enter Setup" class="filter-input">

                    

                    <label for="setter_name_filter" class="filter-label">👷 Filter by Setter:</label>
                    <input type="text" name="setter_name_filter" id="setter_name_filter" placeholder="Enter Setter Name" class="filter-input">

                    <label for="operator_name_filter" class="filter-label">🧑‍🔧 Filter by Operator:</label>
                    <input type="text" name="operator_name_filter" id="operator_name_filter" placeholder="Enter Operator Name" class="filter-input">

                    <button type="submit" class="filter-button">Filter</button>
                    <button type="button" onclick="window.location.href='<?php echo $_SERVER['PHP_SELF']; ?>';" class="reset-button">Reset Filters</button>
                </div>
            </form>
			<button id="exportVisibleButton" class="filter-button">Export Visible Data</button>
        </div>

        <?php
        include('db_connection.php');

        $where_clause = "WHERE 1=1"; // Initial condition

        // Function to sanitize input
        function sanitize_input($data) {
            global $conn;
            return mysqli_real_escape_string($conn, trim($data));
        }

        // Apply filters based on GET parameters
        if (isset($_GET['ref_number_filter']) && !empty($_GET['ref_number_filter'])) {
        $ref_number_filter = sanitize_input($_GET['ref_number_filter']);
        $where_clause .= " AND ref_number LIKE '%$ref_number_filter%'";
    }

        if (isset($_GET['date_filter']) && !empty($_GET['date_filter'])) {
            $date_filter = sanitize_input($_GET['date_filter']);
            $where_clause .= " AND date = '$date_filter'";
        }

        if (isset($_GET['shift_filter']) && !empty($_GET['shift_filter'])) {
            $shift_filter = sanitize_input($_GET['shift_filter']);
            $where_clause .= " AND shift LIKE '%$shift_filter%'";
        }

        if (isset($_GET['customer_filter']) && !empty($_GET['customer_filter'])) {
            $customer_filter = sanitize_input($_GET['customer_filter']);
            $where_clause .= " AND customer LIKE '%$customer_filter%'";
        }

      if (isset($_GET['setup_filter']) && !empty($_GET['setup_filter'])) {
        $setup_filter = sanitize_input($_GET['setup_filter']);
        $where_clause .= " AND setup LIKE '%$setup_filter%'";
    }

      if (isset($_GET['lot_number_filter']) && !empty($_GET['lot_number_filter'])) {
        $lot_number_filter = sanitize_input($_GET['lot_number_filter']);
        // સિંગલ ડિજિટ મેચ માટે '=' નો ઉપયોગ કરો
        $where_clause .= " AND lot_number = '$lot_number_filter'";
    }

        if (isset($_GET['setter_name_filter']) && !empty($_GET['setter_name_filter'])) {
            $setter_name_filter = sanitize_input($_GET['setter_name_filter']);
            $where_clause .= " AND setter_name LIKE '%$setter_name_filter%'";
        }

        if (isset($_GET['operator_name_filter']) && !empty($_GET['operator_name_filter'])) {
            $operator_name_filter = sanitize_input($_GET['operator_name_filter']);
            $where_clause .= " AND operator_name LIKE '%$operator_name_filter%'";
        }

        // Add more filter conditions for other columns as needed

        $sql = "SELECT * FROM production $where_clause";
        $result = $conn->query($sql);

        // Check if any records were found
        if ($result->num_rows > 0) {
            // Table Header
            echo "<table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date</th>
                            <th>Shift</th>
                            <th>Shift Start Time</th>
                            <th>Shift End Time</th>
                            <th>Customer</th>
                            <th>Machine Number</th>
                            <th>Setup</th>
                            <th>Cycle Minutes</th>
                            <th>Cycle Seconds</th>
                            <th>Loading Time</th>
                            <th>Hourly Production</th>
                            <th>Shift Production</th>
                            <th>Setter Name</th>
                            <th>Operator Name</th>
                            <th>Ref Number</th>
                            <th>Drowing & Rev no.</th>
                            <th>Lot Number</th>
                            <th>Lot Qty</th>
                            <th>Heat Number</th>
                            <th>Grade</th>
                            <th>Part Count 1st</th>
                            <th>Part Count 2nd</th>
                            <th>Part Count 3rd</th>
                            <th>PCWP</th>
                            <th>Breakdwon List</th>
                            <th>Breakdown Time</th>
                            <th>Total Production</th>
							<th>Edit Production</th>
							<th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>";

            // Display Data
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row['id'] . "</td>
                        <td>" . $row['date'] . "</td>
                        <td>" . $row['shift'] . "</td>
                        <td>" . $row['shift_start_time'] . "</td>
                        <td>" . $row['shift_end_time'] . "</td>
                        <td>" . $row['customer'] . "</td>
                        <td>" . $row['machine_number'] . "</td>
                        <td>" . $row['setup'] . "</td>
                        <td>" . $row['cycle_minutes'] . "</td>
                        <td>" . $row['cycle_seconds'] . "</td>
                        <td>" . $row['loading_time'] . "</td>
                        <td>" . $row['hourly_target'] . "</td>
                        <td>" . $row['shift_target'] . "</td>
                        <td>" . $row['setter_name'] . "</td>
                        <td>" . $row['operator_name'] . "</td>
                        <td>" . $row['ref_number'] . "</td>
                        <td>" . $row['drowing'] . "</td>
                        <td>" . $row['lot_number'] . "</td>
                        <td>" . $row['lot_qty'] . "</td>
                        <td>" . $row['heat_number'] . "</td>
                        <td>" . $row['grade'] . "</td>
                        <td>" . $row['part_count_1st'] . "</td>
                        <td>" . $row['part_count_2nd'] . "</td>
                        <td>" . $row['part_count_3rd'] . "</td>
                        <td>" . $row['pcwp'] . "</td>
                        <td>" . $row['breakdown_list'] . "</td>
                        <td>" . $row['breakdown_time'] . "</td>
                        <td>" . $row['total_production'] . "</td>
						<td><a href='edit.php?id=" . $row['id'] . "'>✏️ Edit</a></td>
						<td><a href='delete.php?id=" . $row['id'] . "'
                onclick=\"return confirm('Are you sure you want to delete this record?');\"
                class='delete-link'>🗑️ Delete</a></td>
                    </tr>";
            }
            echo "</tbody>
                </table>";
        } else {
            echo "<p class='no-records'>❌ No records found matching your filters.</p>";
        }

        $conn->close();
        ?>
    </div>
	<script>
function exportVisibleDataToExcel() {
  const table = document.querySelector('table');
  const thead = table.querySelector('thead');
  const tbody = table.querySelector('tbody');
  const visibleRows = Array.from(tbody.querySelectorAll('tr:not([style*="display: none"])')); // Only get visible rows

  if (!thead || visibleRows.length === 0) {
    alert('No visible data to export.');
    return;
  }

  const headers = Array.from(thead.querySelectorAll('th')).map(th => th.textContent);
  const dataToSend = visibleRows.map(row => {
    const cells = Array.from(row.querySelectorAll('td')).map(cell => cell.textContent);
    return cells;
  });

  const exportData = {
    headers: headers,
    data: dataToSend
  };

  fetch('export_visible_data.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(exportData),
  })
  .then(response => response.blob())
  .then(blob => {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'visible_production_data.xls';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  })
  .catch(error => {
    console.error('Error exporting data:', error);
    alert('An error occurred during export.');
  });
}

// Button event listener
const exportButton = document.getElementById('exportVisibleButton');
if (exportButton) {
  exportButton.addEventListener('click', exportVisibleDataToExcel);
}
</script>
<script>
function loadDropdown(fieldId, columnName) {
  fetch('getOptions.php?type=' + encodeURIComponent(columnName))
    .then(response => response.json())
    .then(data => {
      const select = document.getElementById(fieldId);
      select.innerHTML = '<option value="">Select</option>';
      data.forEach(item => {
        const option = document.createElement('option');
        option.value = item;
        option.textContent = item;
        select.appendChild(option);
      });
    })
    .catch(error => {
      console.error('Error loading ' + columnName + ' options:', error);
    });
}

document.addEventListener('DOMContentLoaded', function () {
  loadDropdown('customer_filter', 'customer_filter');
    loadDropdown('setter_name', 'Setter Name');
  loadDropdown('operator_name', 'Operator Name');
  });

</script>

</body>
</html>