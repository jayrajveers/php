<?php
$conn = new mysqli("localhost", "root", "", "dasp");
$lot = $_GET["lot_number"];
$result = $conn->query("SELECT * FROM records WHERE lot_number LIKE '%$lot%'");

echo "<table border='1'>
<tr><th>Lot</th><th>Machine</th><th>Customer</th><th>Setter</th><th>Operator</th><th>Ref</th><th>Edit</th></tr>";

while ($row = $result->fetch_assoc()) {
  $data = implode("||", [
    $row["lot_number"],
    $row["machine_number"],
    $row["customer"],
    $row["setter"],
    $row["operator"],
    $row["ref_number"]
	$row["breakdown_list"]
  ]);
  echo "<tr>
    <td>{$row['lot_number']}</td>
    <td>{$row['machine_number']}</td>
    <td>{$row['customer']}</td>
    <td>{$row['setter']}</td>
    <td>{$row['operator']}</td>
    <td>{$row['ref_number']}</td>
	<td>{$row['breakdown_list']}</td>
    <td><button onclick=\"editRecord('$data')\">Edit</button></td>
  </tr>";
}
echo "</table>";
?>
