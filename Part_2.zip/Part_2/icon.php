<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Icon Display</title>
    <style>
        body {
            font-family: sans-serif;
            display: flex;
            flex-direction: column; /* Allow content to stack vertically */
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            background-color: #f0f0f0;
            padding: 20px;
            box-sizing: border-box;
        }

        h1 {
            color: #333;
            margin-bottom: 30px;
        }

        .input-container {
            width: 400px;
            max-width: 90%; /* Responsive width */
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 8px;
            display: flex;
            align-items: center;
            padding: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .input-container label {
            margin-right: 10px;
            color: #555;
            font-weight: bold;
        }

        .input-container input[type="text"] {
            flex-grow: 1;
            border: none;
            outline: none;
            padding: 10px 12px;
            font-size: 1.1em;
            background-color: #f9f9f9;
            border-radius: 5px;
        }

        #iconDisplayArea {
            margin-top: 40px;
            padding: 30px;
            border: 2px dashed #a0a0a0;
            border-radius: 10px;
            min-width: 200px;
            min-height: 100px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 8em; /* Make the displayed icon very large */
            color: #007bff; /* A nice blue color for the icon */
            background-color: #e9f5ff;
            box-shadow: inset 0 0 10px rgba(0,123,255,0.1);
            overflow: hidden; /* Prevent very large icons from breaking layout */
            word-break: break-all; /* Help break long codes */
            text-align: center;
        }

        #iconDisplayArea.placeholder::before {
            content: "તમારું આઇકન અહીં દેખાશે";
            font-size: 0.2em; /* Smaller font for placeholder */
            color: #888;
        }

        .error {
            color: red;
            margin-top: 10px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>Unicode Icon Generator</h1>

    <div class="input-container">
        <label for="unicodeInput">કોડ દાખલ કરો:</label>
        <input type="text" id="unicodeInput" placeholder="દા.ત. 128512 અથવા &#128512;">
    </div>

    <p class="error" id="errorMessage"></p>

    <div id="iconDisplayArea" class="placeholder">
        </div>

    <script>
        const unicodeInput = document.getElementById('unicodeInput');
        const iconDisplayArea = document.getElementById('iconDisplayArea');
        const errorMessage = document.getElementById('errorMessage');

        unicodeInput.addEventListener('keypress', function(event) {
            // Check if the Enter key was pressed (key code 13)
            if (event.key === 'Enter') {
                event.preventDefault(); // Prevent default Enter key behavior (like submitting a form)
                displayIcon();
            }
        });

        function displayIcon() {
            const inputValue = unicodeInput.value.trim(); // Get input value and remove leading/trailing spaces
            iconDisplayArea.innerHTML = ''; // Clear previous icon
            errorMessage.textContent = ''; // Clear previous error messages
            iconDisplayArea.classList.remove('placeholder'); // Remove placeholder class

            let charCode;

            // Check if the input starts with &# and ends with ;
            if (inputValue.startsWith('&#') && inputValue.endsWith(';')) {
                // Extract the number from the HTML entity (e.g., &#128512;)
                charCode = parseInt(inputValue.substring(2, inputValue.length - 1), 10);
            } else if (!isNaN(inputValue) && inputValue !== '') {
                // If it's just a number (e.g., 128512)
                charCode = parseInt(inputValue, 10);
            } else {
                errorMessage.textContent = 'માન્ય Unicode કોડ દાખલ કરો (દા.ત. 128512 અથવા &#128512;).';
                iconDisplayArea.classList.add('placeholder'); // Re-add placeholder
                return;
            }

            // Validate if the charCode is within a reasonable Unicode range
            // Emojis typically start from around U+1F600 (decimal 128512) to U+1F9FF (decimal 129535)
            // But general Unicode characters can be much lower or higher.
            // A common range for basic multilingual plane (BMP) is 0 to 65535,
            // and for supplementary planes (where most emojis are) is 65536 to 1114111.
            if (charCode >= 0 && charCode <= 1114111) {
                // Create a character from the Unicode code
                const char = String.fromCodePoint(charCode);
                iconDisplayArea.textContent = char; // Display the character
            } else {
                errorMessage.textContent = 'અમાન્ય Unicode કોડ રેન્જ.';
                iconDisplayArea.classList.add('placeholder'); // Re-add placeholder
            }
        }

        // Initial call to set placeholder
        displayIcon(); // This will show the placeholder initially
    </script>
</body>
</html>