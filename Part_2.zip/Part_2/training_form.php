<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>બલ્ક તાલીમ રેકોર્ડ ફોર્મ</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f8f9fa;
            color: #333;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            max-width: 800px;
            margin: auto;
            border-top: 5px solid #0056b3;
        }
        h2 {
            color: #0056b3;
            text-align: center;
            margin-bottom: 25px;
            font-size: 2em;
        }
        h3 {
            color: #007bff;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-top: 30px;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 18px;
        }
        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
            color: #555;
        }
        input[type="text"],
        input[type="date"],
        input[type="number"],
        textarea,
        select {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            font-size: 1rem;
            box-sizing: border-box;
        }
        textarea {
            resize: vertical;
            min-height: 80px;
        }
        button[type="submit"] {
            background-color: #28a745;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1rem;
            display: block;
            width: 100%;
            margin-top: 30px;
            transition: background-color 0.3s ease;
        }
        button[type="submit"]:hover {
            background-color: #218838;
        }
        .add-btn {
            background-color: #007bff;
            width: auto;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            color: white;
            cursor: pointer;
            font-size: 0.9rem;
            transition: background-color 0.3s ease;
            margin-top: 5px;
            float: right; /* Changed from display:block to float */
        }
        .add-btn:hover {
            background-color: #0056b3;
        }
        .remove-btn {
            background-color: #dc3545;
            width: auto;
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            color: white;
            cursor: pointer;
            font-size: 0.8rem;
            transition: background-color 0.3s ease;
            margin-left: 10px;
            vertical-align: middle;
        }
        .remove-btn:hover {
            background-color: #c82333;
        }
        .nav-buttons {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .nav-buttons a {
            background-color: #6c757d;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .nav-buttons a:hover {
            background-color: #5a6268;
        }
        .nav-buttons .primary-link {
            background-color: #007bff;
        }
        .nav-buttons .primary-link:hover {
            background-color: #0056b3;
        }
        .employee-field-group {
            border: 1px solid #ccc;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            background-color: #f0f8ff;
            position: relative; /* For positioning the remove button */
        }
        .employee-field-group .remove-btn {
            position: absolute;
            top: 10px;
            right: 10px;
        }
        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="nav-buttons">
            <a href="add_data.php">HOME PAGE</a>
            <a href="view_training_reports.php" class="primary-link">તાલીમ રિપોર્ટ જુઓ</a>
        </div>
        <h2>કર્મચારી તાલીમ રેકોર્ડ ફોર્મ (બલ્ક એન્ટ્રી)</h2>

        <form action="process_training.php" method="POST">

            <h3>તાલીમની વિગતો (બધા કર્મચારીઓ માટે સમાન)</h3>
            <div class="form-group">
                <label for="training_title">તાલીમનું શીર્ષક / વિષય:</label>
                <input type="text" id="training_title" name="training_title" required placeholder="દા.ત. CNC મશીન ઓપરેશન, IATF 16949 જાગૃતિ">
            </div>
            <div class="form-group">
                <label for="training_date">તાલીમની તારીખ:</label>
                <input type="date" id="training_date" name="training_date" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label for="training_type">તાલીમનો પ્રકાર:</label>
                <select id="training_type" name="training_type">
                    <option value="">પસંદ કરો</option>
                    <option value="On-the-Job">ઓન-ધ-જોબ (OJT)</option>
                    <option value="Classroom">વર્ગખંડ</option>
                    <option value="Online">ઓનલાઈન</option>
                    <option value="External Course">બાહ્ય કોર્સ/સેમિનાર</option>
                </select>
            </div>
            <div class="form-group">
                <label for="training_provider">તાલીમ પ્રદાતા (આંતરિક/બાહ્ય):</label>
                <input type="text" id="training_provider" name="training_provider" placeholder="દા.ત. આંતરિક ટ્રેનર, ABC કન્સલ્ટન્ટ્સ">
            </div>
            <div class="form-group">
                <label for="trainer_name">તાલીમ આપનારનું નામ:</label>
                <input type="text" id="trainer_name" name="trainer_name" placeholder="દા.ત. સુરેશભાઈ ટ્રેનર">
            </div>
            <div class="form-group">
                <label for="duration_hours">તાલીમનો સમયગાળો (કલાકોમાં):</label>
                <input type="number" id="duration_hours" name="duration_hours" step="0.5" min="0" placeholder="દા.ત. 4.5">
            </div>
            <div class="form-group">
                <label for="assessment_results">મૂલ્યાંકન પરિણામો (બધા માટે સમાન, અથવા દરેક માટે અલગ વિકલ્પ):</label>
                <input type="text" id="assessment_results" name="assessment_results" placeholder="દા.ત. પાસ, 85%, N/A">
            </div>
            <div class="form-group">
                <label for="competency_level_achieved">પ્રાપ્ત સક્ષમતા સ્તર (બધા માટે સમાન, અથવા દરેક માટે અલગ વિકલ્પ):</label>
                <select id="competency_level_achieved" name="competency_level_achieved">
                    <option value="">પસંદ કરો</option>
                    <option value="Basic">બેઝિક</option>
                    <option value="Intermediate">ઇન્ટરમીડિયેટ</option>
                    <option value="Advanced">એડવાન્સ</option>
                    <option value="Expert">નિષ્ણાત</option>
                </select>
            </div>
            <div class="form-group">
                <label for="next_training_due_date">આગામી તાલીમની નિયત તારીખ (જો લાગુ પડે તો - બધા માટે સમાન):</label>
                <input type="date" id="next_training_due_date" name="next_training_due_date">
            </div>
            <div class="form-group">
                <label for="remarks">નોંધ / ટિપ્પણીઓ (બધા માટે સમાન):</label>
                <textarea id="remarks" name="remarks" placeholder="કોઈપણ વધારાની નોંધો અથવા અવલોકનો"></textarea>
            </div>

            <h3>કર્મચારીઓની યાદી</h3>
            <div id="employeeContainer">
                <div class="employee-field-group" id="employee_group_1">
                    <button type="button" class="remove-btn" onclick="removeEmployee(this)">દૂર કરો</button>
                    <div class="form-group">
                        <label for="employee_name_1">કર્મચારી 1 નું નામ:</label>
                        <input type="text" id="employee_name_1" name="employees[0][name]" required placeholder="દા.ત. રમેશભાઈ પટેલ">
                    </div>
                    <div class="form-group">
                        <label for="employee_id_1">કર્મચારી 1 ID (જો કોઈ હોય તો):</label>
                        <input type="text" id="employee_id_1" name="employees[0][id]" placeholder="દા.ત. EMP-001">
                    </div>
                    <div class="form-group">
                        <label for="department_1">કર્મચારી 1 નો વિભાગ:</label>
                        <input type="text" id="department_1" name="employees[0][department]" placeholder="દા.ત. પ્રોડક્શન">
                    </div>
                     </div>
            </div>
            <div class="clearfix">
                <button type="button" id="addEmployee" class="add-btn">વધુ કર્મચારી ઉમેરો</button>
            </div>

            <button type="submit">બલ્ક તાલીમ રેકોર્ડ સબમિટ કરો</button>
        </form>
    </div>

    <script>
        let employeeCounter = 1;

        // Function to add a new employee field group
        document.getElementById('addEmployee').addEventListener('click', function() {
            employeeCounter++;
            const employeeContainer = document.getElementById('employeeContainer');
            const newEmployeeGroup = document.createElement('div');
            newEmployeeGroup.className = 'employee-field-group';
            newEmployeeGroup.id = `employee_group_${employeeCounter}`;
            newEmployeeGroup.innerHTML = `
                <button type="button" class="remove-btn" onclick="removeEmployee(this)">દૂર કરો</button>
                <div class="form-group">
                    <label for="employee_name_${employeeCounter}">કર્મચારી ${employeeCounter} નું નામ:</label>
                    <input type="text" id="employee_name_${employeeCounter}" name="employees[${employeeCounter - 1}][name]" required placeholder="દા.ત. અનિલભાઈ શાહ">
                </div>
                <div class="form-group">
                    <label for="employee_id_${employeeCounter}">કર્મચારી ${employeeCounter} ID (જો કોઈ હોય તો):</label>
                    <input type="text" id="employee_id_${employeeCounter}" name="employees[${employeeCounter - 1}][id]" placeholder="દા.ત. EMP-00${employeeCounter}">
                </div>
                <div class="form-group">
                    <label for="department_${employeeCounter}">કર્મચારી ${employeeCounter} નો વિભાગ:</label>
                    <input type="text" id="department_${employeeCounter}" name="employees[${employeeCounter - 1}][department]" placeholder="દા.ત. QC">
                </div>
                `;
            employeeContainer.appendChild(newEmployeeGroup);
        });

        // Function to remove an employee field group
        function removeEmployee(button) {
            const employeeGroup = button.closest('.employee-field-group');
            if (employeeGroup) {
                employeeGroup.remove();
            }
        }
    </script>
</body>
</html>