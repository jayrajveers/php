<?php
$connection = mysqli_connect("localhost", "root", "", "dasp");
if(!$connection){
    die("Connection Failed: " . mysqli_connect_error());
}

$date = mysqli_real_escape_string($connection, $_POST['date']);
$machine = mysqli_real_escape_string($connection, $_POST['machine']);
$shift = mysqli_real_escape_string($connection, $_POST['shift']); // શિફ્ટની વેલ્યુ મેળવો

    $query = "SELECT ref_number, lot_number, operator_name, setter_name FROM production WHERE `date` = '$date' AND machine_number = '$machine' AND shift = '$shift' LIMIT 1";
$result = mysqli_query($connection, $query);

$data = [];
if ($result) {
    $data = mysqli_fetch_assoc($result);
}

echo json_encode($data);
mysqli_close($connection);
?>