<?php
    session_start();

    // Check karo ke user logged in chhe ke nahi.
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        // Jo logged in nathi, to login page par redirect karo.
        header("location: login.php");
        exit;
    }
?>
<?php

// ડેટાબેઝની વિગતો
$servername = "localhost"; // અથવા તમારો ડેટાબેઝ હોસ્ટ
$username = "root"; // તમારું ડેટાબેઝ વપરાશકર્તા નામ
$password = ""; // તમારું ડેટાબેઝ પાસવર્ડ
$dbname = "dasp";

try {
    // PDO ઓબ્જેક્ટ બનાવીને ડેટાબેઝ સાથે કનેક્ટ કરો
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8mb4", $username, $password);
    // ભૂલો માટે PDO એરર મોડને અપવાદ પર સેટ કરો
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // શોધ ક્વેરી બનાવવા માટેના ભાગોને પ્રારંભ કરો
    $whereClauses = [];
    $params = [];

    // ફોર્મમાંથી શોધના માપદંડ મેળવો
    if (!empty($_GET['date'])) {
        $whereClauses[] = "date = :date";
        $params[':date'] = $_GET['date'];
    }
    if (!empty($_GET['shift'])) {
        $whereClauses[] = "shift = :shift";
        $params[':shift'] = $_GET['shift'];
    }
    if (!empty($_GET['machine_number'])) {
        $whereClauses[] = "machine_number LIKE :machine_number";
        $params[':machine_number'] = '%' . $_GET['machine_number'] . '%';
    }
    if (!empty($_GET['ref_number'])) {
        $whereClauses[] = "ref_number LIKE :ref_number";
        $params[':ref_number'] = '%' . $_GET['ref_number'] . '%';
    }
    if (!empty($_GET['lot_number'])) {
        $whereClauses[] = "lot_number LIKE :lot_number";
        $params[':lot_number'] = '%' . $_GET['lot_number'] . '%';
    }
    if (!empty($_GET['operator_name'])) {
        $whereClauses[] = "operator_name LIKE :operator_name";
        $params[':operator_name'] = '%' . $_GET['operator_name'] . '%';
    }
    if (!empty($_GET['setter'])) {
        $whereClauses[] = "setter LIKE :setter";
        $params[':setter'] = '%' . $_GET['setter'] . '%';
    }
    if (!empty($_GET['notes'])) {
        $whereClauses[] = "notes LIKE :notes";
        $params[':notes'] = '%' . $_GET['notes'] . '%';
    }

    // મૂળ SQL ક્વેરી બનાવો
    $sql = "SELECT id, date, shift, machine_number, ref_number, lot_number, operator_name, setter, image1, image2, image3, image4, image5, notes FROM note";

    // જો કોઈ શોધ માપદંડ હોય તો WHERE કલૉઝ ઉમેરો
    if (!empty($whereClauses)) {
        $sql .= " WHERE " . implode(" AND ", $whereClauses);
    }

    // ક્વેરી તૈયાર કરો
    $stmt = $conn->prepare($sql);

    // પરિમાણો બાંધો
    $stmt->execute($params);

    // પરિણામો મેળવો
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <meta charset="UTF-8">
        <title>NOTE SEARCH</title>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
        <style>
            /* તમારા note.php ફાઇલની સ્ટાઇલને અહીં કોપી કરો */
            * {
                box-sizing: border-box;
            }

            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background-color: #f0f2f5;
                margin: 0;
                padding: 0;
                display: flex;
                flex-direction: column;
                align-items: center;
                min-height: 100vh;
                padding-top: 60px; /* હેડર માટે જગ્યા */
            }

            .container {
                background-color: #fff;
                margin-top: 20px;
                padding: 30px 40px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                max-width: 1280px;
                width: 95%;
            }

            h2 {
                text-align: center;
                color: #1877f2;
                margin-bottom: 25px;
            }

            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }

            th, td {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }

            th {
                background-color: #f2f2f2;
                font-weight: bold;
            }

            tr:nth-child(even) {
                background-color: #f9f9f9;
            }

            .no-results {
                text-align: center;
                color: #777;
                margin-top: 20px;
            }

            .image-preview-small {
                max-width: 50px;
                height: auto;
                border: 1px solid #eee;
                border-radius: 4px;
                margin-right: 5px;
                vertical-align: middle;
            }

            .full-image-link {
                display: inline-block;
                margin-top: 5px;
                font-size: 0.9em;
                color: #1877f2;
                text-decoration: none;
            }

            .full-image-link:hover {
                text-decoration: underline;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div style="margin: 20px 0; text-align: center;">
                <a href="home_page.php" style="
                    background-color: #28a745;
                    color: white;
                    padding: 12px 25px;
                    text-decoration: none;
                    border-radius: 6px;
                    font-weight: bold;
                    font-size: 16px;
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                    transition: background-color 0.3s ease;
                " onmouseover="this.style.backgroundColor='#218838'" onmouseout="this.style.backgroundColor='#28a745'">
                    HOME PAGE
                </a>
                <a href="note_search.php" style="
                    background-color: #1877f2;
                    color: white;
                    padding: 12px 25px;
                    text-decoration: none;
                    border-radius: 6px;
                    font-weight: bold;
                    font-size: 16px;
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                    transition: background-color 0.3s ease;
                    margin-left: 10px;
                ">
                    NEW SEARCH
                </a>
            </div>
            <h2>NOTE LIST</h2>

            <?php if (!empty($results)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>DATE</th>
                            <th>SHIFT</th>
                            <th>MACHINE NUMBER</th>
                            <th>PART CODE</th>
                            <th>LOT NUMBER</th>
                            <th>OPRETOR</th>
                            <th>SETTER</th>
                            <th>IMAGE</th>
                            <th>NOTE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results as $row): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['date']; ?></td>
                                <td><?php echo $row['shift']; ?></td>
                                <td><?php echo $row['machine_number']; ?></td>
                                <td><?php echo $row['ref_number']; ?></td>
                                <td><?php echo $row['lot_number']; ?></td>
                                <td><?php echo $row['operator_name']; ?></td>
                                <td><?php echo $row['setter']; ?></td>
                                <td>
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <?php $image = $row['image' . $i]; ?>
                                        <?php if (!empty($image)): ?>
                                            <img src="<?php echo $image; ?>" alt="Image <?php echo $i; ?>" class="image-preview-small">
                                            <a href="<?php echo $image; ?>" target="_blank" class="full-image-link">VIEW</a>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </td>
                                <td><?php echo $row['notes']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="no-results">કોઈ પરિણામો મળ્યા નથી.</p>
            <?php endif; ?>
        </div>
    </body>
    </html>

    <?php

} catch(PDOException $e) {
    echo "<div style='font-family: sans-serif; text-align: center; margin-top: 50px; background-color: #ffebee; padding: 20px; border: 1px solid #ef9a9a; border-radius: 5px;'>";
    echo "<h2 style='color: #d32f2f;'>શોધ કરવામાં ભૂલ!</h2>";
    echo "<p>ભૂલ: " . $e->getMessage() . "</p>";
    echo "<p>કૃપા કરીને સંચાલકનો સંપર્ક કરો અથવા પછીથી ફરી પ્રયાસ કરો.</p>";
    echo "</div>";
}

$conn = null; // કનેક્શન બંધ કરો

?>