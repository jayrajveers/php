<?php
// download_file.php

if (isset($_GET['path'])) {
    $filePath = $_GET['path'];

    // --- Security Check: Important to prevent directory traversal ---
    $baseUploadDir = realpath('uploads/'); // Get the absolute path of your 'uploads' directory
    $requestedFilePath = realpath($filePath); // Get the absolute path of the requested file

    // Check if the requested file is actually inside the 'uploads' directory
    if ($requestedFilePath === false || strpos($requestedFilePath, $baseUploadDir) !== 0) {
        // If the file is not found or it's outside the allowed directory,
        // return a 404 Not Found or a forbidden error.
        header("HTTP/1.0 404 Not Found");
        echo "<h1>404 Not Found</h1>";
        echo "The requested file could not be found or you do not have permission to access it.";
        exit;
    }
    // --- End Security Check ---

    if (file_exists($requestedFilePath) && is_file($requestedFilePath)) {
        // Get the file's MIME type
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $requestedFilePath);
        finfo_close($finfo);

        // Get the base name of the file (e.g., "Document - 2.jpeg")
        $fileName = basename($requestedFilePath);

        // Set appropriate headers for file download
        header('Content-Description: File Transfer');
        header('Content-Type: ' . $mimeType);
        header('Content-Disposition: inline; filename="' . $fileName . '"'); // 'inline' to display in browser if possible, 'attachment' to force download
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($requestedFilePath));

        // Clear output buffer and read the file to the browser
        ob_clean();
        flush();
        readfile($requestedFilePath);
        exit;
    } else {
        // File does not exist
        header("HTTP/1.0 404 Not Found");
        echo "<h1>404 Not Found</h1>";
        echo "The requested file does not exist.";
        exit;
    }
} else {
    // 'path' parameter is missing
    header("HTTP/1.0 400 Bad Request");
    echo "<h1>400 Bad Request</h1>";
    echo "File path not specified.";
    exit;
}
?>