<?php

// --- 1. ડેટાબેઝ ગોઠવણી ---
// આ ફાઇલ માટે ડેટાબેઝ કનેક્શન અહીં જ સ્થાપિત કરો.
define('DB_SERVER', 'localhost'); // તમારું ડેટાબેઝ સર્વર
define('DB_USERNAME', 'root'); // તમારું ડેટાબેઝ યુઝરનેમ
define('DB_PASSWORD', ''); // તમારો ડેટાબેઝ પાસવર્ડ
define('DB_NAME', 'dasp'); // તમારા ડેટાબેઝનું નામ

// ડેટાબેઝ કનેક્શન બનાવો
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// કનેક્શન તપાસો
if ($conn->connect_error) {
    die("કનેક્શન નિષ્ફળ થયું: " . $conn->connect_error);
}

// PHP માં HTML સ્પેશિયલ કેરેક્ટરને એસ્કેપ કરવા માટેનું હેલ્પર ફંક્શન
function escape_html($str) {
    if (is_string($str)) {
        return htmlspecialchars($str, ENT_QUOTES | ENT_HTML5, 'UTF-8', false);
    }
    return $str;
}

/**
 * બધા પાર્ટ નંબર અને તેમના ID મેળવે છે.
 * @return array પાર્ટ રેકોર્ડ્સનો એરે.
 */
function getAllPartNumbers() {
    global $conn;
    $parts = [];
    $sql = "SELECT id AS part_id, part_number, part_name FROM parts ORDER BY part_number";
    $result = $conn->query($sql);
    if ($result === false) {
        error_log("getAllPartNumbers માં ક્વેરી ભૂલ: " . $conn->error);
    }
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $parts[] = $row;
        }
    }
    return $parts;
}

/**
 * આપેલ part_id માટે અનન્ય સેટઅપ માહિતી મેળવે છે.
 * @param int $part_id
 * @return array સેટઅપ માહિતીનો એરે.
 */
function getSetupsByPartId($part_id) {
    global $conn;
    $setups = [];
    $sql = "SELECT DISTINCT setup_info FROM part_parameters WHERE part_id = ? AND setup_info IS NOT NULL AND setup_info != '' ORDER BY setup_info";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (Setups): " . $conn->error);
        return [];
    }
    $stmt->bind_param("i", $part_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $setups[] = $row;
    }
    $stmt->close();
    return $setups;
}

/**
 * આપેલ part_id અને setup_info માટે ઇન-પ્રોસેસ માપન ડેટા મેળવે છે.
 * આ ફંક્શનમાં લોટ/બેચ નંબર અને તારીખ ફિલ્ટર ઉમેરવામાં આવ્યું છે.
 * @param int $part_id
 * @param string $setup_info
 * @param string|null $batch_number ફિલ્ટર કરવા માટેનો બેચ/લોટ નંબર. જો null, તો બધા બેચ નંબર માટે.
 * @param string|null $selected_date રિપોર્ટ માટે ચોક્કસ તારીખ (YYYY-MM-DD). જો null, તો બધી તારીખો માટે.
 * @return array માપનોનો એરે.
 */
function getInProcessMeasurementsForReport($part_id, $setup_info, $batch_number = null, $selected_date = null) {
    global $conn;
    $measurements = [];
    $sql = "SELECT ipm.id, ipm.measured_value, ipm.variance, ipm.positive_deviation_input, ipm.negative_deviation_input, ipm.measurement_date, ipm.operator_name, ipm.batch_number, ipm.heat_number, ipm.machine_id,
                    ipm.is_conforming, ipm.nonconformity_details, ipm.corrective_action_taken,
                    pp.parameter_name, pp.specification, pp.spec_positive, pp.spec_negative, pp.setup_info, pp.id AS parameter_id,
                    p.part_number, p.part_name, p.part_code
             FROM inprocess_measurements AS ipm
             JOIN part_parameters AS pp ON ipm.parameter_id = pp.id
             JOIN parts AS p ON ipm.part_id = p.id
             WHERE ipm.part_id = ? AND pp.setup_info = ?";

    $types = "is";
    $params = [$part_id, $setup_info];

    if ($batch_number !== null && $batch_number !== '') {
        $sql .= " AND ipm.batch_number = ?";
        $types .= "s";
        $params[] = $batch_number;
    }

    if ($selected_date !== null && $selected_date !== '') {
        $sql .= " AND DATE(ipm.measurement_date) = ?"; // Filter by exact date
        $types .= "s";
        $params[] = $selected_date;
    }

    $sql .= " ORDER BY ipm.measurement_date ASC, pp.parameter_name ASC"; // Order by date/time and then parameter name

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (In-process Report View): " . $conn->error);
        return [];
    }

    // Dynamic binding of parameters
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $measurements[] = $row;
    }
    $stmt->close();
    return $measurements;
}

/**
 * આપેલ part_id અને setup_info માટે અનન્ય લોટ/બેચ નંબર મેળવે છે.
 * @param int $part_id
 * @param string $setup_info
 * @return array લોટ/બેચ નંબરનો એરે.
 */
function getBatchNumbersByPartAndSetup($part_id, $setup_info) {
    global $conn;
    $batch_numbers = [];
    $sql = "SELECT DISTINCT ipm.batch_number
             FROM inprocess_measurements AS ipm
             JOIN part_parameters AS pp ON ipm.parameter_id = pp.id
             WHERE ipm.part_id = ? AND pp.setup_info = ? AND ipm.batch_number IS NOT NULL AND ipm.batch_number != ''
             ORDER BY ipm.batch_number";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (Batch Numbers): " . $conn->error);
        return [];
    }
    $stmt->bind_param("is", $part_id, $setup_info);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $batch_numbers[] = $row;
    }
    $stmt->close();
    return $batch_numbers;
}

/**
 * આપેલ part_id, setup_info અને batch_number માટે ઉપલબ્ધ અનન્ય માપન તારીખો મેળવે છે.
 * @param int $part_id
 * @param string $setup_info
 * @param string|null $batch_number
 * @return array તારીખોનો એરે (YYYY-MM-DD ફોર્મેટમાં).
 */
function getMeasurementDatesByPartSetupAndBatch($part_id, $setup_info, $batch_number = null) {
    global $conn;
    $dates = [];
    $sql = "SELECT DISTINCT DATE(ipm.measurement_date) AS measurement_date
             FROM inprocess_measurements AS ipm
             JOIN part_parameters AS pp ON ipm.parameter_id = pp.id
             WHERE ipm.part_id = ? AND pp.setup_info = ?";

    $types = "is";
    $params = [$part_id, $setup_info];

    if ($batch_number !== null && $batch_number !== '') {
        $sql .= " AND ipm.batch_number = ?";
        $types .= "s";
        $params[] = $batch_number;
    }

    $sql .= " ORDER BY measurement_date DESC"; // Most recent dates first

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (Measurement Dates): " . $conn->error);
        return [];
    }

    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $dates[] = $row;
    }
    $stmt->close();
    return $dates;
}


// AJAX: Part ID ના આધારે સેટઅપ મેળવો
if (isset($_GET['action']) && $_GET['action'] == 'get_setups_for_part') {
    $part_id = $_GET['part_id'] ?? 0;
    $setups = getSetupsByPartId($part_id);
    header('Content-Type: application/json');
    echo json_encode($setups);
    exit;
}

// AJAX: Part ID અને Setup Info ના આધારે બેચ નંબર મેળવો
if (isset($_GET['action']) && $_GET['action'] == 'get_batch_numbers_for_setup') {
    $part_id = $_GET['part_id'] ?? 0;
    $setup_info = $_GET['setup_info'] ?? '';
    $batch_numbers = getBatchNumbersByPartAndSetup($part_id, $setup_info);
    header('Content-Type: application/json');
    echo json_encode($batch_numbers);
    exit;
}

// AJAX: Part ID, Setup Info અને Batch Number ના આધારે માપન તારીખો મેળવો
if (isset($_GET['action']) && $_GET['action'] == 'get_measurement_dates') {
    $part_id = $_GET['part_id'] ?? 0;
    $setup_info = $_GET['setup_info'] ?? '';
    $batch_number = $_GET['batch_number'] ?? null;
    $measurement_dates = getMeasurementDatesByPartSetupAndBatch($part_id, $setup_info, $batch_number);
    header('Content-Type: application/json');
    echo json_encode($measurement_dates);
    exit;
}

// AJAX: રિપોર્ટ ડેટા મેળવો
if (isset($_GET['action']) && $_GET['action'] == 'get_inprocess_report_data') {
    $part_id = $_GET['part_id'] ?? 0;
    $setup_info = $_GET['setup_info'] ?? '';
    $batch_number = $_GET['batch_number'] ?? null;
    $selected_date = $_GET['selected_date'] ?? null; // Get selected date for filtering

    $report_data = getInProcessMeasurementsForReport($part_id, $setup_info, $batch_number, $selected_date);
    header('Content-Type: application/json');
    echo json_encode($report_data);
    exit;
}

$allPartNumbers = getAllPartNumbers();

?>

<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IATF ઇન-પ્રોસેસ કંટ્રોલ રિપોર્ટ વ્યૂ</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
            color: #333;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2, h3, h4 {
            color: #0056b3;
            text-align: center;
            margin-bottom: 20px;
        }
        .section {
            background-color: #e9f7ff;
            border: 1px solid #b3e0ff;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group select,
        .form-group input[type="text"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #0056b3;
        }

        /* Report specific styles */
        .report-header-info {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* Three columns */
            gap: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            background-color: #f9f9f9;
        }

        .report-header-info p {
            margin: 0;
            padding: 2px 0;
        }

        #inprocess_report_table table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 0.9em;
        }

        #inprocess_report_table th,
        #inprocess_report_table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
            vertical-align: middle;
        }

        #inprocess_report_table th {
            background-color: #e0e0e0;
            font-weight: bold;
            text-align: center;
        }

        #inprocess_report_table tr.non-conforming-row {
            background-color: #ffe6e6;
        }

        #inprocess_report_table .non-conforming-value {
            color: red;
            font-weight: bold;
        }

        /* Chart specific styles */
        #runchart_container {
            margin-top: 30px;
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #ddd;
        }
        #runchart_container canvas {
            max-height: 400px; /* Limit chart height */
            width: 100% !important; /* Ensure canvas takes full width */
            height: auto !important; /* Maintain aspect ratio */
        }
		/* Styling for a button-like link */
.add-button-container {
    text-align: center; /* જો બટનને સેન્ટરમાં લાવવું હોય તો */
    margin-top: 20px; /* ઉપરથી થોડી જગ્યા માટે */
    margin-bottom: 20px; /* નીચેથી થોડી જગ્યા માટે */
}

.add-button {
    display: inline-block; /* જેથી પેડિંગ અને માર્જિન યોગ્ય રીતે લાગુ પડે */
    padding: 12px 25px; /* બટનની અંદરની જગ્યા */
    background-color: var(--erp-primary-color); /* ERP પ્રાઇમરી કલર */
    color: #ffffff; /* ટેક્સ્ટ કલર સફેદ */
    text-decoration: none; /* લિંકની નીચેની લીટી દૂર કરો */
    border: none; /* કોઈ બોર્ડર નહીં */
    border-radius: 6px; /* ગોળાકાર કિનારીઓ */
    cursor: pointer; /* હોવર કરવા પર પોઇન્ટર બતાવો */
    font-size: 18px; /* ફોન્ટ સાઈઝ */
    font-weight: 500; /* ફોન્ટ વેઇટ */
    transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.2s ease; /* સ્મૂથ ટ્રાન્ઝિશન */
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* હળવો શેડો */
}

.add-button:hover {
    background-color: #303f9f; /* હોવર પર થોડો ઘાટો કલર */
    transform: translateY(-2px); /* હોવર પર થોડું ઉપર ખસેડો */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15); /* હોવર પર શેડો વધારો */
}

.add-button:active {
    transform: translateY(0); /* ક્લિક પર મૂળ સ્થિતિમાં પાછું લાવો */
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1); /* ક્લિક પર શેડો ઓછો કરો */
}
    </style>
</head>
<body>
<div class="add-button-container">
            <a href="inprocess_master.php" class="add-button">
                Home Page
            </a>
        </div>
		
		<div class="add-button-container">
            <a href="inprocess_report_view_.php" class="add-button">
                 Singl Value Formate
            </a>
        </div>
    
	
        <h1>IATF ઇન-પ્રોસેસ કંટ્રોલ રિપોર્ટ વ્યૂ</h1>

        <div class="section selection-area">
		
            <h2>માહિતી પસંદ કરો</h2>
            <div class="form-group">
                <label for="part_id">પાર્ટ નંબર:</label>
                <select id="part_id" onchange="loadSetups()">
                    <option value="">-- પાર્ટ નંબર પસંદ કરો --</option>
                    <?php
                    foreach ($allPartNumbers as $part) {
                        echo "<option value='" . escape_html($part['part_id']) . "'>" . escape_html($part['part_number']) . " - " .escape_html($part['part_name']) . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="setup_info">સેટઅપ:</label>
                <select id="setup_info" onchange="loadBatchNumbers()">
                    <option value="">-- સેટઅપ પસંદ કરો --</option>
                </select>
            </div>

            <div class="form-group">
                <label for="batch_number_filter">બેચ/લોટ નંબર (ફિલ્ટર):</label>
                <select id="batch_number_filter" onchange="loadMeasurementDates()">
                    <option value="">-- બધા બેચ/લોટ નંબર --</option>
                </select>
            </div>

            <div class="form-group">
                <label for="measurement_date_filter">તારીખ પસંદ કરો:</label>
                <select id="measurement_date_filter">
                    <option value="">-- બધી તારીખો --</option>
                </select>
            </div>

            <button onclick="loadReport()">રિપોર્ટ જુઓ</button>
        </div>

        <div class="section report-area" id="report_area" style="display: none;">
            <h2>ઇન-પ્રોસેસ માપન રિપોર્ટ</h2>
            <div id="inprocess_report_table">
                <p>રિપોર્ટ અહીં પ્રદર્શિત થશે.</p>
            </div>
            ---
            <div id="runchart_container" style="display: none;">
                <h3>રનચાર્ટ</h3>
                </div>
        </div>
    </div>

    <script>
        // Helper function to escape HTML for display
        function escapeHtml(str) {
            var div = document.createElement('div');
            div.appendChild(document.createTextNode(str));
            return div.innerHTML;
        }

        // Function to load setups based on selected part ID
        function loadSetups() {
            const partId = document.getElementById('part_id').value;
            const setupSelect = document.getElementById('setup_info');
            setupSelect.innerHTML = '<option value="">-- સેટઅપ પસંદ કરો --</option>'; // Clear existing options
            document.getElementById('batch_number_filter').innerHTML = '<option value="">-- બધા બેચ/લોટ નંબર --</option>'; // Clear batch numbers
            document.getElementById('measurement_date_filter').innerHTML = '<option value="">-- બધી તારીખો --</option>'; // Clear dates
            document.getElementById('report_area').style.display = 'none'; // Hide report area

            if (partId) {
                fetch(`inprocess_report_view.php?action=get_setups_for_part&part_id=${partId}`)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(setup => {
                            const option = document.createElement('option');
                            option.value = escapeHtml(setup.setup_info);
                            option.textContent = escapeHtml(setup.setup_info);
                            setupSelect.appendChild(option);
                        });
                    })
                    .catch(error => {
                        console.error('Error loading setups:', error);
                        alert('સેટઅપ્સ લોડ કરવામાં ભૂલ થઈ.');
                    });
            }
        }

        // Function to load batch numbers based on selected part ID and setup info
        function loadBatchNumbers() {
            const partId = document.getElementById('part_id').value;
            const setupInfo = document.getElementById('setup_info').value;
            const batchNumberSelect = document.getElementById('batch_number_filter');
            batchNumberSelect.innerHTML = '<option value="">-- બધા બેચ/લોટ નંબર --</option>'; // Clear existing options
            document.getElementById('measurement_date_filter').innerHTML = '<option value="">-- બધી તારીખો --</option>'; // Clear dates
            document.getElementById('report_area').style.display = 'none'; // Hide report area

            if (partId && setupInfo) {
                fetch(`inprocess_report_view.php?action=get_batch_numbers_for_setup&part_id=${partId}&setup_info=${encodeURIComponent(setupInfo)}`)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(batch => {
                            const option = document.createElement('option');
                            option.value = escapeHtml(batch.batch_number);
                            option.textContent = escapeHtml(batch.batch_number);
                            batchNumberSelect.appendChild(option);
                        });
                        // After loading batch numbers, load measurement dates
                        loadMeasurementDates();
                    })
                    .catch(error => {
                        console.error('Error loading batch numbers:', error);
                        alert('બેચ નંબર લોડ કરવામાં ભૂલ થઈ.');
                    });
            }
        }

        // Function to load measurement dates based on selected part ID, setup info, and batch number
        function loadMeasurementDates() {
            const partId = document.getElementById('part_id').value;
            const setupInfo = document.getElementById('setup_info').value;
            const batchNumber = document.getElementById('batch_number_filter').value;
            const dateSelect = document.getElementById('measurement_date_filter');
            dateSelect.innerHTML = '<option value="">-- બધી તારીખો --</option>'; // Clear existing options
            document.getElementById('report_area').style.display = 'none'; // Hide report area

            if (partId && setupInfo) {
                let url = `inprocess_report_view.php?action=get_measurement_dates&part_id=${partId}&setup_info=${encodeURIComponent(setupInfo)}`;
                if (batchNumber) {
                    url += `&batch_number=${encodeURIComponent(batchNumber)}`;
                }

                fetch(url)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(dateEntry => {
                            const option = document.createElement('option');
                            option.value = escapeHtml(dateEntry.measurement_date);
                            // Format date for display (e.g., DD-MM-YYYY)
                            const displayDate = new Date(dateEntry.measurement_date).toLocaleDateString('gu-IN');
                            option.textContent = escapeHtml(displayDate);
                            dateSelect.appendChild(option);
                        });
                    })
                    .catch(error => {
                        console.error('Error loading measurement dates:', error);
                        alert('માપનની તારીખો લોડ કરવામાં ભૂલ થઈ.');
                    });
            }
        }

        // Global variable to hold all chart instances
        let inProcessChartInstances = {};

        // Function to load the report and generate runcharts
        function loadReport() {
            const partId = document.getElementById('part_id').value;
            const setupInfo = document.getElementById('setup_info').value;
            const batchNumber = document.getElementById('batch_number_filter').value;
            const selectedDate = document.getElementById('measurement_date_filter').value;

            const reportTableDiv = document.getElementById('inprocess_report_table');
            const reportArea = document.getElementById('report_area');
            const runchartContainer = document.getElementById('runchart_container'); // Get the runchart container

            reportTableDiv.innerHTML = '<p>લોડ કરી રહ્યું છે...</p>';
            reportArea.style.display = 'none';
            runchartContainer.style.display = 'none'; // Hide runchart container initially

            // Clear previous charts
            for (const chartId in inProcessChartInstances) {
                if (inProcessChartInstances[chartId]) {
                    inProcessChartInstances[chartId].destroy();
                }
            }
            inProcessChartInstances = {}; // Reset the object
            runchartContainer.innerHTML = ''; // Clear the container of old canvases

            if (!partId || !setupInfo) {
                reportTableDiv.innerHTML = '<p>કૃપા કરીને પાર્ટ નંબર અને સેટઅપ પસંદ કરો.</p>';
                return;
            }

            let url = `inprocess_report_view.php?action=get_inprocess_report_data&part_id=${partId}&setup_info=${encodeURIComponent(setupInfo)}`;
            if (batchNumber) {
                url += `&batch_number=${encodeURIComponent(batchNumber)}`;
            }
            if (selectedDate) {
                url += `&selected_date=${encodeURIComponent(selectedDate)}`;
            }

            fetch(url)
                .then(response => response.json())
                .then(reportData => {
                    reportTableDiv.innerHTML = ''; // Clear loading message

                    if (reportData.length > 0) {
                        // --- TABLE GENERATION ---
                        const groupedData = {};
                        let distinctTimes = new Set();
                        reportData.forEach(row => {
                            const dateTimeKey = row.measurement_date;
                            distinctTimes.add(dateTimeKey);

                            if (!groupedData[dateTimeKey]) {
                                groupedData[dateTimeKey] = {
                                    operator_name: row.operator_name,
                                    batch_number: row.batch_number,
                                    heat_number: row.heat_number,
                                    machine_id: row.machine_id,
                                    measurements: []
                                };
                            }
                            groupedData[dateTimeKey].measurements.push(row);
                        });

                        const sortedDates = Array.from(distinctTimes).sort();

                        const uniqueParameters = [];
                        const parameterMap = new Map();
                        reportData.forEach(row => {
                            if (!parameterMap.has(row.parameter_id)) {
                                parameterMap.set(row.parameter_id, {
                                    parameter_id: row.parameter_id,
                                    parameter_name: row.parameter_name,
                                    specification: row.specification,
                                    spec_positive: row.spec_positive,
                                    spec_negative: row.spec_negative
                                });
                                uniqueParameters.push({
                                    parameter_id: row.parameter_id,
                                    parameter_name: row.parameter_name,
                                    specification: row.specification,
                                    spec_positive: row.spec_positive,
                                    spec_negative: row.spec_negative
                                });
                            }
                        });
                        // Sort unique parameters by name for consistent display
                        uniqueParameters.sort((a, b) => a.parameter_name.localeCompare(b.parameter_name));


                        let tableHtml = '<h2>Daily In-Process Inspection Report - CNC</h2>';
                        const firstRow = reportData[0]; // Use data from the first row for general info
                        tableHtml += `
                            <div class="report-header-info">
                                <p><strong>DATE:</strong> ${new Date(firstRow.measurement_date).toLocaleDateString('gu-IN')}</p>
                                <p><strong>CUSTOMER NAME: </strong> FAG</p>
                                <p><strong>SHIFT:</strong> DAY/NIGHT</p>
                                <p><strong>PART TYPE</strong> INNER RING</p>
                                <p><strong>PART NUMBER:</strong> ${escapeHtml(firstRow.part_number ?? '')}</p>
                                <p><strong>PART CODE:</strong> ${escapeHtml(firstRow.part_code ?? '')}</p>
                                <p><strong>LOT NUMBER :</strong> ${escapeHtml(firstRow.batch_number ?? '')}</p>
                                <p><strong>HEAT NUMBER :</strong> ${escapeHtml(firstRow.heat_number ?? '')}</p>
                                <p><strong>CNC Machine No:</strong> ${escapeHtml(firstRow.machine_id ?? '')}</p>
                                <p><strong>Operator Name:</strong> ${escapeHtml(firstRow.operator_name ?? '')}</p>
                                <p><strong>Inspector Name:</strong> </p>
                                <p><strong>Setup:</strong> ${escapeHtml(firstRow.setup_info ?? '')}</p>
                            </div>
                        `;

                        tableHtml += `
                            <table>
                                <thead>
                                    <tr>
                                        <th rowspan="2">No</th>
                                        <th rowspan="2">Parameter</th>
                                        <th rowspan="2">Specification</th>
                                        <th colspan="${sortedDates.length * 2}">Observation ( All Dimensions are in mm.) Hourly Inspection Qty 5pcs & Recorded 2 Pcs.</th>
                                    </tr>
                                    <tr>
                        `;

                        // Add dynamic time columns with + and - sub-columns
                        sortedDates.forEach((date, index) => {
                            const displayTime = new Date(date).toLocaleTimeString('gu-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
                            tableHtml += `<th colspan="2">${index + 1} Nos Time <br> (${displayTime})</th>`;
                        });

                        tableHtml += `
                                    </tr>
                                    <tr>
                        `;

                        // Add + અને - headers for each time slot
                        tableHtml += `<th colspan="3"></th>`; // Empty cells for No, Parameter, Specification
                        sortedDates.forEach(() => {
                            tableHtml += `<th>+ વિચલન</th><th>- વિચલન</th>`; // + and - deviation headers
                        });
                        tableHtml += `</tr>`;

                        tableHtml += `
                                </thead>
                                <tbody>
                        `;

                        // Populate table rows for each parameter
                        uniqueParameters.forEach((param, index) => {
                            tableHtml += `
                                <tr>
                                    <td>${index + 1}</td>
                                    <td>${escapeHtml(param.parameter_name)}</td>
                                    <td>${escapeHtml(param.specification ?? '')} ${param.spec_positive !== null && param.spec_negative !== null ? `(+${escapeHtml(param.spec_positive)} / -${escapeHtml(param.spec_negative)})` : ''}</td>
                            `;

                            // Add measurement values for each time slot with separate + and - columns
                            sortedDates.forEach(dateKey => {
                                const measurementsForThisTimeAndParam = reportData.filter(m =>
                                    m.parameter_id === param.parameter_id && m.measurement_date === dateKey
                                );

                                let positiveCellContent = '';
                                let negativeCellContent = '';
                                let isConformingRow = true; // Assume conforming initially for the row

                                if (measurementsForThisTimeAndParam.length > 0) {
                                    const measurement = measurementsForThisTimeAndParam[0]; // Take the first for now
                                    const positiveDeviation = measurement.positive_deviation_input;
                                    const negativeDeviation = measurement.negative_deviation_input;
                                    const isConforming = measurement.is_conforming == 1;

                                    if (positiveDeviation !== null && positiveDeviation !== '') {
                                        positiveCellContent = escapeHtml(positiveDeviation);
                                        if (!isConforming) {
                                            positiveCellContent = `<span class="non-conforming-value">${positiveCellContent} (NG)</span>`;
                                            isConformingRow = false; // Mark row as non-conforming
                                        }
                                    }

                                    if (negativeDeviation !== null && negativeDeviation !== '') {
                                        negativeCellContent = escapeHtml(negativeDeviation);
                                        if (!isConforming) {
                                            negativeCellContent = `<span class="non-conforming-value">${negativeCellContent} (NG)</span>`;
                                            isConformingRow = false; // Mark row as non-conforming
                                        }
                                    }
                                }

                                tableHtml += `<td>${positiveCellContent}</td><td>${negativeCellContent}</td>`;
                            });
                            tableHtml += `</tr>`;
                        });

                        tableHtml += '</tbody></table>';
                        reportTableDiv.innerHTML = tableHtml;
                        reportArea.style.display = 'block'; // Show report area

                        // --- RUNCHART GENERATION ---
                        createRunchart(reportData, uniqueParameters); // Pass reportData and uniqueParameters to the chart function
                        runchartContainer.style.display = 'block'; // Show the runchart container
                    } else {
                        reportTableDiv.innerHTML = '<p>આ પાર્ટ, સેટઅપ, બેચ નંબર અને પસંદ કરેલી તારીખ માટે કોઈ ઇન-પ્રોસેસ માપન મળ્યા નથી.</p>';
                        runchartContainer.style.display = 'none'; // Hide runchart if no data
                    }
                })
                .catch(error => {
                    console.error('Error loading in-process report data:', error);
                    reportTableDiv.innerHTML = '<p class="info-message error">રિપોર્ટ ડેટા લોડ કરવામાં ભૂલ થઈ.</p>';
                    runchartContainer.style.display = 'none'; // Hide runchart on error
                });
        }

        // Function to create individual runcharts for each parameter
        function createRunchart(reportData, uniqueParameters) {
            const runchartContainer = document.getElementById('runchart_container');

            // Clear previous charts and their containers
            for (const chartId in inProcessChartInstances) {
                if (inProcessChartInstances[chartId]) {
                    inProcessChartInstances[chartId].destroy();
                }
            }
            inProcessChartInstances = {}; // Reset the object
            runchartContainer.innerHTML = ''; // Clear the container of old canvases

            if (uniqueParameters.length === 0) {
                runchartContainer.innerHTML = '<p>ચાર્ટ બનાવવા માટે કોઈ પેરામીટર ડેટા ઉપલબ્ધ નથી.</p>';
                return;
            }

            // Extract all unique measurement dates/times once for consistent X-axis
            const allMeasurementDates = [...new Set(reportData.map(d => d.measurement_date))].sort();
            const labels = allMeasurementDates.map(dateStr => {
                // Format time for chart labels (e.g., 10:00 AM)
                return new Date(dateStr).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
            });

            uniqueParameters.forEach(param => {
                // Create a new canvas for each parameter
                const chartId = `chart_${param.parameter_id}`;
                const chartTitle = `રનચાર્ટ: ${escapeHtml(param.parameter_name)}`; // Chart title based on parameter name

                const paramChartDiv = document.createElement('div');
                paramChartDiv.style.marginBottom = '30px'; // Add some spacing between charts
                paramChartDiv.innerHTML = `<h4>${chartTitle}</h4><canvas id="${chartId}"></canvas>`;
                runchartContainer.appendChild(paramChartDiv);

                const ctx = document.getElementById(chartId).getContext('2d');

                const measuredData = [];
                // Use spec_positive and spec_negative to calculate limits
                const specificationValue = parseFloat(param.specification);
                const specPositive = parseFloat(param.spec_positive);
                const specNegative = parseFloat(param.spec_negative);

                let lowerSpec = null;
                let upperSpec = null;

                // Calculate LSL and USL based on specification and deviations
                if (!isNaN(specificationValue) && !isNaN(specNegative)) {
                    lowerSpec = specificationValue - specNegative;
                }
                if (!isNaN(specificationValue) && !isNaN(specPositive)) {
                    upperSpec = specificationValue + specPositive;
                }

                // Populate data points for this specific parameter across all measurement times
                allMeasurementDates.forEach(dateStr => {
                    const measurement = reportData.find(d =>
                        d.parameter_id === param.parameter_id && d.measurement_date === dateStr
                    );
                    // For runchart, use the measured_value as it represents the actual point.
                    measuredData.push(measurement ? parseFloat(measurement.measured_value) : null);
                });

                const datasets = [
                    {
                        label: `માપેલ મૂલ્ય`,
                        data: measuredData,
                        borderColor: 'rgba(75, 192, 192, 1)', // A standard color for measured value
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        fill: false,
                        tension: 0.1,
                        pointRadius: 5,
                        pointHoverRadius: 8
                    }
                ];

                // Add specification lines if available and meaningful (e.g., if spec is a number)
                if (!isNaN(specificationValue)) {
                    datasets.push({
                        label: `નોમિનલ સ્પષ્ટીકરણ`,
                        data: Array(labels.length).fill(specificationValue),
                        borderColor: 'rgba(0, 0, 255, 0.7)', // Blue for nominal spec
                        borderDash: [5, 5],
                        fill: false,
                        pointRadius: 0
                    });
                }
                if (lowerSpec !== null && !isNaN(lowerSpec)) {
                     datasets.push({
                        label: `નીચી મર્યાદા (LSL)`,
                        data: Array(labels.length).fill(lowerSpec),
                        borderColor: 'rgba(255, 0, 0, 0.7)', // Red for lower spec limit
                        borderDash: [5, 5],
                        fill: false,
                        pointRadius: 0
                    });
                }
                if (upperSpec !== null && !isNaN(upperSpec)) {
                    datasets.push({
                        label: `ઉચ્ચ મર્યાદા (USL)`,
                        data: Array(labels.length).fill(upperSpec),
                        borderColor: 'rgba(255, 0, 0, 0.7)', // Red for upper spec limit
                        borderDash: [5, 5],
                        fill: false,
                        pointRadius: 0
                    });
                }

                // Create the chart for the current parameter
                inProcessChartInstances[chartId] = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: datasets
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            title: {
                                display: true,
                                text: chartTitle
                            },
                            tooltip: {
                                mode: 'index',
                                intersect: false,
                            }
                        },
                        scales: {
                            x: {
                                title: {
                                    display: true,
                                    text: 'માપનનો સમય'
                                }
                            },
                            y: {
                                title: {
                                    display: true,
                                    text: 'માપેલ મૂલ્ય (mm)' // Assuming mm, adjust as needed
                                }
                            }
                        }
                    }
                });
            });
        }

        // Initial load of setups when the page loads
        document.addEventListener('DOMContentLoaded', loadSetups);
    </script>
</body>
</html>