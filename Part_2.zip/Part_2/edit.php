<?php
    session_start();

    // Check karo ke user logged in chhe ke nahi.
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        // Jo logged in nathi, to login page par redirect karo.
        header("location: login.php");
        exit;
    }
?>
<?php
include('db_connection.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM production WHERE id = '$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    // બીજો ડેટાબેઝ કનેક્ટ કરો (dasp)
    $conn2 = new mysqli("localhost", "root", "", "dasp");

    // જો બીજા ડેટાબેઝ કનેક્શનમાં કોઈ ભૂલ હોય તો ચેક કરો
    if ($conn2->connect_error) {
        die("Machine Data ડેટાબેઝ કનેક્શન નિષ્ફળ થયું: " . $conn2->connect_error);
    }

    // ડ્રોપડાઉન માટે ડેટા મેળવો
    $sql_customers = "SELECT DISTINCT `Customer` FROM `data_for_phpmyadmin` ORDER BY `Customer`";
    $result_customers = $conn2->query($sql_customers);

    $sql_machines = "SELECT DISTINCT `Machine Number` FROM `data_for_phpmyadmin` ORDER BY `Machine Number`";
    $result_machines = $conn2->query($sql_machines);

    $sql_setters = "SELECT DISTINCT `Setter Name` FROM `data_for_phpmyadmin` ORDER BY `Setter Name`";
    $result_setters = $conn2->query($sql_setters);

    $sql_operators = "SELECT DISTINCT `Operator Name` FROM `data_for_phpmyadmin` ORDER BY `Operator Name`";
    $result_operators = $conn2->query($sql_operators);

    $sql_ref_numbers = "SELECT DISTINCT `Ref Number` FROM `data_for_phpmyadmin` ORDER BY `Ref Number`";
    $result_ref_numbers = $conn2->query($sql_ref_numbers);

    $sql_grades = "SELECT DISTINCT `Grade` FROM `data_for_phpmyadmin` ORDER BY `Grade`";
    $result_grades = $conn2->query($sql_grades);

    $sql_breakdown_lists = "SELECT DISTINCT `Breakdown List` FROM `data_for_phpmyadmin` ORDER BY `Breakdown List`";
    $result_breakdown_lists = $conn2->query($sql_breakdown_lists);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Record</title>
<meta charset="UTF-8">
    <title>Machine Stop Log</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #e0eafc, #cfdef3);
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      min-height: 100vh;
    }

    .container {
      background: #fff;
      margin-top: 40px;
      padding: 30px 40px;
      border-radius: 15px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      max-width: 1300px;
      width: 95%;
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 25px;
    }

    form {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    label {
      font-weight: 500;
      margin-bottom: 6px;
      display: block;
      color: #34495e;
    }

    input, select {
      width: 100%;
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 14px;
    }

    .full-width {
      grid-column: 1 / -1;
    }

    .row {
      display: flex;
      gap: 10px;
    }

    .row input {
      flex: 1;
    }

    button {
      background-color: #3498db;
      color: #fff;
      border: none;
      padding: 12px 20px;
      font-size: 16px;
      font-weight: bold;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s;
      margin-top: 5px;
    }

    button:hover {
      background-color: #2980b9;
    }

    @media (max-width: 600px) {
      .row {
        flex-direction: column;
      }
    }
  </style>
</head>
<body>
 <div class="container">
    <h2>Edit Record</h2>
    <form method="post" action="update.php">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <label>Date:
            <input type="date" name="date" value="<?php echo $row['date']; ?>" readonly>
        </label>

        <label>Shift:
            <input type="text" name="shift" value="<?php echo $row['shift']; ?>" readonly>
        </label>

        <label>Shift Start Time:
            <input type="time" name="shift_start_time" value="<?php echo $row['shift_start_time']; ?>" id="start_time" oninput="calculateTargetProduction()">
        </label>

        <label>Shift End Time:
            <input type="time" name="shift_end_time" value="<?php echo $row['shift_end_time']; ?>" id="end_time" oninput="calculateTargetProduction()">
        </label>

        <label>Customer:
            <select name="customer">
                <?php
                if ($result_customers->num_rows > 0) {
                    while ($row_customer = $result_customers->fetch_assoc()) {
                        $selected = ($row['customer'] == $row_customer['Customer']) ? 'selected' : '';
                        echo '<option value="' . $row_customer['Customer'] . '" ' . $selected . '>' . $row_customer['Customer'] . '</option>';
                    }
                } else {
                    echo '<option value="">કોઈ ગ્રાહકો મળ્યા નથી</option>';
                }
                ?>
            </select>
        </label>

        <label>Machine Number:
            <select name="machine_number">
                <?php
                if ($result_machines->num_rows > 0) {
                    while ($row_machine = $result_machines->fetch_assoc()) {
                        $selected = ($row['machine_number'] == $row_machine['Machine Number']) ? 'selected' : '';
                        echo '<option value="' . $row_machine['Machine Number'] . '" ' . $selected . '>' . $row_machine['Machine Number'] . '</option>';
                    }
                } else {
                    echo '<option value="">કોઈ મશીન મળ્યા નથી</option>';
                }
                ?>
            </select>
        </label>

        <label>Setup:
            <input type="text" name="setup" value="<?php echo $row['setup']; ?>" >
        </label>

        <label>Cycle Time Mintus:
            <input type="text" name="cycle_minutes" value="<?php echo $row['cycle_minutes']; ?>" id="cycle_minutes" oninput="calculateTargetProduction()">
        </label>

        <label>Cycle Time Second:
            <input type="text" name="cycle_seconds" value="<?php echo $row['cycle_seconds']; ?>" id="cycle_seconds" oninput="calculateTargetProduction()">
        </label>

        <label>Loding Time Second:
            <input type="text" name="loading_time" value="<?php echo $row['loading_time']; ?>" id="loading_time" oninput="calculateTargetProduction()">
        </label>

        <label>Hourly Target:
            <input type="text" name="hourly_target" value="<?php echo $row['hourly_target']; ?>" id="hourly_target" readonly>
        </label>

        <label>Shift Target:
            <input type="text" name="shift_target" value="<?php echo $row['shift_target']; ?>" id="shift_target" readonly>
        </label>

        <label>Setter Name:
            <select name="setter_name">
                <?php
                if ($result_setters->num_rows > 0) {
                    while ($row_setter = $result_setters->fetch_assoc()) {
                        $selected = ($row['setter_name'] == $row_setter['Setter Name']) ? 'selected' : '';
                        echo '<option value="' . $row_setter['Setter Name'] . '" ' . $selected . '>' . $row_setter['Setter Name'] . '</option>';
                    }
                } else {
                    echo '<option value="">કોઈ સેટર મળ્યા નથી</option>';
                }
                ?>
            </select>
        </label>

        <label>Operator Name:
            <select name="operator_name">
                <?php
                if ($result_operators->num_rows > 0) {
                    while ($row_operator = $result_operators->fetch_assoc()) {
                        $selected = ($row['operator_name'] == $row_operator['Operator Name']) ? 'selected' : '';
                        echo '<option value="' . $row_operator['Operator Name'] . '" ' . $selected . '>' . $row_operator['Operator Name'] . '</option>';
                    }
                } else {
                    echo '<option value="">કોઈ ઓપરેટર મળ્યા નથી</option>';
                }
                ?>
            </select>
        </label>

        <label>Ref Number:
            <select name="ref_number">
                <?php
                if ($result_ref_numbers->num_rows > 0) {
                    while ($row_ref_number = $result_ref_numbers->fetch_assoc()) {
                        $selected = ($row['ref_number'] == $row_ref_number['Ref Number']) ? 'selected' : '';
                        echo '<option value="' . $row_ref_number['Ref Number'] . '" ' . $selected . '>' . $row_ref_number['Ref Number'] . '</option>';
                    }
                } else {
                    echo '<option value="">કોઈ રેફ નંબર મળ્યા નથી</option>';
                }
                ?>
            </select>
        </label>

        <label>Drowing & Rev No.:
            <input type="text" name="drowing" value="<?php echo $row['drowing']; ?>" >
        </label>


        <label>Lot Number:
            <input type="text" name="lot_number" value="<?php echo $row['lot_number']; ?>" >
        </label>

        <label>Lot Qty:
            <input type="number" name="lot_qty" value="<?php echo $row['lot_qty']; ?>" >
        </label>

        <label>Heat Number:
            <input type="text" name="heat_number" value="<?php echo $row['heat_number']; ?>" >
        </label>

        <label>Grade:
            <select name="grade">
                <?php
                if ($result_grades->num_rows > 0) {
                    while ($row_grade = $result_grades->fetch_assoc()) {
                        $selected = ($row['grade'] == $row_grade['Grade']) ? 'selected' : '';
                        echo '<option value="' . $row_grade['Grade'] . '" ' . $selected . '>' . $row_grade['Grade'] . '</option>';
                    }
                } else {
                    echo '<option value="">કોઈ ગ્રેડ મળ્યા નથી</option>';
                }
                ?>
            </select>
        </label>


    <label>Part Count 1st:
    <input type="number" id="count1" name="part_count_1st" value="<?php echo $row['part_count_1st']; ?>">
</label>

<label>Part Count 2nd:
    <input type="number" id="count2" name="part_count_2nd" value="<?php echo $row['part_count_2nd']; ?>">
</label>

<label>Part Count 3rd:
    <input type="number" id="count3" name="part_count_3rd" value="<?php echo $row['part_count_3rd']; ?>">
</label>

    <label>Part Count wise Production:
    <input type="number" id="pcwp" name="pcwp" value="<?php echo $row['pcwp']; ?>" readonly>
</label>

        <label>Breakdown List:
            <select name="breakdown_list">
                <?php
                if ($result_breakdown_lists->num_rows > 0) {
                    while ($row_breakdown_list = $result_breakdown_lists->fetch_assoc()) {
                        $selected = ($row['breakdown_list'] == $row_breakdown_list['Breakdown List']) ? 'selected' : '';
                        echo '<option value="' . $row_breakdown_list['Breakdown List'] . '" ' . $selected . '>' . $row_breakdown_list['Breakdown List'] . '</option>';
                    }
                } else {
                    echo '<option value="">કોઈ બ્રેકડાઉન લિસ્ટ મળ્યા નથી</option>';
                }
                ?>
            </select>
        </label>

        <label>Breakdown Time (Minutes):
            <input type="number" name="breakdown_time" value="<?php echo $row['breakdown_time']; ?>">
        </label>

        <label>Total Production:
            <input type="number" name="total_production" value="<?php echo $row['total_production']; ?>">
        </label>

        <button type="submit">Update</button>
        
    </form>
</div>
<script>
  function calculatePCWP() {
    const c1 = parseInt(document.getElementById('count1').value) || 0;
    const c2 = parseInt(document.getElementById('count2').value) || 0;
    const c3 = parseInt(document.getElementById('count3').value) || 0;

    let result = "";

    if (c1 > 0 && c2 >= c1) {
        result = c2 - c1;
    }
    if (c3 >= c1 && c3 > c2) {
        result = c3 - c1;
    }

    document.getElementById('pcwp').value = result;
}

document.getElementById('count1').addEventListener('input', calculatePCWP);
document.getElementById('count2').addEventListener('input', calculatePCWP);
document.getElementById('count3').addEventListener('input', calculatePCWP);

  document.getElementById('count1').addEventListener('input', calculatePCWP);
  document.getElementById('count2').addEventListener('input', calculatePCWP);
  document.getElementById('count3').addEventListener('input', calculatePCWP);

  function calculateTargetProduction() {
    const min = parseInt(document.getElementById('cycle_minutes').value) || 0;
    const sec = parseInt(document.getElementById('cycle_seconds').value) || 0;
    const loading = parseInt(document.getElementById('loading_time').value) || 0;

    const totalSec = (min * 60) + sec + loading;

    let hourly = 0; // પ્રારંભિક વેલ્યુ 0 સેટ કરો
    if (totalSec > 0) { // જો ટોટલ સેકન્ડ 0 થી વધારે હોય તો જ ગણતરી કરો
        hourly = Math.floor(3600 / totalSec);
    }
    document.getElementById('hourly_target').value = hourly;

    const start = document.getElementById('start_time').value;
    const end = document.getElementById('end_time').value;

    let shiftTarget = 0; // પ્રારંભિક વેલ્યુ 0 સેટ કરો
    if (start && end) {
        const startDate = new Date("01/01/2022 " + start);
        const endDate = new Date("01/01/2022 " + end);
        let diff = (endDate - startDate) / (1000 * 60 * 60);
        if (diff <= 0) diff += 24;
        shiftTarget = diff * hourly;
    }
    document.getElementById('shift_target').value = shiftTarget;
}
</script>
</body>
</html>

<?php
}
?>