<?php
include('db_connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $date = $_POST['date'];
    $shift = $_POST['shift'];
    $shift_start_time = $_POST['shift_start_time'];
    $shift_end_time = $_POST['shift_end_time'];
    $customer = $_POST['customer'];
    $machine_number = $_POST['machine_number'];
    $setup = $_POST['setup'];
    $cycle_minutes = $_POST['cycle_minutes'];
    $cycle_seconds = $_POST['cycle_seconds'];
    $loading_time = $_POST['loading_time'];
    $hourly_target = $_POST['hourly_target'];
    $shift_target = $_POST['shift_target'];
    $setter_name = $_POST['setter_name'];
    $operator_name = $_POST['operator_name'];
    $ref_number = $_POST['ref_number'];
    $drowing = $_POST['drowing'];
    $lot_number = $_POST['lot_number'];
    $lot_qty = $_POST['lot_qty'];
    $heat_number = $_POST['heat_number'];
    $grade = $_POST['grade'];
    $part_count_1st = $_POST['part_count_1st'];
    $part_count_2nd = $_POST['part_count_2nd'];
    $part_count_3rd = $_POST['part_count_3rd'];
    $pcwp = $_POST['pcwp'];
    $breakdown_list = $_POST['breakdown_list'];
    $breakdown_time = $_POST['breakdown_time'];
    $total_production = $_POST['total_production'];

    $sql = "UPDATE production SET
		customer='$customer',
        machine_number='$machine_number',
        setup='$setup',
        cycle_minutes='$cycle_minutes',
        cycle_seconds='$cycle_seconds',
        loading_time='$loading_time',
        
        setter_name='$setter_name',
        operator_name='$operator_name',
        ref_number='$ref_number',
        drowing='$drowing',
        lot_number='$lot_number',
        lot_qty='$lot_qty',
        heat_number='$heat_number',
        grade='$grade',
        part_count_1st='$part_count_1st',
        part_count_2nd='$part_count_2nd',
        part_count_3rd='$part_count_3rd',
        
        breakdown_list='$breakdown_list',
        breakdown_time='$breakdown_time',
        total_production='$total_production'
        WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        // ✅ Redirect with all filter parameters
        $redirect_url = "search.php?";
        if (isset($_POST['date']) && !empty($_POST['date'])) {
            $redirect_url .= "date_filter=" . urlencode($_POST['date']) . "&";
        }
        if (isset($_POST['shift']) && !empty($_POST['shift'])) {
            $redirect_url .= "shift_filter=" . urlencode($_POST['shift']) . "&";
        }
        if (isset($_POST['customer']) && !empty($_POST['customer'])) {
            $redirect_url .= "customer_filter=" . urlencode($_POST['customer']) . "&";
        }
        if (isset($_POST['ref_number']) && !empty($_POST['ref_number'])) {
            $redirect_url .= "ref_number_filter=" . urlencode($_POST['ref_number']) . "&";
        }
        if (isset($_POST['lot_number']) && !empty($_POST['lot_number'])) {
            $redirect_url .= "lot_number_filter=" . urlencode($_POST['lot_number']) . "&";
        }
        if (isset($_POST['setup']) && !empty($_POST['setup'])) {
            $redirect_url .= "setup_filter=" . urlencode($_POST['setup']) . "&";
        }
        if (isset($_POST['setter_name']) && !empty($_POST['setter_name'])) {
            $redirect_url .= "setter_name_filter=" . urlencode($_POST['setter_name']) . "&";
        }
        if (isset($_POST['operator_name']) && !empty($_POST['operator_name'])) {
            $redirect_url .= "operator_name_filter=" . urlencode($_POST['operator_name']) . "&";
        }

        // Remove the trailing "&" if it exists
        $redirect_url = rtrim($redirect_url, "&");

        header("Location: " . $redirect_url);
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $conn->close();
}
?>