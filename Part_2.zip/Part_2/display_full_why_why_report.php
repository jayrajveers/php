<?php
// Database connection parameters - **UPDATE THESE WITH YOUR ACTUAL DETAILS**
$servername = "localhost"; // Replace with your database server name
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "dasp"; // Replace with your database name

$conn = null; // Initialize connection variable
$report = null;
$whys = [];

if (isset($_GET['id'])) {
    $report_id = htmlspecialchars($_GET['id']);

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

        // Fetch main report details
        $stmt_report = $conn->prepare("SELECT * FROM why_why_analysis_records WHERE id = :id");
        $stmt_report->bindParam(':id', $report_id, PDO::PARAM_INT);
        $stmt_report->execute();
        $report = $stmt_report->fetch();

        if ($report) {
            // Fetch 'Why' reasons for this report
            $stmt_whys = $conn->prepare("SELECT why_text FROM why_reasons WHERE analysis_record_id = :analysis_record_id ORDER BY why_order ASC");
            $stmt_whys->bindParam(':analysis_record_id', $report_id, PDO::PARAM_INT);
            $stmt_whys->execute();
            $whys = $stmt_whys->fetchAll(PDO::FETCH_COLUMN); // Fetch just the column values
        }

    } catch (PDOException $e) {
        echo "<p style='color: red;'>ડેટાબેઝ ભૂલ: " . $e->getMessage() . "</p>";
    } finally {
        if ($conn) {
            $conn = null; // Close the database connection
        }
    }
}
?>
<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Why-Why Analysis Report Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f8f9fa;
            color: #333;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            max-width: 900px;
            margin: auto;
            border-top: 5px solid #007bff;
        }
        h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 25px;
            font-size: 2.2em;
        }
        h3 {
            color: #0056b3;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-top: 30px;
            margin-bottom: 20px;
        }
        p {
            margin-bottom: 10px;
            line-height: 1.6;
        }
        strong {
            color: #555;
        }
        .detail-group {
            margin-bottom: 15px;
            background-color: #f9f9f9;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #eee;
        }
        .detail-group p:last-child {
            margin-bottom: 0;
        }
        ol {
            margin-left: 20px;
            padding-left: 0;
        }
        li {
            margin-bottom: 5px;
        }
        .back-button {
            display: inline-block;
            background-color: #6c757d;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 30px;
            transition: background-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #5a6268;
        }
        .error-message {
            color: red;
            text-align: center;
            font-size: 1.1em;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if ($report): ?>
            <h2>Why-Why Analysis રિપોર્ટ વિગતો (ID: <?php echo htmlspecialchars($report['id']); ?>)</h2>

            <h3>સામાન્ય માહિતી</h3>
            <div class="detail-group">
                <p><strong>એનાલિસિસ તારીખ:</strong> <?php echo htmlspecialchars($report['analysis_date']); ?></p>
                <p><strong>મશીન ID:</strong> <?php echo htmlspecialchars($report['machine_id']); ?></p>
                <p><strong>પાર્ટનું નામ / જોબ ID:</strong> <?php echo htmlspecialchars($report['part_name']); ?></p>
                <p><strong>ભર્યું તારીખ-સમય:</strong> <?php echo htmlspecialchars($report['created_at']); ?></p>
            </div>

            <h3>સમસ્યા/બિન-અનુરૂપતાનું વર્ણન</h3>
            <div class="detail-group">
                <p><strong>મુખ્ય સમસ્યાનું સંક્ષિપ્ત વર્ણન:</strong> <?php echo nl2br(htmlspecialchars($report['problem_statement'])); ?></p>
                <p><strong>શું થયું?:</strong> <?php echo nl2br(htmlspecialchars($report['what_happened'] ?? 'N/A')); ?></p>
                <p><strong>ક્યાં થયું?:</strong> <?php echo htmlspecialchars($report['where_happened'] ?? 'N/A'); ?></p>
                <p><strong>ક્યારે થયું?:</strong> <?php echo htmlspecialchars($report['when_happened'] ?? 'N/A'); ?></p>
                <p><strong>કોણે શોધ્યું?:</strong> <?php echo htmlspecialchars($report['who_found'] ?? 'N/A'); ?></p>
                <p><strong>કેટલું થયું?:</strong> <?php echo htmlspecialchars($report['how_much_impact'] ?? 'N/A'); ?></p>
                <p><strong>ગ્રાહક પર સંભવિત અસર:</strong> <?php echo nl2br(htmlspecialchars($report['customer_impact'] ?? 'N/A')); ?></p>
            </div>

            <h3>કન્ટેઈનમેન્ટ એક્શન</h3>
            <div class="detail-group">
                <p><strong>તાત્કાલિક લેવાયેલા પગલાં:</strong> <?php echo nl2br(htmlspecialchars($report['containment_action'] ?? 'N/A')); ?></p>
                <p><strong>અસરકારકતા ચકાસવામાં આવી?:</strong> <?php echo ($report['containment_effectiveness_verified'] ? 'હા' : 'ના'); ?></p>
                <p><strong>ચકાસણી કરનાર વ્યક્તિ:</strong> <?php echo htmlspecialchars($report['containment_verified_by'] ?? 'N/A'); ?></p>
                <p><strong>ચકાસણી તારીખ:</strong> <?php echo htmlspecialchars($report['containment_verification_date'] ?? 'N/A'); ?></p>
            </div>

            <h3>ક્રોસ-ફંક્શનલ ટીમ</h3>
            <div class="detail-group">
                <p><strong>ટીમ લીડર:</strong> <?php echo htmlspecialchars($report['team_leader'] ?? 'N/A'); ?></p>
                <?php
                // For team members, if you stored them as a comma-separated string in the main table, display here.
                // If you created a separate table for team members, you'd fetch and display them here.
                // For this example, assuming 'team_members' string is part of the main record or omitted.
                // If you added 'team_members_str' to the main table, you can display it like:
                // <p><strong>ટીમ સભ્યો:</strong> <?php echo htmlspecialchars($report['team_members_str'] ?? 'N/A'); </p>
                ?>
            </div>

            <h3>શા માટે? (Why?) - મૂળ કારણ વિશ્લેષણ</h3>
            <div class="detail-group">
                <?php if (!empty($whys)): ?>
                    <ol>
                        <?php foreach ($whys as $why_reason): ?>
                            <li><?php echo nl2br(htmlspecialchars($why_reason)); ?></li>
                        <?php endforeach; ?>
                    </ol>
                <?php else: ?>
                    <p>કોઈ 'શા માટે' કારણો દાખલ કરવામાં આવ્યા નથી.</p>
                <?php endif; ?>
                <p><strong>ઓળખાયેલ મૂળ કારણ:</strong> <?php echo nl2br(htmlspecialchars($report['root_cause'] ?? 'N/A')); ?></p>
            </div>

            <h3>કરેક્ટિવ અને પ્રિવેન્ટિવ એક્શન</h3>
            <div class="detail-group">
                <p><strong>કરેક્ટિવ એક્શન:</strong> <?php echo nl2br(htmlspecialchars($report['corrective_action'] ?? 'N/A')); ?></p>
                <p><strong>CA માટે જવાબદાર વ્યક્તિ:</strong> <?php echo htmlspecialchars($report['ca_responsible_person'] ?? 'N/A'); ?></p>
                <p><strong>CA પૂર્ણ કરવાની લક્ષ્ય તારીખ:</strong> <?php echo htmlspecialchars($report['ca_target_date'] ?? 'N/A'); ?></p>
                <p><strong>પ્રિવેન્ટિવ એક્શન:</strong> <?php echo nl2br(htmlspecialchars($report['preventive_action'] ?? 'N/A')); ?></p>
                <p><strong>PA માટે જવાબદાર વ્યક્તિ:</strong> <?php echo htmlspecialchars($report['pa_responsible_person'] ?? 'N/A'); ?></p>
                <p><strong>PA પૂર્ણ કરવાની લક્ષ્ય તારીખ:</strong> <?php echo htmlspecialchars($report['pa_target_date'] ?? 'N/A'); ?></p>
                <p><strong>અપડેટ થયેલ સિસ્ટમ દસ્તાવેજો:</strong> <?php echo nl2br(htmlspecialchars($report['system_documents_updated'] ?? 'N/A')); ?></p>
            </div>

            <h3>અસરકારકતાની ચકાસણી</h3>
            <div class="detail-group">
                <p><strong>ચકાસણીની પદ્ધતિ:</strong> <?php echo nl2br(htmlspecialchars($report['verification_method'] ?? 'N/A')); ?></p>
                <p><strong>ચકાસણીની તારીખ:</strong> <?php echo htmlspecialchars($report['verification_date'] ?? 'N/A'); ?></p>
                <p><strong>ચકાસણીના પરિણામો:</strong> <?php echo nl2br(htmlspecialchars($report['verification_results'] ?? 'N/A')); ?></p>
                <p><strong>ચકાસણી કરનાર વ્યક્તિ:</strong> <?php echo htmlspecialchars($report['verified_by'] ?? 'N/A'); ?></p>
            </div>

            <h3>શીખેલા પાઠ</h3>
            <div class="detail-group">
                <p><strong>શીખેલા પાઠનો સારાંશ:</strong> <?php echo nl2br(htmlspecialchars($report['lessons_learned'] ?? 'N/A')); ?></p>
            </div>

            <a href="view_why_why_reports.php" class="back-button">બધા રિપોર્ટ્સ પર પાછા જાઓ</a>

        <?php else: ?>
            <p class="error-message">માફ કરશો, આ ID માટે કોઈ રિપોર્ટ મળ્યો નથી.</p>
            <a href="view_why_why_reports.php" class="back-button">બધા રિપોર્ટ્સ પર પાછા જાઓ</a>
        <?php endif; ?>
    </div>
</body>
</html>