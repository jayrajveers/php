<?php
    session_start();

    // Check karo ke user logged in chhe ke nahi.
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        // Jo logged in nathi, to login page par redirect karo.
        header("location: login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Rejection Data</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        /* તમારી CSS અહીં (form.php માં આપેલી CSS જેવી જ) */
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #e0eafc, #cfdef3);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
        }

        .container {
            background: #fff;
            margin-top: 40px;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            max-width: 1280px;
            width: 95%;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 25px;
        }

        form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        label {
            font-weight: 500;
            margin-bottom: 6px;
            display: block;
            color: #34495e;
        }

        input, select {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        .full-width {
            grid-column: 1 / -1;
        }

        .row {
            display: flex;
            gap: 10px;
        }

        .row input {
            flex: 1;
        }

        button {
            background-color: #3498db;
            color: #fff;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s;
            margin-top: 15px;
        }

        button:hover {
            background-color: #2980b9;
        }

        .back-button {
            background-color: #7f8c8d;
            color: #fff;
            border: none;
            padding: 10px 15px;
            font-size: 14px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            margin-top: 10px;
            display: inline-block;
        }

        .back-button:hover {
            background-color: #616a6b;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Rejection Data</h2>
    <?php
        // ડેટાબેઝ કનેક્શનની માહિતી (get_rejection_data.php જેવી જ)
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "productiondata";

        // કનેક્શન બનાવો
        $conn = new mysqli($servername, $username, $password, $dbname);

        // કનેક્શન તપાસો
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // GET પદ્ધતિથી id મેળવો
        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            // id દ્વારા રેકોર્ડ પસંદ કરો
            $sql = "SELECT * FROM rejectiondata WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                ?>
                <form action="update_rejection_data.php" method="post">
					<input type="hidden" name="id" value="<?php echo $row['ID']; ?>">
					<label>Date: <input type="text" name="Date" id="EntryDate" value="<?php echo $row['EntryDate']; ?>" readonly></label>
					<label>Shift: <input type="text" name="Shift" id="Shift" value="<?php echo $row['Shift']; ?>"readonly></label>
					<label>Machine Number: <input type="text" name="MachineNumber" id="MachineNumber" value="<?php echo $row['MachineNumber']; ?>"readonly></label>
					<label>Part Code: <input type="text" name="ref_number" id="ref_number" value="<?php echo $row['PartCode']; ?>" readonly></label>
                    <label>Lot Number: <input type="text" name="lot_number" id="lot_number" value="<?php echo $row['lot_number']; ?>" readonly></label>
                    <label>Operator: <input type="text" name="operator_name" id="operator_name" value="<?php echo $row['Operator']; ?>" readonly></label>
                    <label>Setter: <input type="text" name="setter" id="setter" value="<?php echo $row['Setter']; ?>" readonly></label>
                    <div class = "full-width">
                        <h3>Forging Section</h3>
                    </div>
                    <label>OD UNFILL: <input type="number" name="FORGING_OD_UNFILL" value="<?php echo $row['FORGING_OD_UNFILL']; ?>"></label>
                    <label>OD LAPING: <input type="number" name="FORGING_OD_LAPING" value="<?php echo $row['FORGING_OD_LAPING']; ?>"></label>
                    <label>OD CRAKE: <input type="number" name="FORGING_OD_CRAKE" value="<?php echo $row['FORGING_OD_CRAKE']; ?>"></label>
                    <label>ID UNFILL: <input type="number" name="FORGING_BORE_UNFILL" value="<?php echo $row['FORGING_BORE_UNFILL']; ?>"></label>
                    <label>ID LAPING: <input type="number" name="FORGING_BORE_LAPING" value="<?php echo $row['FORGING_BORE_LAPING']; ?>"></label>
                    <label>ID CRAKE: <input type="number" name="FORGING_BORE_CRAKE" value="<?php echo $row['FORGING_BORE_CRAKE']; ?>"></label>
                    <label>FACE UNFILL: <input type="number" name="FORGING_WIDTH_UNFILL" value="<?php echo $row['FORGING_WIDTH_UNFILL']; ?>"></label>
                    <label>FACE LAPING: <input type="number" name="FORGING_WIDTH_LAPING" value="<?php echo $row['FORGING_WIDTH_LAPING']; ?>"></label>
                    <label>FACE CRAKE: <input type="number" name="FORGING_WIDTH_CRAKE" value="<?php echo $row['FORGING_WIDTH_CRAKE']; ?>"></label>
                    <label>TRACK UNFILL: <input type="number" name="FORGING_TRACK_UNFILL" value="<?php echo $row['FORGING_TRACK_UNFILL']; ?>"></label>
                    <label>TRACK LAPING: <input type="number" name="FORGING_TRACK_LAPING" value="<?php echo $row['FORGING_TRACK_LAPING']; ?>"></label>
                    <label>TRACK CARKE: <input type="number" name="FORGING_TRACK_CARKE" value="<?php echo $row['FORGING_TRACK_CARKE']; ?>"></label>
                    <div class = "full-width">  <h3>Inhouse & Vendor</h3> </div>
                    <label>INHOUSE: <input type="number" name="INHOUSE" value="<?php echo $row['INHOUSE']; ?>"></label>
                    <label>Vendor Name: <input type="text" name="VendorName" value="<?php echo $row['VendorName']; ?>"></label>
                    <label>Vendor nos: <input type="number" name="Vendornos" value="<?php echo $row['vendor_nos']; ?>"></label>
                    <div class = "full-width">  <h3>CNC Section</h3> </div>
                    <label>WIDTH: <input type="number" name="CNC_WIDTH" value="<?php echo $row['CNC_WIDTH']; ?>"></label>
                    <label>ID: <input type="number" name="CNC_ID" value="<?php echo $row['CNC_ID']; ?>"></label>
                    <label>OD: <input type="number" name="CNC_OD" value="<?php echo $row['CNC_OD']; ?>"></label>
                    <label>TRACK: <input type="number" name="CNC_TRACK" value="<?php echo $row['CNC_TRACK']; ?>"></label>
                    <label>LOCATION: <input type="number" name="CNC_LOCATION" value="<?php echo $row['CNC_LOCATION']; ?>"></label>
                    <label>LOADING MISTAKE: <input type="number" name="CNC_LOADING_MISTAKE" value="<?php echo $row['CNC_LOADING_MISTAKE']; ?>"></label>
                    <label>GROOVE: <input type="number" name="CNC_GROOVE" value="<?php echo $row['CNC_GROOVE']; ?>"></label>
                    <label>SETTING: <input type="number" name="CNC_SETTING" value="<?php echo $row['CNC_SETTING']; ?>"></label>
                    <label>OTHER: <input type="number" name="CNC_OTHER" value="<?php echo $row['CNC_OTHER']; ?>"></label>
                    <div class = "full-width">  <h3>Total</h3> </div>
                    <label>FORGING TOTAL: <input type="number" name="FORGING_TOTAL" value="<?php echo $row['FORGING_TOTAL']; ?>" readonly></label>
                    <label>CNC Total: <input type="number" name="CNC_Total" value="<?php echo $row['CNC_Total']; ?>" readonly></label>
                    <label>VENDOR TOTAL: <input type="number" name="VENDOR_TOTAL" value="<?php echo $row['VENDOR_TOTAL']; ?>" readonly></label>
                    <label>TOTAL: <input type="number" name="TOTAL" value="<?php echo $row['TOTAL']; ?>" readonly></label>
					<div class = "full-width">  
                    <button type="submit">Update Data</button>
                    <a href="rejection_data.php" class="back-button">Back to Records</a>
					</div>
                </form>
                <script>
                    function calculateTotals() {
                        // FORGING SECTION TOTAL
                        let forgingFields = [
                            "FORGING_OD_UNFILL", "FORGING_OD_LAPING", "FORGING_OD_CRAKE",
                            "FORGING_BORE_UNFILL", "FORGING_BORE_LAPING", "FORGING_BORE_CRAKE",
                            "FORGING_WIDTH_UNFILL", "FORGING_WIDTH_LAPING", "FORGING_WIDTH_CRAKE",
                            "FORGING_TRACK_UNFILL", "FORGING_TRACK_LAPING", "FORGING_TRACK_CARKE"
                        ];
                        let forgingTotal = forgingFields.reduce((sum, field) => {
                            return sum + (parseInt(document.getElementsByName(field)[0].value) || 0);
                        }, 0);
                        document.getElementsByName("FORGING_TOTAL")[0].value = forgingTotal;

                        // CNC SECTION TOTAL
                        let cncFields = [
                            "CNC_WIDTH", "CNC_ID", "CNC_OD", "CNC_TRACK",
                            "CNC_LOCATION", "CNC_LOADING_MISTAKE", "CNC_GROOVE",
                            "CNC_SETTING", "CNC_OTHER"
                        ];
                        let cncTotal = cncFields.reduce((sum, field) => {
                            return sum + (parseInt(document.getElementsByName(field)[0].value) || 0);
                        }, 0);
                        document.getElementsByName("CNC_Total")[0].value = cncTotal;

                        // VENDOR TOTAL (INHOUSE + Vendornos)
                        let inhouse = parseInt(document.getElementsByName("INHOUSE")[0].value) || 0;
                        let vendorNos = parseInt(document.getElementsByName("Vendornos")[0].value) || 0;
                        let vendorTotal = inhouse + vendorNos;
                        document.getElementsByName("VENDOR_TOTAL")[0].value = vendorTotal;

                        // FINAL TOTAL
                        let finalTotal = forgingTotal + cncTotal + vendorTotal;
                        document.getElementsByName("TOTAL")[0].value = finalTotal;
                    }

                    // Auto-update totals when any input changes
                    document.querySelectorAll('input[type="number"]').forEach(input => {
                        input.addEventListener('input', calculateTotals);
                    });

                    // પ્રારંભિક ગણતરી
                    calculateTotals();
                </script>
                <?php
            } else {
                echo "<p>No record found with the given id.</p>";
            }
            $stmt->close();
        } else {
            echo "<p>Invalid request. Please provide an id to edit.</p>";
        }

        $conn->close();
    ?>
</div>

</body>
</html>