<?php
// તમે અહીં સેશન શરૂ કરી શકો છો અથવા અન્ય કોઈ PHP લોજિક ઉમેરી શકો છો
// session_start();
// જો યુઝર લોગ ઇન ન હોય તો રીડાયરેક્ટ કરી શકાય છે.
?>
<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CNC Department - ERP ડેશબોર્ડ</title>
    <link rel="stylesheet" href="inprocess_report_entry.css"> <style>
        /* General Body and Layout */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; /* SAP-like font */
            margin: 0;
            padding: 0;
            background-color: var(--erp-background-color);
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }

        /* Header */
        .header {
            background-color: var(--erp-primary-color);
            color: #ffffff;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 4px var(--erp-shadow-color);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .header .logo {
            height: 40px; /* Adjust logo size */
            margin-right: 15px;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }

        /* Main Container for Sidebar and Content */
        .main-container {
            display: flex;
            flex: 1;
            width: 100%;
        }

        /* Sidebar Navigation */
        .sidebar {
            width: 250px;
            background-color: var(--erp-card-background);
            box-shadow: 2px 0 5px var(--erp-shadow-color);
            padding-top: 20px;
            flex-shrink: 0; /* Prevent sidebar from shrinking */
        }
        .sidebar h3 {
            color: var(--erp-primary-color);
            text-align: center;
            margin-bottom: 20px;
            padding: 0 15px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 5px;
        }
        .sidebar ul li a {
            display: block;
            padding: 12px 20px;
            color: var(--erp-text-color);
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.3s ease, color 0.3s ease;
            border-left: 5px solid transparent;
        }
        .sidebar ul li a:hover,
        .sidebar ul li a.active {
            background-color: var(--erp-primary-color);
            color: #ffffff;
            border-left-color: var(--erp-accent-color);
        }

        /* Dropdown specific styles within sidebar */
        .sidebar ul li.dropdown a {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .sidebar ul li.dropdown .dropdown-content {
            display: none;
            background-color: var(--erp-background-color); /* Lighter background for dropdown */
            min-width: 100%;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.05); /* Inner shadow for depth */
            z-index: 1;
        }

        .sidebar ul li.dropdown .dropdown-content a {
            color: var(--erp-text-color);
            padding: 10px 20px 10px 30px; /* Indent sub-items */
            text-decoration: none;
            display: block;
            text-align: left;
            font-size: 15px;
            transition: background-color 0.2s ease;
            border-left: 3px solid transparent; /* Subtle border for sub-items */
        }

        .sidebar ul li.dropdown .dropdown-content a:hover {
            background-color: var(--erp-border-color); /* Light hover for sub-items */
            color: var(--erp-primary-color);
            border-left-color: var(--erp-accent-color);
        }

        .sidebar ul li.dropdown.active > .dropdown-content {
            display: block; /* Show dropdown content if parent is active */
        }

        /* Content Area */
        .content-area {
            flex-grow: 1;
            padding: 20px;
            background-color: var(--erp-background-color);
            overflow-y: auto; /* Enable scrolling for content */
        }

        /* Dashboard-like cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            background-color: var(--erp-card-background);
            border-radius: 8px;
            box-shadow: 0 4px 8px var(--erp-shadow-color);
            padding: 25px;
            text-align: center;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            cursor: pointer;
            border-top: 5px solid var(--erp-accent-color);
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.12);
        }
        .card h2 {
            color: var(--erp-primary-color);
            margin-top: 0;
            font-size: 20px;
            margin-bottom: 15px;
        }
        .card p {
            color: var(--erp-light-text-color);
            font-size: 14px;
        }
        .card .icon {
            font-size: 40px;
            color: var(--erp-secondary-color);
            margin-bottom: 15px;
        }

        /* Footer */
        .footer {
            background-color: var(--erp-secondary-color);
            color: #ffffff;
            text-align: center;
            padding: 15px 20px;
            font-size: 14px;
            box-shadow: 0 -2px 4px var(--erp-shadow-color);
            margin-top: auto; /* Pushes footer to the bottom */
        }

        /* Basic Responsive Adjustments */
        @media (max-width: 768px) {
            .main-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                padding-top: 10px;
                box-shadow: 0 2px 5px var(--erp-shadow-color);
            }
            .sidebar ul {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }
            .sidebar ul li {
                margin: 5px;
            }
            .sidebar ul li a {
                padding: 10px 15px;
            }
            .header h1 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>CNC Department</h1>
    </div>

    <div class="main-container">
        <aside class="sidebar">
            <h3>મેનુ</h3>
            <ul>
                <li><a href="index.php">પ્રોડક્શન ક્વોલિટી ડેશબોર્ડ</a></li>
                <li class="dropdown">
                    <a href="#">&#10010; ADD</a>
                    <div class="dropdown-content">
                        <a href="form.html">ADD NEW PRODUCTION</a>
                        <a href="rejection.html">ADD NEW REJECTION</a>
                        <a href="note.php">Add Note</a>
                    </div>
                </li>
                <li class="dropdown">
                    <a href="#">&#x1F50D; VIEW</a>
                    <div class="dropdown-content">
                        <a href="search.php">PRODUCTION LIST</a>
                        <a href="rejection_data.php">REJECTION LIST</a>
                        <a href="note_search.php">NOTE LIST</a>
                        <a href="get_lot_status.php">PART STATUS</a>
                    </div>
                </li>
                <li><a href="master_file.php">પાર્ટ માસ્ટર મેનેજમેન્ટ</a></li>
                <li><a href="inprocess_report_entry.php">ઇન-પ્રોસેસ એન્ટ્રી</a></li>
                <li><a href="inprocess_report_view.php">ઇન-પ્રોસેસ રિપોર્ટ જુઓ</a></li>
                <li><a href="view_history.php">લોગ હિસ્ટરી જુઓ</a></li>
                <li class="dropdown">
                    <a href="#">LOGOUT</a>
                    <div class="dropdown-content">
                        <a href="logout.php">Logout</a>
                    </div>
                </li>
            </ul>
        </aside>

        <main class="content-area">
            <h1>CNC ડિપાર્ટમેન્ટ ડેશબોર્ડ</h1>
            <p>CNC ડિપાર્ટમેન્ટ સંબંધિત કાર્યો માટે અહીંથી નેવિગેટ કરો. નીચેના કાર્ડ્સ તમને મુખ્ય મોડ્યુલો સુધી ઝડપી પહોંચ પ્રદાન કરે છે.</p>

            <div class="dashboard-cards">
                <div class="card" onclick="window.location.href='form.html'">
                    <div class="icon">&#10010;</div>
                    <h2>નવું પ્રોડક્શન ઉમેરો</h2>
                    <p>નવી પ્રોડક્શન એન્ટ્રી દાખલ કરો.</p>
                </div>
                <div class="card" onclick="window.location.href='rejection.html'">
                    <div class="icon">&#x2716;</div> <h2>નવું રિજેક્શન ઉમેરો</h2>
                    <p>નવી રિજેક્શન એન્ટ્રી દાખલ કરો.</p>
                </div>
                <div class="card" onclick="window.location.href='note.php'">
                    <div class="icon">&#128221;</div> <h2>નોટ ઉમેરો</h2>
                    <p>મહત્વપૂર્ણ નોંધો ઉમેરો.</p>
                </div>
                <div class="card" onclick="window.location.href='search.php'">
                    <div class="icon">&#x1F50D;</div>
                    <h2>પ્રોડક્શન લિસ્ટ</h2>
                    <p>તમામ પ્રોડક્શન રેકોર્ડ્સ જુઓ.</p>
                </div>
                <div class="card" onclick="window.location.href='rejection_data.php'">
                    <div class="icon">&#128203;</div> <h2>રિજેક્શન લિસ્ટ</h2>
                    <p>તમામ રિજેક્શન રેકોર્ડ્સ જુઓ.</p>
                </div>
                <div class="card" onclick="window.location.href='note_search.php'">
                    <div class="icon">&#128214;</div> <h2>નોટ લિસ્ટ</h2>
                    <p>બધી ઉમેરેલી નોંધો જુઓ.</p>
                </div>
                <div class="card" onclick="window.location.href='get_lot_status.php'">
                    <div class="icon">&#128270;</div> <h2>પાર્ટ સ્ટેટસ</h2>
                    <p>પાર્ટના લોટનું વર્તમાન સ્ટેટસ તપાસો.</p>
                </div>
                <div class="card" onclick="window.location.href='master_file.php'">
                    <div class="icon">&#9881;</div> <h2>પાર્ટ માસ્ટર</h2>
                    <p>પાર્ટની વિગતો અને ગુણધર્મોનું સંચાલન કરો.</p>
                </div>
                <div class="card" onclick="window.location.href='inprocess_report_entry.php'">
                    <div class="icon">&#128221;</div> <h2>ઇન-પ્રોસેસ એન્ટ્રી</h2>
                    <p>ઇન-પ્રોસેસ માપન ડેટા દાખલ કરો.</p>
                </div>
                <div class="card" onclick="window.location.href='inprocess_report_view.php'">
                    <div class="icon">&#128202;</div> <h2>ઇન-પ્રોસેસ રિપોર્ટ</h2>
                    <p>ઇન-પ્રોસેસ માપન રિપોર્ટ્સ જુઓ.</p>
                </div>
                <div class="card" onclick="window.location.href='view_history.php'">
                    <div class="icon">&#128198;</div> <h2>લોગ હિસ્ટરી</h2>
                    <p>સિસ્ટમમાં થયેલા ફેરફારોની હિસ્ટરી જુઓ.</p>
                </div>
            </div>
        </main>
    </div>

    <footer class="footer">
        <p>&copy; <?php echo date("Y"); ?> CNC Department. બધા હકો સુરક્ષિત.</p>
    </footer>

    <script>
        // JavaScript for dropdown functionality and active link highlighting
        document.addEventListener('DOMContentLoaded', function() {
            const currentPath = window.location.pathname.split('/').pop();
            const sidebarLinks = document.querySelectorAll('.sidebar ul li a');
            const dropdowns = document.querySelectorAll('.sidebar .dropdown');

            // Set active class for direct links
            sidebarLinks.forEach(link => {
                if (link.getAttribute('href') === currentPath) {
                    link.classList.add('active');
                }
            });

            // Handle dropdown click to toggle visibility and active state
            dropdowns.forEach(dropdown => {
                const dropdownToggle = dropdown.querySelector('a');
                const dropdownContent = dropdown.querySelector('.dropdown-content');

                // Check if any sub-link within this dropdown is active
                let hasActiveChild = false;
                if (dropdownContent) {
                    const subLinks = dropdownContent.querySelectorAll('a');
                    subLinks.forEach(subLink => {
                        if (subLink.getAttribute('href') === currentPath) {
                            subLink.classList.add('active'); // Highlight sub-link
                            dropdown.classList.add('active'); // Activate parent dropdown
                            hasActiveChild = true;
                        }
                    });
                }
                
                // If a child is active, ensure the dropdown content is displayed
                if (hasActiveChild) {
                    dropdownContent.style.display = 'block';
                }

                // Add click listener for dropdown toggle
                dropdownToggle.addEventListener('click', function(event) {
                    event.preventDefault(); // Prevent default link behavior
                    // Toggle the 'active' class on the parent li.dropdown
                    dropdown.classList.toggle('active');
                    // Toggle display of the dropdown content
                    if (dropdownContent) {
                        dropdownContent.style.display = dropdown.classList.contains('active') ? 'block' : 'none';
                    }
                });
            });
        });
    </script>
</body>
</html>