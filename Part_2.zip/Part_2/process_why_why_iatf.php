<?php
// Database connection parameters
$servername = "localhost"; // Replace with your database server name
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "dasp"; // Replace with your database name

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Set default fetch mode to associative array
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // --- 1. Retrieve and Sanitize Form Data ---
        // General Information
        $analysis_date = $_POST['analysis_date'] ?? null;
        $machine_id = htmlspecialchars($_POST['machine_id'] ?? '');
        $part_name = htmlspecialchars($_POST['part_name'] ?? '');

        // Problem Description
        $problem_statement = htmlspecialchars($_POST['problem_statement'] ?? '');
        $what_happened = htmlspecialchars($_POST['what_happened'] ?? '');
        $where_happened = htmlspecialchars($_POST['where_happened'] ?? '');
        
        // Combine date and time for 'when_happened'
        $when_happened_date = $_POST['when_happened_date'] ?? null;
        $when_happened_time = $_POST['when_happened_time'] ?? null;
        $when_happened = null;
        if ($when_happened_date && $when_happened_time) {
            $when_happened = $when_happened_date . ' ' . $when_happened_time;
        } elseif ($when_happened_date) {
            $when_happened = $when_happened_date . ' 00:00:00'; // Default time if only date is provided
        }

        $who_found = htmlspecialchars($_POST['who_found'] ?? '');
        $how_much_impact = htmlspecialchars($_POST['how_much_impact'] ?? '');
        $customer_impact = htmlspecialchars($_POST['customer_impact'] ?? '');

        // Containment Actions
        $containment_action = htmlspecialchars($_POST['containment_action'] ?? '');
        $containment_effectiveness_verified = isset($_POST['containment_effectiveness_verified']) ? 1 : 0;
        $containment_verified_by = htmlspecialchars($_POST['containment_verified_by'] ?? '');
        $containment_verification_date = $_POST['containment_verification_date'] ?? null;

        // Cross-Functional Team (store as comma-separated string for simplicity in this example)
        $team_leader = htmlspecialchars($_POST['team_leader'] ?? '');
        $team_members = $_POST['team_members'] ?? [];
        $team_members_str = '';
        foreach ($team_members as $member) {
            if (!empty(trim($member))) {
                $team_members_str .= htmlspecialchars(trim($member)) . ', ';
            }
        }
        $team_members_str = rtrim($team_members_str, ', '); // Remove trailing comma

        // Why-Why Analysis
        $whys = $_POST['whys'] ?? []; // Array of 'why' reasons
        $root_cause = htmlspecialchars($_POST['root_cause'] ?? '');

        // Corrective & Preventive Actions
        $corrective_action = htmlspecialchars($_POST['corrective_action'] ?? '');
        $ca_responsible_person = htmlspecialchars($_POST['ca_responsible_person'] ?? '');
        $ca_target_date = $_POST['ca_target_date'] ?? null;

        $preventive_action = htmlspecialchars($_POST['preventive_action'] ?? '');
        $pa_responsible_person = htmlspecialchars($_POST['pa_responsible_person'] ?? '');
        $pa_target_date = $_POST['pa_target_date'] ?? null;
        $system_documents_updated = htmlspecialchars($_POST['system_documents_updated'] ?? '');

        // Verification of Effectiveness
        $verification_method = htmlspecialchars($_POST['verification_method'] ?? '');
        $verification_date = $_POST['verification_date'] ?? null;
        $verification_results = htmlspecialchars($_POST['verification_results'] ?? '');
        $verified_by = htmlspecialchars($_POST['verified_by'] ?? '');

        // Lessons Learned
        $lessons_learned = htmlspecialchars($_POST['lessons_learned'] ?? '');

        // --- 2. Insert Data into Database ---
        $conn->beginTransaction(); // Start transaction for atomicity

        // Insert into why_why_analysis_records table
        $stmt_main = $conn->prepare("INSERT INTO why_why_analysis_records (
            analysis_date, machine_id, part_name, problem_statement,
            what_happened, where_happened, when_happened, who_found,
            how_much_impact, customer_impact,
            containment_action, containment_effectiveness_verified, containment_verified_by, containment_verification_date,
            team_leader, root_cause,
            corrective_action, ca_responsible_person, ca_target_date,
            preventive_action, pa_responsible_person, pa_target_date, system_documents_updated,
            verification_method, verification_date, verification_results, verified_by,
            lessons_learned
        ) VALUES (
            :analysis_date, :machine_id, :part_name, :problem_statement,
            :what_happened, :where_happened, :when_happened, :who_found,
            :how_much_impact, :customer_impact,
            :containment_action, :containment_effectiveness_verified, :containment_verified_by, :containment_verification_date,
            :team_leader, :root_cause,
            :corrective_action, :ca_responsible_person, :ca_target_date,
            :preventive_action, :pa_responsible_person, :pa_target_date, :system_documents_updated,
            :verification_method, :verification_date, :verification_results, :verified_by,
            :lessons_learned
        )");

        $stmt_main->bindParam(':analysis_date', $analysis_date);
        $stmt_main->bindParam(':machine_id', $machine_id);
        $stmt_main->bindParam(':part_name', $part_name);
        $stmt_main->bindParam(':problem_statement', $problem_statement);
        $stmt_main->bindParam(':what_happened', $what_happened);
        $stmt_main->bindParam(':where_happened', $where_happened);
        $stmt_main->bindParam(':when_happened', $when_happened);
        $stmt_main->bindParam(':who_found', $who_found);
        $stmt_main->bindParam(':how_much_impact', $how_much_impact);
        $stmt_main->bindParam(':customer_impact', $customer_impact);
        $stmt_main->bindParam(':containment_action', $containment_action);
        $stmt_main->bindParam(':containment_effectiveness_verified', $containment_effectiveness_verified, PDO::PARAM_INT);
        $stmt_main->bindParam(':containment_verified_by', $containment_verified_by);
        $stmt_main->bindParam(':containment_verification_date', $containment_verification_date);
        $stmt_main->bindParam(':team_leader', $team_leader);
        $stmt_main->bindParam(':root_cause', $root_cause);
        $stmt_main->bindParam(':corrective_action', $corrective_action);
        $stmt_main->bindParam(':ca_responsible_person', $ca_responsible_person);
        $stmt_main->bindParam(':ca_target_date', $ca_target_date);
        $stmt_main->bindParam(':preventive_action', $preventive_action);
        $stmt_main->bindParam(':pa_responsible_person', $pa_responsible_person);
        $stmt_main->bindParam(':pa_target_date', $pa_target_date);
        $stmt_main->bindParam(':system_documents_updated', $system_documents_updated);
        $stmt_main->bindParam(':verification_method', $verification_method);
        $stmt_main->bindParam(':verification_date', $verification_date);
        $stmt_main->bindParam(':verification_results', $verification_results);
        $stmt_main->bindParam(':verified_by', $verified_by);
        $stmt_main->bindParam(':lessons_learned', $lessons_learned);
        
        $stmt_main->execute();
        $analysis_record_id = $conn->lastInsertId(); // Get the ID of the newly inserted record

        // Insert individual 'Why' reasons
        if (!empty($whys)) {
            $stmt_why = $conn->prepare("INSERT INTO why_reasons (analysis_record_id, why_order, why_text) VALUES (:analysis_record_id, :why_order, :why_text)");
            foreach ($whys as $index => $why_reason_val) { // Changed $why_reason to $why_reason_val
                if (!empty(trim($why_reason_val))) { // Use the new loop variable here
                    $why_order = $index + 1;
                    $sanitized_why_text = htmlspecialchars($why_reason_val); // Sanitize and assign to a new variable
                    
                    $stmt_why->bindParam(':analysis_record_id', $analysis_record_id, PDO::PARAM_INT);
                    $stmt_why->bindParam(':why_order', $why_order, PDO::PARAM_INT);
                    $stmt_why->bindParam(':why_text', $sanitized_why_text); // Bind the new variable
                    $stmt_why->execute();
                }
            }
        }	

        $conn->commit(); // Commit the transaction if all inserts are successful

        echo "<!DOCTYPE html><html lang='gu'><head><meta charset='UTF-8'><title>સબમિશન સફળ</title>";
        echo "<style>
            body { font-family: Arial, sans-serif; margin: 20px; background-color: #e9f5ff; color: #333; }
            .container { background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); max-width: 800px; margin: auto; border-top: 5px solid #28a745;}
            h2 { color: #28a745; text-align: center; margin-bottom: 20px; }
            h3 { color: #007bff; border-bottom: 1px solid #eee; padding-bottom: 8px; margin-top: 20px; }
            p { margin-bottom: 8px; line-height: 1.5; }
            strong { color: #555; }
            ol { margin-left: 20px; padding-left: 0; }
            li { margin-bottom: 5px; }
            .back-button { display: block; width: 200px; margin: 30px auto; padding: 10px 20px; background-color: #007bff; color: white; text-align: center; text-decoration: none; border-radius: 5px; }
            .back-button:hover { background-color: #0056b3; }
        </style></head><body><div class='container'>";
        echo "<h2>એનાલિસિસ સફળતાપૂર્વક સબમિટ થયું!</h2>";
        echo "<p>નવા રેકોર્ડ ID: <strong>" . $analysis_record_id . "</strong></p>";

        echo "<h3>જનરલ માહિતી</h3>";
        echo "<p><strong>તારીખ:</strong> " . htmlspecialchars($analysis_date) . "</p>";
        echo "<p><strong>મશીન ID:</strong> " . htmlspecialchars($machine_id) . "</p>";
        echo "<p><strong>પાર્ટનું નામ:</strong> " . htmlspecialchars($part_name) . "</p>";

        echo "<h3>સમસ્યા વર્ણન</h3>";
        echo "<p><strong>મુખ્ય સમસ્યા:</strong> " . nl2br(htmlspecialchars($problem_statement)) . "</p>";
        echo "<p><strong>શું થયું?:</strong> " . nl2br(htmlspecialchars($what_happened)) . "</p>";
        echo "<p><strong>ક્યાં થયું?:</strong> " . htmlspecialchars($where_happened) . "</p>";
        echo "<p><strong>ક્યારે થયું?:</strong> " . htmlspecialchars($when_happened ?? 'N/A') . "</p>";
        echo "<p><strong>કોણે શોધ્યું?:</strong> " . htmlspecialchars($who_found) . "</p>";
        echo "<p><strong>કેટલું થયું?:</strong> " . htmlspecialchars($how_much_impact) . "</p>";
        echo "<p><strong>ગ્રાહક પર અસર:</strong> " . nl2br(htmlspecialchars($customer_impact)) . "</p>";

        echo "<h3>કન્ટેઈનમેન્ટ એક્શન</h3>";
        echo "<p><strong>પગલાં:</strong> " . nl2br(htmlspecialchars($containment_action)) . "</p>";
        echo "<p><strong>અસરકારકતા ચકાસવામાં આવી?:</strong> " . ($containment_effectiveness_verified ? 'હા' : 'ના') . "</p>";
        echo "<p><strong>ચકાસણી કરનાર:</strong> " . htmlspecialchars($containment_verified_by) . "</p>";
        echo "<p><strong>ચકાસણી તારીખ:</strong> " . htmlspecialchars($containment_verification_date) . "</p>";

        echo "<h3>ક્રોસ-ફંક્શનલ ટીમ</h3>";
        echo "<p><strong>ટીમ લીડર:</strong> " . htmlspecialchars($team_leader) . "</p>";
        echo "<p><strong>ટીમ સભ્યો:</strong> " . htmlspecialchars($team_members_str) . "</p>";

        echo "<h3>શા માટે? (Why?)</h3>";
        if (!empty($whys)) {
            echo "<ol>";
            foreach ($whys as $index => $why_reason) {
                if (!empty(trim($why_reason))) {
                    echo "<li>" . nl2br(htmlspecialchars($why_reason)) . "</li>";
                }
            }
            echo "</ol>";
        } else {
            echo "<p>કોઈ 'શા માટે' કારણો દાખલ કરવામાં આવ્યા નથી.</p>";
        }
        echo "<p><strong>ઓળખાયેલ મૂળ કારણ:</strong> " . nl2br(htmlspecialchars($root_cause)) . "</p>";

        echo "<h3>કરેક્ટિવ અને પ્રિવેન્ટિવ એક્શન</h3>";
        echo "<p><strong>કરેક્ટિવ એક્શન:</strong> " . nl2br(htmlspecialchars($corrective_action)) . "</p>";
        echo "<p><strong>CA જવાબદાર:</strong> " . htmlspecialchars($ca_responsible_person) . "</p>";
        echo "<p><strong>CA લક્ષ્ય તારીખ:</strong> " . htmlspecialchars($ca_target_date) . "</p>";
        echo "<p><strong>પ્રિવેન્ટિવ એક્શન:</strong> " . nl2br(htmlspecialchars($preventive_action)) . "</p>";
        echo "<p><strong>PA જવાબદાર:</strong> " . htmlspecialchars($pa_responsible_person) . "</p>";
        echo "<p><strong>PA લક્ષ્ય તારીખ:</strong> " . htmlspecialchars($pa_target_date) . "</p>";
        echo "<p><strong>સિસ્ટમ દસ્તાવેજો અપડેટ થયા:</strong> " . nl2br(htmlspecialchars($system_documents_updated)) . "</p>";

        echo "<h3>અસરકારકતાની ચકાસણી</h3>";
        echo "<p><strong>ચકાસણી પદ્ધતિ:</strong> " . nl2br(htmlspecialchars($verification_method)) . "</p>";
        echo "<p><strong>ચકાસણી તારીખ:</strong> " . htmlspecialchars($verification_date) . "</p>";
        echo "<p><strong>ચકાસણી પરિણામો:</strong> " . nl2br(htmlspecialchars($verification_results)) . "</p>";
        echo "<p><strong>ચકાસણી કરનાર:</strong> " . htmlspecialchars($verified_by) . "</p>";

        echo "<h3>શીખેલા પાઠ</h3>";
        echo "<p><strong>સારાંશ:</strong> " . nl2br(htmlspecialchars($lessons_learned)) . "</p>";

        echo "<a href='why_why_form.php' class='back-button'>નવો એનાલિસિસ ઉમેરો</a>";
        echo "</div></body></html>";

    } else {
        echo "<p>આ ફાઇલ સીધી એક્સેસ કરી શકાતી નથી. કૃપા કરીને ફોર્મ સબમિટ કરો.</p>";
    }

} catch(PDOException $e) {
    echo "<!DOCTYPE html><html lang='gu'><head><meta charset='UTF-8'><title>ભૂલ</title>";
    echo "<style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f8d7da; color: #721c24; }
        .container { background-color: #ffe8ee; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); max-width: 600px; margin: auto; border-top: 5px solid #dc3545;}
        h2 { color: #dc3545; text-align: center; margin-bottom: 20px; }
        p { line-height: 1.5; }
    </style></head><body><div class='container'>";
    echo "<h2>ડેટાબેઝમાં ડેટા સાચવવામાં ભૂલ!</h2>";
    echo "<p>કૃપા કરીને નીચેની ભૂલ તપાસો:</p>";
    echo "<p><strong>ભૂલ:</strong> " . $e->getMessage() . "</p>";
    echo "<p>કૃપા કરીને ડેટાબેઝ કનેક્શન સેટિંગ્સ (`servername`, `username`, `password`, `dbname`) અને કોષ્ટકોની રચના તપાસો.</p>";
    echo "</div></body></html>";
}

$conn = null; // Close the database connection
?>