<?php

// --- 1. ડેટાબેઝ ગોઠવણી ---
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'dasp');

$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

if ($conn->connect_error) {
    die("કનેક્શન નિષ્ફળ થયું: " . $conn->connect_error);
}

function escape_html($str) {
    if (is_string($str)) {
        return htmlspecialchars($str, ENT_QUOTES | ENT_HTML5, 'UTF-8', false);
    }
    return $str;
}

function getShift() {
    date_default_timezone_set('Asia/Kolkata');
    $currentHour = (int)date('H');
    if ($currentHour >= 8 && $currentHour < 20) {
        return 'DAY';
    } else {
        return 'NIGHT';
    }
}

// --- 2. કાર્યક્ષમતાઓ ---
function getAllPartNumbers() {
    global $conn;
    $parts = [];
    $sql = "SELECT id AS part_id, part_number, part_name, drawing_rev FROM parts ORDER BY part_number";
    $result = $conn->query($sql);
    if ($result === false) {
        error_log("getAllPartNumbers માં ક્વેરી ભૂલ: " . $conn->error);
    }
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $parts[] = $row;
        }
    }
    return $parts;
}

function getSetupsByPartId($part_id) {
    global $conn;
    $setups = [];
    $sql = "SELECT DISTINCT setup_info FROM part_parameters WHERE part_id = ? AND setup_info IS NOT NULL AND setup_info != '' ORDER BY setup_info";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (Setups): " . $conn->error);
        return [];
    }
    $stmt->bind_param("i", $part_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $setups[] = $row;
    }
    $stmt->close();
    return $setups;
}

function getParametersByPartIdAndSetup($part_id, $setup_info) {
    global $conn;
    $parameters = [];
    $sql = "SELECT id AS parameter_id, parameter_name, specification, spec_positive, spec_negative
            FROM part_parameters
            WHERE part_id = ? AND setup_info = ?
            ORDER BY parameter_name";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (Parameters by Setup): " . $conn->error);
        return [];
    }
    $stmt->bind_param("is", $part_id, $setup_info);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $parameters[] = $row;
    }
    $stmt->close();
    return $parameters;
}

function addInProcessMeasurement($part_id, $parameter_id, $measured_value, $variance, $positive_deviation_input, $negative_deviation_input, $operator_name, $batch_number, $heat_number, $lot_qty, $machine_id, $is_conforming, $nonconformity_details, $corrective_action_taken, $inspector_name, $shift) {
    global $conn;

    $stmt = $conn->prepare("INSERT INTO inprocess_measurements (part_id, parameter_id, measured_value, variance, positive_deviation_input, negative_deviation_input, operator_name, batch_number, heat_number, lot_qty, machine_id, is_conforming, nonconformity_details, corrective_action_taken, inspector_name, shift) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        error_log("ઇન-પ્રોસેસ માપન પ્રિપેર ભૂલ: " . $conn->error);
        return false;
    }
    $stmt->bind_param("iiddddsssisissss", $part_id, $parameter_id, $measured_value, $variance, $positive_deviation_input, $negative_deviation_input, $operator_name, $batch_number, $heat_number, $lot_qty, $machine_id, $is_conforming, $nonconformity_details, $corrective_action_taken, $inspector_name, $shift);

    if ($stmt->execute()) {
        $stmt->close();
        return true;
    } else {
        error_log("ઇન-પ્રોસેસ માપન ઉમેરવામાં ભૂલ: " . $stmt->error);
        $stmt->close();
        return false;
    }
}

function getInProcessMeasurementsForReport($part_id, $setup_info) {
    global $conn;
    $measurements = [];
    $sql = "SELECT ipm.id, ipm.measured_value, ipm.variance, ipm.positive_deviation_input, ipm.negative_deviation_input, ipm.measurement_date, ipm.operator_name, ipm.batch_number, ipm.heat_number, ipm.lot_qty, ipm.machine_id,
                    ipm.is_conforming, ipm.nonconformity_details, ipm.corrective_action_taken, ipm.inspector_name, ipm.shift,
                    pp.parameter_name, pp.specification, pp.spec_positive, pp.spec_negative, pp.setup_info
            FROM inprocess_measurements AS ipm
            JOIN part_parameters AS pp ON ipm.parameter_id = pp.id
            WHERE ipm.part_id = ? AND pp.setup_info = ?
            ORDER BY ipm.measurement_date DESC";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (In-process Report): " . $conn->error);
        return [];
    }
    $stmt->bind_param("is", $part_id, $setup_info);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $measurements[] = $row;
    }
    $stmt->close();
    return $measurements;
}

// --- 3. ફોર્મ સબમિશન હેન્ડલિંગ અને AJAX વિનંતીઓ ---
if (isset($_GET['action']) && $_GET['action'] == 'get_setups_for_part') {
    $part_id = $_GET['part_id'] ?? 0;
    $setups = getSetupsByPartId($part_id);
    header('Content-Type: application/json');
    echo json_encode($setups);
    exit;
}

if (isset($_GET['action']) && $_GET['action'] == 'get_parameters_for_setup') {
    $part_id = $_GET['part_id'] ?? 0;
    $setup_info = $_GET['setup_info'] ?? '';
    $parameters = getParametersByPartIdAndSetup($part_id, $setup_info);
    header('Content-Type: application/json');
    echo json_encode($parameters);
    exit;
}

if (isset($_GET['action']) && $_GET['action'] == 'get_inprocess_report_data') {
    $part_id = $_GET['part_id'] ?? 0;
    $setup_info = $_GET['setup_info'] ?? '';
    $report_data = getInProcessMeasurementsForReport($part_id, $setup_info);
    header('Content-Type: application/json');
    echo json_encode($report_data);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    if ($_POST['action'] == 'add_inprocess_measurement_single' || $_POST['action'] == 'add_inprocess_measurements_all') {

        $part_id = $_POST['part_id'] ?? 0;
        $operator_name = $_POST['operator_name'] ?? '';
        $batch_number = $_POST['batch_number'] ?? null;
        $heat_number = $_POST['heat_number'] ?? null;
        $lot_qty = $_POST['lot_qty'] ?? null;
        $lot_qty = ($lot_qty !== null && $lot_qty !== '') ? (int)$lot_qty : null;

        $machine_id = $_POST['machine_id'] ?? null;
        $selected_setup_info = $_POST['selected_setup_info'] ?? '';
        $inspector_name = $_POST['inspector_name'] ?? null;
        $shift = getShift();

        if ($_POST['action'] == 'add_inprocess_measurement_single') {
            $parameter_id = $_POST['parameter_id'] ?? 0;
            $measured_value_positive_deviation_str = $_POST['measured_value_positive_deviation'] ?? '';
            $measured_value_negative_deviation_str = $_POST['measured_value_negative_deviation'] ?? '';
            $measured_deviations = [
                $parameter_id => [
                    'positive' => $measured_value_positive_deviation_str,
                    'negative' => $measured_value_negative_deviation_str
                ]
            ];
        } else {
            $measured_deviations = $_POST['measured_deviations'] ?? [];
        }

        if (empty($operator_name)) {
            echo "<p class='info-message error'>કૃપા કરીને ઓપરેટરનું નામ દાખલ કરો.</p>";
            exit;
        }
        
        if (empty($inspector_name)) {
            echo "<p class='info-message error'>કૃપા કરીને ઇન્સ્પેક્ટરનું નામ દાખલ કરો.</p>";
            exit;
        }

        $all_parameters = getParametersByPartIdAndSetup($part_id, $selected_setup_info);
        $parameters_map = [];
        foreach ($all_parameters as $param) {
            $parameters_map[$param['parameter_id']] = $param;
        }

        $success_count = 0;
        $failure_count = 0;
        $ng_count = 0;
        $no_input_count = 0;

        foreach ($measured_deviations as $parameter_id => $deviations) {
            $measured_value_positive_deviation_str = $deviations['positive'] ?? '';
            $measured_value_negative_deviation_str = $deviations['negative'] ?? '';

            if ($measured_value_positive_deviation_str === '' && $measured_value_negative_deviation_str === '') {
                $no_input_count++;
                continue;
            }

            $param_details = $parameters_map[$parameter_id] ?? null;

            if (!$param_details) {
                error_log("Parameter ID $parameter_id not found for processing.");
                $failure_count++;
                continue;
            }

            $measured_value = null;
            $variance = null;

            $positive_deviation_input = ($measured_value_positive_deviation_str !== '') ? (float)$measured_value_positive_deviation_str : null;
            $negative_deviation_input = ($measured_value_negative_deviation_str !== '') ? (float)$measured_value_negative_deviation_str : null;

            $specification_value = ($param_details['specification'] !== null && $param_details['specification'] !== '') ? (float)$param_details['specification'] : null;

            if ($specification_value !== null) {
                $max_measured = null;
                $min_measured = null;

                if ($positive_deviation_input !== null) {
                    $max_measured = $specification_value + $positive_deviation_input;
                }
                if ($negative_deviation_input !== null) {
                    $min_measured = $specification_value + $negative_deviation_input;
                }

                if ($max_measured !== null && $min_measured !== null) {
                    $measured_value = ($max_measured + $min_measured) / 2;
                } elseif ($max_measured !== null) {
                    $measured_value = $max_measured;
                } elseif ($min_measured !== null) {
                    $measured_value = $min_measured;
                } else {
                    $measured_value = $specification_value;
                }
            } else {
                $measured_value = null;
            }
            
            if ($measured_value !== null) {
                $measured_value = round($measured_value, 3);
            }

            if ($positive_deviation_input !== null && $negative_deviation_input !== null) {
                $variance = abs($positive_deviation_input - $negative_deviation_input);
            } elseif ($positive_deviation_input !== null) {
                $variance = abs($positive_deviation_input);
            } elseif ($negative_deviation_input !== null) {
                $variance = abs($negative_deviation_input);
            } else {
                $variance = null;
            }

            if ($variance !== null) {
                $variance = round($variance, 3);
            }

            $is_conforming = true;
            $nonconformity_details = null;

            $raw_spec_positive = ($param_details['spec_positive'] !== null && $param_details['spec_positive'] !== '') ? (float)$param_details['spec_positive'] : null;
            $raw_spec_negative = ($param_details['spec_negative'] !== null && $param_details['spec_negative'] !== '') ? (float)$param_details['spec_negative'] : null;

            if ($positive_deviation_input !== null) {
                if ($raw_spec_positive === null || !is_numeric($raw_spec_positive) || abs($positive_deviation_input) > $raw_spec_positive) {
                    $is_conforming = false;
                    $nonconformity_details = "પોઝિટિવ વિચલન ઇનપુટ (" . ($positive_deviation_input ?? 'N/A') . ") નિર્ધારિત પોઝિટિવ ટોલરન્સ (" . ($raw_spec_positive ?? 'N/A') . ") કરતા વધારે છે.";
                }
            }

            if ($negative_deviation_input !== null) {
                if ($raw_spec_negative === null || !is_numeric($raw_spec_negative) || abs($negative_deviation_input) > $raw_spec_negative) {
                    if ($is_conforming) {
                        $is_conforming = false;
                        $nonconformity_details = "નેગેટિવ વિચલન ઇનપુટ (" . ($negative_deviation_input ?? 'N/A') . ") નિર્ધારિત નેગેટિવ ટોલરન્સ (" . ($raw_spec_negative ?? 'N/A') . ") કરતા વધારે છે.";
                    } else {
                        $nonconformity_details .= " અને નેગેટિવ વિચલન ઇનપુટ (" . ($negative_deviation_input ?? 'N/A') . ") નિર્ધારિત નેગેટિવ ટોલરન્સ (" . ($raw_spec_negative ?? 'N/A') . ") કરતા વધારે છે.";
                    }
                }
            }

            if (($positive_deviation_input !== null || $negative_deviation_input !== null) &&
                ($specification_value === null || !is_numeric($specification_value) ||
                (($raw_spec_positive === null || !is_numeric($raw_spec_positive)) && ($raw_spec_negative === null || !is_numeric($raw_spec_negative))))) {
                if ($is_conforming) {
                    $is_conforming = false;
                    $nonconformity_details = "કોઈ સ્પષ્ટીકરણ અથવા ટોલરન્સ નિર્ધારિત ન હોવા છતાં માપન દાખલ કરવામાં આવ્યું.";
                }
            }

            if ($positive_deviation_input === null && $negative_deviation_input === null) {
                $is_conforming = true;
                $nonconformity_details = null;
            }

            if ($part_id > 0 && $parameter_id > 0 && !empty($operator_name) && !empty($inspector_name) && ($positive_deviation_input !== null || $negative_deviation_input !== null)) {
                if (addInProcessMeasurement($part_id, $parameter_id, $measured_value, $variance, $positive_deviation_input, $negative_deviation_input, $operator_name, $batch_number, $heat_number, $lot_qty, $machine_id, $is_conforming, $nonconformity_details, $corrective_action_taken = null, $inspector_name, $shift)) {
                    $success_count++;
                    if (!$is_conforming) {
                        $ng_count++;
                    }
                } else {
                    $failure_count++;
                }
            } else {
                if($measured_value_positive_deviation_str !== '' || $measured_value_negative_deviation_str !== '') {
                    $failure_count++;
                }
            }
        }

        $total_processed = $success_count + $failure_count + $no_input_count;
        if ($total_processed > 0) {
            echo "<p class='info-message success'>કુલ $success_count માપન સફળતાપૂર્વક ઉમેરાયા.</p>";
            if ($ng_count > 0) {
                echo "<p class='info-message warning'>જેમાંથી $ng_count માપન NG હતા.</p>";
            }
            if ($failure_count > 0) {
                echo "<p class='info-message error'>$failure_count માપન ઉમેરવામાં નિષ્ફળ રહ્યા.</p>";
            }
            if ($no_input_count > 0) {
                echo "<p class='info-message info'>$no_input_count પેરામીટર્સ માટે કોઈ માપન દાખલ કરવામાં આવ્યું ન હતું.</p>";
            }
        } else {
            echo "<p class='info-message error'>કોઈ માપન ઉમેરાયા નથી.</p>";
        }
        exit;
    }
}

$allPartNumbers = getAllPartNumbers();
$currentShift = getShift();

?>
<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IATF ઇન-પ્રોસેસ કંટ્રોલ રિપોર્ટ અને એન્ટ્રી</title>
    <style>
        :root {
            --erp-primary-color: #4CAF50;
            --erp-secondary-color: #007bff;
            --erp-text-color: #333;
            --erp-border-color: #ccc;
            --erp-bg-color: #f4f7f6;
            --erp-card-bg: #fff;
            --erp-header-bg: #e9ecef;
            --erp-table-header-bg: #007bff;
            --erp-table-header-color: #fff;
            --erp-success-color: #28a745;
            --erp-error-color: #dc3545;
            --erp-warning-color: #ffc107;
            --erp-info-color: #17a2b8;
            --erp-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
            --erp-hover-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        }

        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--erp-bg-color);
            color: var(--erp-text-color);
            line-height: 1.6;
            overflow-x: hidden;
        }

        .container {
            width: 95%;
            max-width: 1400px;
            margin: 20px auto;
            padding: 20px;
            background-color: var(--erp-card-bg);
            border-radius: 8px;
            box-shadow: var(--erp-shadow);
        }

        h1 {
            text-align: center;
            color: var(--erp-primary-color);
            margin-bottom: 30px;
            font-size: 2.2em;
        }

        .section {
            background-color: var(--erp-card-bg);
            padding: 25px;
            margin-bottom: 25px;
            border-radius: 8px;
            box-shadow: var(--erp-shadow);
            border-top: 5px solid var(--erp-secondary-color);
        }

        .section h2 {
            color: var(--erp-secondary-color);
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 1.8em;
            border-bottom: 2px solid var(--erp-border-color);
            padding-bottom: 10px;
        }

        /* Flex container for two columns */
        .form-columns {
            display: flex;
            flex-wrap: wrap; /* Allows columns to wrap on smaller screens */
            gap: 20px; /* Space between columns */
            margin-bottom: 20px;
        }

        .form-column {
            flex: 1; /* Each column takes equal width */
            min-width: 300px; /* Minimum width for each column before wrapping */
            display: flex;
            flex-direction: column;
            gap: 15px; /* Space between form groups within a column */
        }


        .form-group {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .form-group label {
            flex: 0 0 150px; /* Fixed width for labels */
            font-weight: bold;
            color: var(--erp-text-color);
            text-align: right;
        }

        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group select {
            flex: 1; /* Input fields take remaining width */
            padding: 10px 12px;
            border: 1px solid var(--erp-border-color);
            border-radius: 5px;
            font-size: 1em;
            max-width: 300px; /* Ensure inputs don't stretch too wide */
            box-sizing: border-box;
            background-color: #fdfdfd;
        }

        .form-group input[type="text"]:focus,
        .form-group input[type="number"]:focus,
        .form-group select:focus {
            border-color: var(--erp-secondary-color);
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.25);
            outline: none;
        }

        #parameters_list {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px dashed var(--erp-border-color);
        }

        .parameter-row {
            display: grid;
            grid-template-columns: 2fr 1.5fr 1.5fr 3fr 1fr 1fr 0.5fr;
            align-items: center;
            gap: 15px;
            padding: 12px 0;
            border-bottom: 1px dotted #e0e0e0;
            background-color: #f9f9f9;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .parameter-row:last-child {
            border-bottom: none;
        }

        .parameter-row > div {
            padding: 0 10px;
            word-wrap: break-word;
        }

        .param-label {
            font-weight: bold;
            color: var(--erp-primary-color);
            font-size: 1.1em;
        }

        .input-field {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .input-field label {
            font-weight: normal;
            color: var(--erp-text-color);
            margin: 0;
            flex: none;
            text-align: left;
        }

        .input-field input[type="number"] {
            width: 80px;
            padding: 8px;
            text-align: center;
            font-size: 0.95em;
            margin: 0;
            max-width: none; /* Override max-width for smaller inputs */
        }

        .status-check {
            padding: 5px 10px;
            border-radius: 4px;
            text-align: center;
            font-weight: bold;
        }

        .status-ok {
            background-color: #d4edda;
            color: var(--erp-success-color);
            border: 1px solid #c3e6cb;
        }

        .status-ng {
            background-color: #f8d7da;
            color: var(--erp-error-color);
            border: 1px solid #f5c6cb;
        }

        .variance-display {
            font-size: 0.9em;
            color: #555;
            text-align: center;
        }

        .parameter-row button {
            padding: 8px 15px;
            background-color: var(--erp-secondary-color);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.2s ease, transform 0.1s ease;
            font-size: 0.9em;
        }

        .parameter-row button:hover {
            background-color: #0056b3;
            transform: translateY(-1px);
        }

        .parameter-row button:active {
            transform: translateY(0);
        }

        .add-all-button-container {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px dashed var(--erp-border-color);
        }

        .add-all-button-container button {
            padding: 15px 30px;
            background-color: var(--erp-primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.2em;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.2s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .add-all-button-container button:hover {
            background-color: #303f9f;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        .add-all-button-container button:active {
            transform: translateY(0);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .info-message {
            padding: 12px 20px;
            margin-top: 20px;
            border-radius: 5px;
            font-weight: bold;
            text-align: center;
            font-size: 1.1em;
            animation: fadeOut 5s forwards; /* Fades out after 5 seconds */
        }

        .info-message.success {
            background-color: var(--erp-success-color);
            color: white;
        }

        .info-message.error {
            background-color: var(--erp-error-color);
            color: white;
        }

        .info-message.warning {
            background-color: var(--erp-warning-color);
            color: #333;
        }

        .info-message.info {
            background-color: var(--erp-info-color);
            color: white;
        }

        @keyframes fadeOut {
            0% { opacity: 1; display: block; }
            90% { opacity: 1; display: block; }
            100% { opacity: 0; display: none; }
        }

        .report-area table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 0.9em;
            box-shadow: var(--erp-shadow);
        }

        .report-area th, .report-area td {
            border: 1px solid #ddd;
            padding: 10px 8px;
            text-align: left;
        }

        .report-area th {
            background-color: var(--erp-table-header-bg);
            color: var(--erp-table-header-color);
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .report-area tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .report-area tr:hover {
            background-color: #e9e9e9;
        }

        .report-area .conforming {
            background-color: #e6ffe6; /* Light green for OK */
            color: var(--erp-success-color);
            font-weight: bold;
        }

        .report-area .non-conforming {
            background-color: #ffe6e6; /* Light red for NG */
            color: var(--erp-error-color);
            font-weight: bold;
        }

        /* Responsive adjustments */
        @media (max-width: 1024px) {
            .parameter-row {
                grid-template-columns: 1.5fr 1fr 1fr 2fr 1fr 1fr 0.5fr;
                gap: 10px;
            }
            .form-group label {
                flex: 0 0 120px;
            }
            .form-group input, .form-group select {
                max-width: 250px;
            }
        }

        @media (max-width: 768px) {
            .container {
                width: 98%;
                margin: 10px auto;
                padding: 15px;
            }
            h1 {
                font-size: 1.8em;
                margin-bottom: 20px;
            }
            .section {
                padding: 20px;
                margin-bottom: 20px;
            }
            .section h2 {
                font-size: 1.5em;
                margin-bottom: 15px;
            }
            .form-columns {
                flex-direction: column; /* Stack columns on smaller screens */
                gap: 15px;
            }
            .form-column {
                min-width: unset; /* Remove min-width constraint */
            }
            .form-group {
                flex-direction: column;
                align-items: flex-start;
            }
            .form-group label {
                margin-right: 0;
                margin-bottom: 5px;
                text-align: left;
            }
            .form-group input, .form-group select {
                width: 100%;
                max-width: none;
            }
            .parameter-row {
                grid-template-columns: 1fr;
                gap: 5px;
                padding: 10px;
            }
            .parameter-row > div {
                padding: 0;
            }
            .input-field {
                flex-wrap: wrap;
                justify-content: center;
            }
            .input-field input[type="number"] {
                width: 100px;
            }
            .report-area table, .report-area thead, .report-area tbody, .report-area th, .report-area td, .report-area tr {
                display: block;
            }
            .report-area thead tr {
                position: absolute;
                top: -9999px;
                left: -9999px;
            }
            .report-area tr {
                border: 1px solid #ddd;
                margin-bottom: 10px;
                border-radius: 5px;
                overflow: hidden;
                box-shadow: var(--erp-shadow);
            }
            .report-area td {
                border: none;
                border-bottom: 1px solid #eee;
                position: relative;
                padding-left: 50%;
                text-align: right;
            }
            .report-area td:last-child {
                border-bottom: 0;
            }
            .report-area td:before {
                position: absolute;
                left: 6px;
                width: 45%;
                padding-right: 10px;
                white-space: nowrap;
                content: attr(data-label);
                font-weight: bold;
                text-align: left;
            }
            /* Add data-label attributes to table cells for responsive design */
            .report-area td:nth-of-type(1):before { content: "ID"; }
            .report-area td:nth-of-type(2):before { content: "તારીખ"; }
            .report-area td:nth-of-type(3):before { content: "ઓપરેટર"; }
            .report-area td:nth-of-type(4):before { content: "ઇન્સ્પેક્ટર"; }
            .report-area td:nth-of-type(5):before { content: "શિફ્ટ"; }
            .report-area td:nth-of-type(6):before { content: "બેચ/લોટ નંબર"; }
            .report-area td:nth-of-type(7):before { content: "હીટ નંબર"; }
            .report-area td:nth-of-type(8):before { content: "લોટ Qty"; }
            .report-area td:nth-of-type(9):before { content: "મશીન ID"; }
            .report-area td:nth-of-type(10):before { content: "પેરામીટર"; }
            .report-area td:nth-of-type(11):before { content: "સ્પષ્ટીકરણ"; }
            .report-area td:nth-of-type(12):before { content: "ટોલરન્સ (+/-)"; }
            .report-area td:nth-of-type(13):before { content: "માપેલ મૂલ્ય"; }
            .report-area td:nth-of-type(14):before { content: "+ ઇનપુટ"; }
            .report-area td:nth-of-type(15):before { content: "- ઇનપુટ"; }
            .report-area td:nth-of-type(16):before { content: "વેરિઅન્સ"; }
            .report-area td:nth-of-type(17):before { content: "સ્થિતિ"; }
            .report-area td:nth-of-type(18):before { content: "નોન-કન્ફોર્મિટી વિગતો"; }
        }

        /* Home Page Button Style */
        .add-button-container {
            text-align: center;
            margin-top: 20px;
            margin-bottom: 20px;
        }

        .add-button {
            display: inline-block;
            padding: 12px 25px;
            background-color: var(--erp-primary-color);
            color: #fff;
            text-decoration: none;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 18px;
            font-weight: 500;
            transition: background-color .3s ease,transform .2s ease,box-shadow .2s ease;
            box-shadow: 0 2px 4px rgba(0,0,0,.1);
        }

        .add-button:hover {
            background-color: #303f9f; /* A slightly darker blue for hover */
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,.15);
        }

        .add-button:active {
            transform: translateY(0);
            box-shadow: 0 1px 2px rgba(0,0,0,.1);
        }
    </style>
</head>
<body>
<div class="add-button-container">
            <a href="inprocess_master.php" class="add-button">
                Home Page
            </a>
        </div>
    <div class="container">
        <h1>IATF ઇન-પ્રોસેસ કંટ્રોલ રિપોર્ટ અને એન્ટ્રી</h1>

        <div class="section selection-area">
            <h2>માહિતી પસંદ કરો</h2>
            <div class="form-columns">
			 <div class="form-group">
                <label for="part_id">પાર્ટ નંબર:</label>
                <select id="part_id" name="part_id" onchange="loadSetups()">
                    <option value="">-- પાર્ટ નંબર પસંદ કરો --</option>
                    <?php
                    foreach ($allPartNumbers as $part) {
                        echo "<option value='" . escape_html($part['part_id']) . "'>" . escape_html($part['part_number']) . "</option>";
                    }
                    ?>
                </select>
            </div>
<div class="form-group">
                <label for="setup_info">સેટઅપ:</label>
                <select id="setup_info" name="setup_info" onchange="loadParametersAndReport()">
                    <option value="">-- સેટઅપ પસંદ કરો --</option>
                </select>
            </div>
            <input type="hidden" id="selected_setup_info_hidden" name="selected_setup_info">
</div>
			</div>
			
            
            
        <div class="section entry-area" id="entry_area" style="display: none;">
            <h2>માપન એન્ટ્રી</h2>
            <div class="form-columns">
                <div class="form-column">
                    <div class="form-group">
                        <label for="operator_name">ઓપરેટરનું નામ:</label>
                        <input type="text" id="operator_name" name="operator_name" required>
                    </div>
                    <div class="form-group">
                        <label for="inspector_name">ઇન્સ્પેક્ટરનું નામ:</label>
                        <input type="text" id="inspector_name" name="inspector_name" required>
                    </div>
					<div class="form-group">
                        <label for="machine_id">મશીન ID:</label>
                        <input type="text" id="machine_id" name="machine_id" placeholder="મશીન ID દાખલ કરો">
                    </div>
                </div>
                <div class="form-column">
                    <div class="form-group">
                        <label for="shift_display">શિફ્ટ:</label>
                        <input type="text" id="shift_display" value="<?php echo escape_html($currentShift); ?>" readonly>
                        <input type="hidden" id="shift" name="shift" value="<?php echo escape_html($currentShift); ?>">
                    </div>
                    <div class="form-group">
                        <label for="batch_number">બેચ/લોટ નંબર:</label>
                        <input type="text" id="batch_number" name="batch_number" placeholder="બેચ અથવા લોટ નંબર">
                    </div>
                    <div class="form-group">
                        <label for="heat_number">હીટ નંબર:</label>
                        <input type="text" id="heat_number" name="heat_number" placeholder="હીટ નંબર દાખલ કરો">
                    </div>
                    <div class="form-group">
                        <label for="lot_qty">લોટ Qty:</label>
                        <input type="number" id="lot_qty" name="lot_qty" placeholder="લોટ Qty દાખલ કરો" min="0">
                    </div>
                    
                </div>
            </div>

            <div id="parameters_list">
                <p>ઉપર પાર્ટ નંબર અને સેટઅપ પસંદ કરો.</p>
            </div>
            <div id="status_message" class="info-message" style="display:none;"></div>
            <div class="add-all-button-container">
                    <button onclick="addAllMeasurements()">બધા માપન ઉમેરો</button>
            </div>
        </div>

        <div class="section report-area" id="report_area" style="display: none;">
            <h2>ઇન-પ્રોસેસ માપન રિપોર્ટ</h2>
            <div id="inprocess_report_table">
                <p>ઇન-પ્રોસેસ રિપોર્ટ અહીં પ્રદર્શિત થશે.</p>
            </div>
        </div>
    </div>

    <script src="inprocess_report_entry.js"></script>
</body>
</html>