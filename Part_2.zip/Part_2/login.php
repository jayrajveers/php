<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e9ecef;
            display: flex;
            min-height: 100vh;
            margin: 0;
            align-items: center; /* Center content vertically */
            justify-content: center; /* Center content horizontally */
        }

        .container {
            display: flex;
            width: 95%; /* Slightly wider for better responsiveness */
            max-width: 1400px; /* Increased max width */
            background-color: #fff;
            border-radius: 12px; /* More rounded corners */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15); /* Stronger shadow */
            overflow: hidden;
            margin: 30px; /* More margin around the container */
        }

        .menu {
            background-color: #343a40; /* Darker background for the menu */
            color: #fff; /* White text for better contrast */
            padding: 30px;
            width: 450px; /* Slightly wider menu */
            border-right: 1px solid #495057; /* Darker border */
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .menu h2 {
            color: #007bff; /* Bootstrap primary color */
            text-align: center;
            margin-bottom: 30px;
            font-size: 24px; /* Larger heading */
            font-weight: bold;
        }

        .menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
            width: 100%;
        }

        .menu li {
            margin-bottom: 15px;
        }

        .menu a {
            display: block;
            padding: 12px;
            text-decoration: none;
            color: #f8f9fa; /* Light text for links */
            border-radius: 6px; /* Rounded link buttons */
            transition: background-color 0.3s ease;
            text-align: left;
            font-weight: bold;
        }

        .menu a:hover {
            background-color: #495057; /* Darker hover effect */
        }

        .content {
            flex-grow: 1;
            padding: 40px; /* More padding for the content area */
            display: flex;
            justify-content: center;
            align-items: center;
        }

        form {
            width: 400px; /* Slightly wider form */
            padding: 40px;
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }

        form h3 {
            color: #007bff;
            text-align: center;
            margin-bottom: 30px;
            font-size: 28px; /* Larger form title */
            font-weight: bold;
        }

        form div {
            margin-bottom: 20px;
        }

        form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #495057;
            font-size: 16px;
        }

        form input[type="text"],
        form input[type="password"] {
            width: calc(100% - 16px);
            padding: 12px;
            border: 1px solid #ced4da; /* Bootstrap border color */
            border-radius: 6px;
            box-sizing: border-box;
            font-size: 16px;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        form input[type="text"]:focus,
        form input[type="password"]:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25); /* Bootstrap focus shadow */
        }

        form button[type="submit"] {
            background-color: #007bff; /* Bootstrap primary button color */
            color: white;
            padding: 14px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            width: 100%;
            transition: background-color 0.15s ease-in-out;
        }

        form button[type="submit"]:hover {
            background-color: #0056b3; /* Darker hover color */
        }

        form p[style="color: red;"] {
            margin-top: 15px;
            text-align: center;
            font-weight: bold;
        }

        .image-container {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px;
        }

        .image-container img {
            max-width: 100%;
            height: auto;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        /* Responsive adjustments */
        @media (max-width: 992px) {
            .container {
                flex-direction: column; /* Stack menu and content on smaller screens */
            }

            .menu {
                width: 100%;
                border-right: none;
                border-bottom: 1px solid #495057;
                padding: 20px;
                align-items: stretch; /* Full width menu items */
            }

            .menu ul {
                display: flex;
                justify-content: space-around; /* Distribute menu items horizontally */
            }

            .menu li {
                margin-bottom: 0;
            }

            .menu a {
                padding: 10px;
            }

            .content {
                padding: 30px;
            }

            .image-container {
                display: none; /* Hide image on smaller screens if desired */
            }
        }

        @media (max-width: 600px) {
            form {
                padding: 30px;
                width: 90%;
            }

            .menu ul {
                flex-direction: column; /* Stack menu items vertically on even smaller screens */
                align-items: center;
            }

            .menu li {
                width: 100%;
            }

            .menu a {
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="menu">
            <h2>Menu</h2>
            <ul>
				<li><a href="today_.php">&#x1F4C6; PRODUCTION LOGS</a></li>
                <li><a href="show.php">&#x1F9FE; PRODUCTION REPORT</a></li>
                <li><a href="rejection_data_.php">&#x1F6AB; REJECTION REPROT</a></li>
                <li><a href="get_lot_status_.php">&#x1F4CC; PART STATUS</a></li>
                <li><a href="note_search_.php">&#x1F517; PART NOTE</a></li>
            </ul>
        </div>
        <div class="content">
            <form method="POST" action="login_process.php">
                <h3>User Login</h3>
                <div>
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div>
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit">Login</button>
                <?php
                    if (isset($_GET['error'])) {
                        echo '<p style="color: red;">' . htmlspecialchars($_GET['error']) . '</p>';
                    }
                ?>
            </form>
        </div>
        <div class="image-container">
    <img src="logo.png" alt="Company Image" style="max-width: 100%; height: auto;">
</div>
    </div>
</body>
</html>