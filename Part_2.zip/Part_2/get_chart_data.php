<?php
// File: get_chart_data.php

// 1. Database Connection for Production Data (dasp)
$servername = "localhost";
$username = "root";
$password = "";
$dbname_production = "dasp"; // <-- Production Data માટેનો ડેટાબેઝ

$conn_production = new mysqli($servername, $username, $password, $dbname_production);

// Check production database connection
if ($conn_production->connect_error) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Production Database connection failed: ' . $conn_production->connect_error]);
    exit;
}

// 2. Database Connection for Rejection Data (productiondata)
$dbname_rejection = "dasp"; // <-- Rejection Data માટેનો ડેટાબેઝ

$conn_rejection = new mysqli($servername, $username, $password, $dbname_rejection);

// Check rejection database connection
if ($conn_rejection->connect_error) {
    // production connection ને પણ બંધ કરો જો તે સફળ થયું હોય
    $conn_production->close();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Rejection Database connection failed: ' . $conn_rejection->connect_error]);
    exit;
}


// બ્રાઉઝરને જણાવો કે આઉટપુટ JSON છે
header('Content-Type: application/json');

// ચાર્ટ ડેટા માટે ખાલી એરે સાથે રિસ્પોન્સ એરે ઇનિશિયલાઇઝ કરો
$response = [
    'daily_production' => [],
    'monthly_production' => [],
    'daily_rejection' => [],
    'monthly_rejection' => []
];

// --- ઉત્પાદન ડેટા માટે સાચા નામ (તમારી નવી માહિતી મુજબ) ---
$production_table = "production";
$production_date_column = "date";
$production_total_column = "total_production";

// --- દૈનિક ઉત્પાદન ડેટા મેળવો ---
$sql_daily_production = "SELECT {$production_date_column} AS date, SUM({$production_total_column}) AS total_prod FROM {$production_table} GROUP BY {$production_date_column} ORDER BY {$production_date_column} DESC LIMIT 30";
$result_daily_production = $conn_production->query($sql_daily_production); // <-- $conn_production નો ઉપયોગ

if ($result_daily_production) {
    while ($row = $result_daily_production->fetch_assoc()) {
        array_unshift($response['daily_production'], $row);
    }
} else {
    error_log("Error in daily production query: " . $conn_production->error);
}

// --- માસિક ઉત્પાદન ડેટા મેળવો ---
$sql_monthly_production = "SELECT DATE_FORMAT({$production_date_column}, '%Y-%m') AS month, SUM({$production_total_column}) AS total_prod FROM {$production_table} GROUP BY month ORDER BY month DESC LIMIT 12";
$result_monthly_production = $conn_production->query($sql_monthly_production); // <-- $conn_production નો ઉપયોગ

if ($result_monthly_production) {
    while ($row = $result_monthly_production->fetch_assoc()) {
        array_unshift($response['monthly_production'], $row);
    }
} else {
    error_log("Error in monthly production query: " . $conn_production->error);
}

// --- રિજેક્શન ડેટા માટે સાચા નામ (તમારી નવી માહિતી મુજબ) ---
$rejection_table = "rejectiondata";
$rejection_date_column = "EntryDate";
$rejection_total_column = "Total"; // <-- "Total" (capital T, lowercase al)

// --- દૈનિક રિજેક્શન ડેટા મેળવો ---
$sql_daily_rejection = "SELECT {$rejection_date_column} AS date, SUM({$rejection_total_column}) AS total_rej FROM {$rejection_table} GROUP BY {$rejection_date_column} ORDER BY {$rejection_date_column} DESC LIMIT 30";
$result_daily_rejection = $conn_rejection->query($sql_daily_rejection); // <-- $conn_rejection નો ઉપયોગ

if ($result_daily_rejection) {
    while ($row = $result_daily_rejection->fetch_assoc()) {
        array_unshift($response['daily_rejection'], $row);
    }
} else {
    error_log("Error in daily rejection query: " . $conn_rejection->error);
}

// --- માસિક રિજેક્શન ડેટા મેળવો ---
$sql_monthly_rejection = "SELECT DATE_FORMAT({$rejection_date_column}, '%Y-%m') AS month, SUM({$rejection_total_column}) AS total_rej FROM {$rejection_table} GROUP BY month ORDER BY month DESC LIMIT 12";
$result_monthly_rejection = $conn_rejection->query($sql_monthly_rejection); // <-- $conn_rejection નો ઉપયોગ

if ($result_monthly_rejection) {
    while ($row = $result_monthly_rejection->fetch_assoc()) {
        array_unshift($response['monthly_rejection'], $row);
    }
} else {
    error_log("Error in monthly rejection query: " . $conn_rejection->error);
}

// ડેટાબેઝ કનેક્શન બંધ કરો
$conn_production->close();
$conn_rejection->close();

// ફેચ કરેલા ડેટાને JSON માં એન્કોડ કરો અને આઉટપુટ કરો
echo json_encode($response);

?>