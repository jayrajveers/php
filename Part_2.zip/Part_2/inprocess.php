<?php

// --- 1. ડેટાબેઝ ગોઠવણી (master_file.php માંથી) ---
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'dasp');

// ડેટાબેઝ કનેક્શન બનાવો
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// કનેક્શન તપાસો
if ($conn->connect_error) {
    die("કનેક્શન નિષ્ફળ થયું: " . $conn->connect_error);
}

// --- 2. કાર્યક્ષમતાઓ ---

/**
 * ID દ્વારા એક પાર્ટ મેળવે છે.
 * @param int $part_id
 * @return array|null પાર્ટ ડેટા અથવા null જો ન મળે.
 */
function getPartById($part_id) {
    global $conn;
    $stmt = $conn->prepare("SELECT p.id AS part_id, p.part_name, p.part_number, p.part_code, c.customer_name FROM parts p JOIN customers c ON p.customer_id = c.id WHERE p.id = ?");
    $stmt->bind_param("i", $part_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $part = $result->fetch_assoc();
    $stmt->close();
    return $part;
}

/**
 * પાર્ટ ID અને Setup Info દ્વારા પાર્ટ પેરામીટર્સ મેળવે છે.
 * @param int $part_id
 * @param string $setup_info
 * @return array પેરામીટર ડેટાનો એરે.
 */
function getPartParametersByPartAndSetup($part_id, $setup_info) {
    global $conn;
    $parameters = [];
    $stmt = $conn->prepare("SELECT id AS parameter_id, parameter_name, setup_info, spec_positive, spec_negative, specification FROM part_parameters WHERE part_id = ? AND setup_info = ? ORDER BY parameter_name");
    $stmt->bind_param("is", $part_id, $setup_info);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $parameters[] = $row;
    }
    $stmt->close();
    return $parameters;
}

/**
 * બધા પાર્ટ્સને તેમના સેટઅપ માહિતી સાથે મેળવે છે.
 * @return array પાર્ટ્સ અને તેમના સેટઅપ માહિતીનો એરે.
 */
function getAllPartsWithSetupInfo() {
    global $conn;
    $parts = [];
    $sql = "SELECT DISTINCT p.id AS part_id, p.part_code, p.part_number, pp.setup_info
            FROM parts p
            JOIN part_parameters pp ON p.id = pp.part_id
            ORDER BY p.part_code, pp.setup_info";
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $parts[] = $row;
        }
    } else {
        error_log("Error fetching parts with setup info: " . $conn->error);
    }
    return $parts;
}

/**
 * ઇન-પ્રોસેસ હેડર અને અવલોકનો ઉમેરે છે.
 * @param array $headerData
 * @param array $observationsData
 * @return bool સફળતા પર True, નહીંતર false.
 */
function addInprocessRecordWithObservations($headerData, $observationsData) {
    global $conn;

    // Start transaction
    $conn->begin_transaction();

    try {
        // 1. Add header record
        $stmt_header = $conn->prepare("INSERT INTO inprocess_headers (inspection_date, customer_name, part_name, part_number, cnc_machine_no, operator_name, shift_name, part_code, inspector_name, setup_info) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt_header->bind_param(
            "ssssssssss",
            $headerData['inspection_date'],
            $headerData['customer_name'],
            $headerData['part_name'],
            $headerData['part_number'],
            $headerData['cnc_machine_no'],
            $headerData['operator_name'],
            $headerData['shift_name'],
            $headerData['part_code'],
            $headerData['inspector_name'],
            $headerData['setup_info']
        );
        $stmt_header->execute();
        $inprocess_header_id = $stmt_header->insert_id;
        $stmt_header->close();

        // 2. Add observation records
        $stmt_obs = $conn->prepare("INSERT INTO inprocess_observations (inprocess_header_id, part_parameter_id, measured_value, observation_time, status) VALUES (?, ?, ?, ?, ?)");
        foreach ($observationsData as $obs) {
            $stmt_obs->bind_param(
                "iidss",
                $inprocess_header_id,
                $obs['part_parameter_id'],
                $obs['measured_value'],
                $obs['observation_time'],
                $obs['status']
            );
            $stmt_obs->execute();
        }
        $stmt_obs->close();

        // Commit transaction
        $conn->commit();
        return true;

    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        error_log("ઇન-પ્રોસેસ રેકોર્ડ ઉમેરવામાં ભૂલ: " . $e->getMessage());
        return false;
    }
}

/**
 * બધા ઇન-પ્રોસેસ રીપોર્ટ્સ મેળવે છે.
 * @param string $searchQuery
 * @return array
 */
function getAllInprocessReports($searchQuery = '') {
    global $conn;
    $reports = [];

    $sql = "SELECT ih.*, io.measured_value, io.observation_time, io.status,
                   pp.parameter_name, pp.specification, pp.spec_positive, pp.spec_negative, pp.setup_info AS param_setup_info
            FROM inprocess_headers ih
            JOIN inprocess_observations io ON ih.id = io.inprocess_header_id
            JOIN part_parameters pp ON io.part_parameter_id = pp.id";

    // જો સર્ચ ક્વેરી હોય તો WHERE ક્લોઝ ઉમેરો
    if (!empty($searchQuery)) {
        $searchQuery = "%" . $searchQuery . "%";
        $sql .= " WHERE ih.part_number LIKE ? OR ih.batch_number LIKE ? OR ih.operator_name LIKE ? OR ih.inspector_name LIKE ? OR ih.customer_name LIKE ?";
    }
    $sql .= " ORDER BY ih.inspection_date DESC, ih.created_at DESC, pp.setup_info, pp.parameter_name, io.observation_time ASC";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (Inprocess Reports): " . $conn->error);
        return [];
    }

    if (!empty($searchQuery)) {
        $stmt->bind_param("sssss", $searchQuery, $searchQuery, $searchQuery, $searchQuery, $searchQuery);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    $groupedReports = [];
    while ($row = $result->fetch_assoc()) {
        $header_id = $row['id'];
        if (!isset($groupedReports[$header_id])) {
            $groupedReports[$header_id] = [
                'header' => $row,
                'observations' => []
            ];
            // Remove redundant header info from observations
            unset($groupedReports[$header_id]['header']['measured_value'],
                  $groupedReports[$header_id]['header']['observation_time'],
                  $groupedReports[$header_id]['header']['status'],
                  $groupedReports[$header_id]['header']['parameter_name'],
                  $groupedReports[$header_id]['header']['specification'],
                  $groupedReports[$header_id]['header']['spec_positive'],
                  $groupedReports[$header_id]['header']['spec_negative'],
                  $groupedReports[$header_id]['header']['param_setup_info']);
        }
        $groupedReports[$header_id]['observations'][] = [
            'parameter_name' => $row['parameter_name'],
            'specification' => $row['specification'],
            'spec_positive' => $row['spec_positive'],
            'spec_negative' => $row['spec_negative'],
            'setup_info' => $row['param_setup_info'], // This is parameter's setup info
            'measured_value' => $row['measured_value'],
            'observation_time' => $row['observation_time'],
            'status' => $row['status']
        ];
    }

    // Now, organize observations by parameter and then by time for the desired display
    $finalReports = [];
    foreach ($groupedReports as $report) {
        $header = $report['header'];
        $observationsByParameter = [];
        foreach ($report['observations'] as $obs) {
            $paramKey = $obs['setup_info'] . ' - ' . $obs['parameter_name']; // Unique key for parameter
            if (!isset($observationsByParameter[$paramKey])) {
                $observationsByParameter[$paramKey] = [
                    'parameter_name' => $obs['parameter_name'],
                    'specification' => $obs['specification'],
                    'spec_positive' => $obs['spec_positive'],
                    'spec_negative' => $obs['spec_negative'],
                    'setup_info' => $obs['setup_info'],
                    'measurements' => []
                ];
            }
            $observationsByParameter[$paramKey]['measurements'][] = [
                'value' => $obs['measured_value'],
                'time' => $obs['observation_time'],
                'status' => $obs['status']
            ];
            // Sort measurements by time for correct column order
            usort($observationsByParameter[$paramKey]['measurements'], function($a, $b) {
                return strtotime($a['time']) - strtotime($b['time']);
            });
        }
        $header['grouped_parameters'] = $observationsByParameter;
        $finalReports[] = $header;
    }

    $stmt->close();
    return $finalReports;
}


// --- 3. ફોર્મ સબમિશન હેન્ડલિંગ ---

// ઇન-પ્રોસેસ રેકોર્ડ અને અવલોકનો ઉમેરવા માટેનું ફોર્મ સબમિશન
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'add_inprocess_report') {
    $part_id = $_POST['part_selection'] ?? 0;
    $setup_info = $_POST['setup_selection'] ?? '';

    // Get Part details from part_id
    $partData = getPartById($part_id);
    if (!$partData) {
        echo "<p style='color: red;'>પાર્ટ ડેટા મળ્યો નથી. કૃપા કરીને યોગ્ય પાર્ટ પસંદ કરો.</p>";
        // Exit or redirect as part data is essential
    } else {
        $headerData = [
            'inspection_date' => date('Y-m-d'), // Current date
            'customer_name' => $partData['customer_name'],
            'part_name' => $partData['part_name'],
            'part_number' => $partData['part_number'],
            'cnc_machine_no' => $_POST['cnc_machine_no'] ?? '',
            'operator_name' => $_POST['operator_name'] ?? '',
            'shift_name' => $_POST['shift_name'] ?? '',
            'part_code' => $partData['part_code'],
            'inspector_name' => $_POST['inspector_name'] ?? '',
            'setup_info' => $setup_info
        ];

        $observationsData = [];
        $parameters_data = getPartParametersByPartAndSetup($part_id, $setup_info);

        foreach ($parameters_data as $param) {
            $parameter_id = $param['parameter_id'];
            $spec_positive = $param['spec_positive'];
            $spec_negative = $param['spec_negative'];

            // Loop through each 'measured_value' for the current parameter
            if (isset($_POST['measured_values'][$parameter_id]) && is_array($_POST['measured_values'][$parameter_id])) {
                foreach ($_POST['measured_values'][$parameter_id] as $measured_value) {
                    if ($measured_value !== '') { // Only process non-empty values
                        $status = 'NOT OK';
                        if ($measured_value !== null && $spec_positive !== null && $spec_negative !== null) {
                            if ((float)$measured_value <= (float)$spec_positive && (float)$measured_value >= (float)$spec_negative) {
                                $status = 'OK';
                            }
                        } else if ($measured_value !== null && $spec_positive === null && $spec_negative === null) {
                            $status = 'OK'; // No tolerance defined, consider OK
                        }

                        $observationsData[] = [
                            'part_parameter_id' => $parameter_id,
                            'measured_value' => (float)$measured_value,
                            'observation_time' => date('Y-m-d H:i:s'), // Current time for each observation
                            'status' => $status
                        ];
                    }
                }
            }
        }

        if (!empty($observationsData)) {
            if (addInprocessRecordWithObservations($headerData, $observationsData)) {
                echo "<p style='color: green;'>ઇન-પ્રોસેસ રીપોર્ટ સફળતાપૂર્વક ઉમેરાયો!</p>";
            } else {
                echo "<p style='color: red;'>ઇન-પ્રોસેસ રીપોર્ટ ઉમેરવામાં નિષ્ફળતા.</p>";
            }
        } else {
            echo "<p style='color: red;'>કોઈ માપેલા મૂલ્યો દાખલ કરાયા નથી.</p>";
        }
    }
}

// રીપોર્ટ ડિલીટ કરવા માટે
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['action']) && $_GET['action'] == 'delete_report') {
    $report_id = $_GET['id'] ?? 0;
    global $conn;
    $stmt = $conn->prepare("DELETE FROM inprocess_headers WHERE id = ?");
    $stmt->bind_param("i", $report_id);
    if ($stmt->execute()) {
        echo "<p style='color: green;'>ઇન-પ્રોસેસ રીપોર્ટ સફળતાપૂર્વક ડિલીટ થયો!</p>";
    } else {
        error_log("ઇન-પ્રોસેસ રીપોર્ટ ડિલીટ કરવામાં ભૂલ: " . $stmt->error);
        echo "<p style='color: red;'>ઇન-પ્રોસેસ રીપોર્ટ ડિલીટ કરવામાં નિષ્ફળતા.</p>";
    }
    $stmt->close();
}


// સર્ચ ક્વેરી મેળવો
$search_query_inprocess = $_GET['search_query_inprocess'] ?? '';

// બધા પાર્ટ્સ તેમના સેટઅપ માહિતી સાથે મેળવો
$allPartsWithSetup = getAllPartsWithSetupInfo();

// ઇન-પ્રોસેસ રીપોર્ટ્સ મેળવો
$inprocessReports = getAllInprocessReports($search_query_inprocess);

?>

<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>દૈનિક ઇન-પ્રોસેસ નિરીક્ષણ રીપોર્ટ - CNC</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
            color: #333;
        }
        .container {
            max-width: 1400px; /* Wider container */
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1, h2 {
            color: #0056b3;
        }
        .main-content {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 20px;
        }
        .panel {
            flex: 1;
            min-width: 45%; /* Adjust for two columns */
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .full-width-panel {
            flex-basis: 100%;
            margin-top: 20px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        form input[type="text"],
        form input[type="date"],
        form input[type="time"],
        form input[type="number"],
        form select {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        form button {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-right: 10px;
        }
        form button.add-button {
            background-color: #28a745;
        }
        form button:hover {
            opacity: 0.9;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }
        table th {
            background-color: #0056b3;
            color: white;
        }
        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .actions a {
            margin-right: 5px;
            text-decoration: none;
            padding: 5px 8px;
            border-radius: 3px;
        }
        .delete-btn {
            background-color: #dc3545;
            color: white;
        }
        .search-container {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }
        .search-container input {
            flex-grow: 1;
        }
        .search-button {
            background-color: #6c757d;
        }
        .status-ok {
            background-color: #d4edda;
            color: #155724;
            padding: 3px 5px;
            border-radius: 3px;
            font-weight: bold;
        }
        .status-not-ok {
            background-color: #f8d7da;
            color: #721c24;
            padding: 3px 5px;
            border-radius: 3px;
            font-weight: bold;
        }
        p {
            margin: 10px 0;
            padding: 8px;
            border-radius: 4px;
        }
        p[style*='green'] {
            background-color: #d4edda;
            color: #155724;
            border-color: #c3e6cb;
        }
        p[style*='red'] {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        /* Styles for the "Observation" table layout */
        .observation-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .observation-table th, .observation-table td {
            border: 1px solid #ccc;
            padding: 5px;
            text-align: center;
        }
        .observation-table th {
            background-color: #e0e0e0;
            font-weight: normal;
        }
        .measurement-input-group {
            display: flex;
            align-items: center;
            gap: 5px;
            margin-bottom: 5px;
        }
        .measurement-input-group input {
            width: 80px; /* Smaller input for values */
            margin-bottom: 0;
        }
        .measurement-input-group span {
            font-size: 0.8em;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>દૈનિક ઇન-પ્રોસેસ નિરીક્ષણ રીપોર્ટ - CNC</h1>

        <div class="main-content">
            <div class="panel">
                <h2>નવો ઇન-પ્રોસેસ રીપોર્ટ</h2>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="add_inprocess_report">

                    <label for="inspection_date">તારીખ:</label>
                    <input type="date" id="inspection_date" name="inspection_date" value="<?php echo date('Y-m-d'); ?>" required>

                    <label for="part_setup_selection">પાર્ટ અને સેટઅપ પસંદ કરો:</label>
                    <select id="part_setup_selection" name="part_setup_selection" required>
                        <option value="">-- પાર્ટ અને સેટઅપ પસંદ કરો --</option>
                        <?php foreach ($allPartsWithSetup as $partSetup): ?>
                            <option value="<?php echo htmlspecialchars($partSetup['part_id'] . '|' . $partSetup['setup_info']); ?>"
                                    data-part_id="<?php echo htmlspecialchars($partSetup['part_id']); ?>"
                                    data-setup_info="<?php echo htmlspecialchars($partSetup['setup_info']); ?>">
                                <?php echo htmlspecialchars($partSetup['part_code'] . ' (' . $partSetup['part_number'] . ') - ' . $partSetup['setup_info']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="hidden" id="selected_part_id" name="part_selection">
                    <input type="hidden" id="selected_setup_info" name="setup_selection">

                    <label for="cnc_machine_no">CNC મશીન નંબર:</label>
                    <input type="text" id="cnc_machine_no" name="cnc_machine_no" required>

                    <label for="operator_name">ઓપરેટરનું નામ:</label>
                    <input type="text" id="operator_name" name="operator_name" required>

                    <label for="shift_name">શિફ્ટ:</label>
                    <input type="text" id="shift_name" name="shift_name" required>

                    <label for="inspector_name">ઇન્સ્પેક્ટરનું નામ:</label>
                    <input type="text" id="inspector_name" name="inspector_name" required>

                    <div id="parameters_measurement_area">
                        </div>

                    <button type="submit" class="add-button">રીપોર્ટ ઉમેરો</button>
                </form>
            </div>

            <div class="panel">
                <h2>હાલના રીપોર્ટ્સ</h2>
                <div class="search-container">
                    <input type="text" id="search_input_inprocess" placeholder="પાર્ટ નંબર, ઓપરેટર, ઇન્સ્પેક્ટર, ગ્રાહક દ્વારા સર્ચ કરો..." value="<?php echo htmlspecialchars($search_query_inprocess); ?>">
                    <button type="button" class="search-button" onclick="performInprocessSearch()">સર્ચ કરો</button>
                </div>

                <?php if (!empty($inprocessReports)): ?>
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th>તારીખ</th>
                                <th>ગ્રાહક</th>
                                <th>પાર્ટ નંબર</th>
                                <th>CNC મશીન</th>
                                <th>ઓપરેટર</th>
                                <th>શિફ્ટ</th>
                                <th>ઇન્સ્પેક્ટર</th>
                                <th>સેટઅપ</th>
                                <th colspan="2">પેરામીટર / માપન</th>
                                <th>કાર્યવાહી</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($inprocessReports as $report): ?>
                                <tr>
                                    <td><?php echo date('d-m-Y', strtotime($report['header']['inspection_date'])); ?></td>
                                    <td><?php echo htmlspecialchars($report['header']['customer_name']); ?></td>
                                    <td><?php echo htmlspecialchars($report['header']['part_number']); ?></td>
                                    <td><?php echo htmlspecialchars($report['header']['cnc_machine_no']); ?></td>
                                    <td><?php echo htmlspecialchars($report['header']['operator_name']); ?></td>
                                    <td><?php echo htmlspecialchars($report['header']['shift_name']); ?></td>
                                    <td><?php echo htmlspecialchars($report['header']['inspector_name']); ?></td>
                                    <td><?php echo htmlspecialchars($report['header']['setup_info']); ?></td>
                                    <td colspan="2" style="padding: 0;">
                                        <table class="observation-table">
                                            <thead>
                                                <tr>
                                                    <th style="width: 30%;">પેરામીટર</th>
                                                    <th style="width: 20%;">સ્પષ્ટીકરણ</th>
                                                    <?php
                                                        // Determine max number of observations to create dynamic columns
                                                        $max_obs_cols = 0;
                                                        foreach ($report['grouped_parameters'] as $param_group) {
                                                            $count = count($param_group['measurements']);
                                                            if ($count > $max_obs_cols) {
                                                                $max_obs_cols = $count;
                                                            }
                                                        }
                                                        for ($i = 0; $i < max(2, $max_obs_cols); $i++): // Ensure at least 2 columns, as per image_40da98.png
                                                    ?>
                                                        <th>Date & Time</th>
                                                    <?php endfor; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($report['grouped_parameters'] as $param_key => $param_data): ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo htmlspecialchars($param_data['parameter_name']); ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                                echo ($param_data['specification'] !== null ? htmlspecialchars($param_data['specification']) . ' ' : '');
                                                                echo '(' . ($param_data['spec_negative'] !== null ? rtrim(rtrim(sprintf('%.3f', $param_data['spec_negative']), '0'), '.') : 'N/A') . ' થી ';
                                                                echo ($param_data['spec_positive'] !== null ? rtrim(rtrim(sprintf('%.3f', $param_data['spec_positive']), '0'), '.') : 'N/A') . ')';
                                                            ?>
                                                        </td>
                                                        <?php
                                                            // Display measurements
                                                            for ($i = 0; $i < max(2, $max_obs_cols); $i++) {
                                                                echo "<td>";
                                                                if (isset($param_data['measurements'][$i])) {
                                                                    $measurement = $param_data['measurements'][$i];
                                                                    echo htmlspecialchars(rtrim(rtrim(sprintf('%.3f', $measurement['value']), '0'), '.')) . "<br>";
                                                                    echo "<span style='font-size:0.8em;'>" . date('d-m-Y H:i', strtotime($measurement['time'])) . "</span><br>";
                                                                    echo "<span class='" . ($measurement['status'] == 'OK' ? 'status-ok' : 'status-not-ok') . "'>" . htmlspecialchars($measurement['status']) . "</span>";
                                                                } else {
                                                                    echo "-";
                                                                }
                                                                echo "</td>";
                                                            }
                                                        ?>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </td>
                                    <td class="actions">
                                        <a href="?action=delete_report&id=<?php echo $report['header']['id']; ?>" class="delete-btn" onclick="return confirm('શું તમે ખરેખર આ રીપોર્ટ ડિલીટ કરવા માંગો છો?')">ડિલીટ</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>કોઈ ઇન-પ્રોસેસ રીપોર્ટ મળ્યો નથી.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        const allPartsWithSetup = <?php echo json_encode($allPartsWithSetup); ?>;

        document.getElementById('part_setup_selection').addEventListener('change', function() {
            const selectedValue = this.value;
            const [partId, setupInfo] = selectedValue.split('|');

            document.getElementById('selected_part_id').value = partId;
            document.getElementById('selected_setup_info').value = setupInfo;

            const parametersMeasurementArea = document.getElementById('parameters_measurement_area');
            parametersMeasurementArea.innerHTML = ''; // Clear previous parameters

            if (partId && setupInfo) {
                // Fetch parameters for the selected part and setup using AJAX
                fetch('get_parameters.php?part_id=' + partId + '&setup_info=' + encodeURIComponent(setupInfo))
                    .then(response => response.json())
                    .then(parameters => {
                        if (parameters.length > 0) {
                            parameters.forEach(param => {
                                const paramDiv = document.createElement('div');
                                paramDiv.classList.add('parameter-row');
                                paramDiv.innerHTML = `
                                    <h3>${param.parameter_name}</h3>
                                    <p>સ્પષ્ટીકરણ: ${param.specification || 'N/A'}</p>
                                    <p>ટોલરન્સ: ${formatTolerance(param.spec_negative, param.spec_positive)}</p>
                                `;

                                // Add 2 input fields for measured values as per "Recorded 2 Pcs"
                                for (let i = 0; i < 2; i++) {
                                    const measurementGroup = document.createElement('div');
                                    measurementGroup.classList.add('measurement-input-group');
                                    measurementGroup.innerHTML = `
                                        <label>માપેલું મૂલ્ય ${i + 1}:</label>
                                        <input type="number"
                                               name="measured_values[${param.parameter_id}][]"
                                               step="0.001"
                                               placeholder="માપેલું મૂલ્ય"
                                               oninput="checkMeasurement(this, ${param.spec_negative}, ${param.spec_positive})">
                                        <span>(${getCurrentTime()}) <span class="status-display"></span></span>
                                    `;
                                    paramDiv.appendChild(measurementGroup);
                                }
                                parametersMeasurementArea.appendChild(paramDiv);
                            });
                        } else {
                            parametersMeasurementArea.innerHTML = '<p>આ પાર્ટ અને સેટઅપ માટે કોઈ પેરામીટર મળ્યા નથી.</p>';
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching parameters:', error);
                        parametersMeasurementArea.innerHTML = '<p style="color:red;">પેરામીટર લોડ કરવામાં ભૂલ આવી.</p>';
                    });
            }
        });

        function formatTolerance(neg, pos) {
            const formattedNeg = neg !== null ? parseFloat(neg).toFixed(3).replace(/\.?0+$/, '') : 'N/A';
            const formattedPos = pos !== null ? parseFloat(pos).toFixed(3).replace(/\.?0+$/, '') : 'N/A';
            return `${formattedNeg} થી ${formattedPos}`;
        }

        function getCurrentTime() {
            const now = new Date();
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            return `${hours}:${minutes}`;
        }

        function checkMeasurement(inputElement, specNegative, specPositive) {
            const measuredValue = parseFloat(inputElement.value);
            const statusDisplay = inputElement.nextElementSibling.querySelector('.status-display');

            if (isNaN(measuredValue)) {
                statusDisplay.textContent = '';
                statusDisplay.className = 'status-display';
                return;
            }

            let status = 'NOT OK';

            if (specNegative !== null && specPositive !== null) {
                if (measuredValue >= specNegative && measuredValue <= specPositive) {
                    status = 'OK';
                }
            } else {
                // If no tolerance is defined, consider it OK (you can change this logic)
                status = 'OK';
            }

            statusDisplay.textContent = status;
            statusDisplay.className = status === 'OK' ? 'status-display status-ok' : 'status-display status-not-ok';
        }

        // સર્ચ કાર્યક્ષમતા
        function performInprocessSearch() {
            const searchQuery = document.getElementById('search_input_inprocess').value;
            window.location.href = '?search_query_inprocess=' + encodeURIComponent(searchQuery);
        }

        // Enter કી દબાવવા પર સર્ચ ટ્રિગર કરવા માટે
        document.getElementById('search_input_inprocess').addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                performInprocessSearch();
            }
        });
    </script>
</body>
</html>

<?php
// ડેટાબેઝ કનેક્શન બંધ કરો
$conn->close();
?>