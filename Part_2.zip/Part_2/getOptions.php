<?php
// MySQL connection settings
$mysqli = new mysqli("localhost", "root", "", "dasp");

// Connection check
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Only allow valid column names
$allowedColumns = ["Customer", "Machine Number", "Setter Name", "Operator Name", "Ref Number", "Grade", "Breakdown List"];

$type = $_GET['type'] ?? '';
if (!in_array($type, $allowedColumns)) {
    echo json_encode([]);
    exit;
}

// SQL query
$query = "SELECT DISTINCT `$type` FROM `data_for_phpmyadmin` WHERE `$type` IS NOT NULL";
$result = $mysqli->query($query);

// Prepare JSON output
$options = [];
while ($row = $result->fetch_assoc()) {
    $options[] = $row[$type];
}

header('Content-Type: application/json');
echo json_encode($options);
?>
