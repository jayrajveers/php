<?php
    session_start();

    // Check karo ke user logged in chhe ke nahi.
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        // Jo logged in nathi, to login page par redirect karo.
        header("location: login.php");
        exit;
    }
?>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dasp";
$rejection_dbname = "dasp"; // New database name for rejection data

$conn = new mysqli($servername, $username, $password, $dbname);
$conn_rejection = new mysqli($servername, $username, $password, $rejection_dbname); // New connection for rejection data

if ($conn->connect_error) {
    die("Connection failed (dasp): " . $conn->connect_error);
}

if ($conn_rejection->connect_error) {
    die("Connection failed (dasp - rejectiondata): " . $conn_rejection->connect_error);
}

$partcode = "";
$result_lots = []; // For specific part code search
$grand_total_production_setup_2 = 0;
$running_part_codes_data = []; // To store data for all running part codes (or filtered by customer)
$done_lots_data = []; // New array to store data for all done lots (or filtered by customer)

$selected_customer = ""; // New variable to store selected customer
$customers = []; // To store the list of customers for the dropdown

// Fetch unique customers for the dropdown
$sql_customers = "SELECT DISTINCT customer FROM production WHERE customer IS NOT NULL AND customer != '' ORDER BY customer ASC";
$result_customers = $conn->query($sql_customers);
if ($result_customers) {
    while ($row = $result_customers->fetch_assoc()) {
        $customers[] = $row['customer'];
    }
} else {
    echo "Error fetching customers: " . $conn->error;
}


if (isset($_POST['clear'])) {
    $partcode = "";
    $selected_customer = ""; // Clear selected customer too
} elseif (isset($_POST['partcode']) && $_POST['partcode'] != '') {
    // Logic for specific part code search
    $partcode = $_POST['partcode'];

    $sql_lots = "SELECT
                            pl.lot_number,
                            MAX(pl.lot_qty) AS lot_qty,
                            SUM(CASE WHEN pl.setup = 2 THEN pl.total_production ELSE 0 END) AS total_production_setup_2,
                            MAX(pl.shift_target) AS target_qty,
                            GROUP_CONCAT(DISTINCT pl.heat_number SEPARATOR ', ') AS heat_numbers,
                            GROUP_CONCAT(DISTINCT pl.grade SEPARATOR ', ') AS grades,
                            GROUP_CONCAT(DISTINCT pl.customer SEPARATOR ', ') AS customers
                        FROM production pl
                        WHERE pl.ref_number LIKE '%$partcode%'
                        GROUP BY pl.lot_number";

    $result_lots_query = $conn->query($sql_lots);
    if ($result_lots_query) {
        while ($row_lot = $result_lots_query->fetch_assoc()) {
            $lot_number = $row_lot['lot_number'];
            $result_lots[$lot_number] = $row_lot;
            $result_lots[$lot_number]['FORGING_TOTAL'] = 0;
            $result_lots[$lot_number]['CNC_Total'] = 0;
            $result_lots[$lot_number]['VENDOR_TOTAL'] = 0;
            $result_lots[$lot_number]['TOTAL_REJECTION'] = 0;

            $sql_rejection = "SELECT
                                                SUM(FORGING_TOTAL) AS FORGING_TOTAL,
                                                SUM(CNC_Total) AS CNC_Total,
                                                SUM(VENDOR_TOTAL) AS VENDOR_TOTAL,
                                                SUM(TOTAL) AS TOTAL_REJECTION
                                            FROM rejectiondata
                                            WHERE PARTCODE LIKE '%$partcode%' AND LOT_NUMBER = '$lot_number'";

            $result_rejection_query = $conn_rejection->query($sql_rejection);
            if ($result_rejection_query && $result_rejection_query->num_rows > 0) {
                $row_rejection = $result_rejection_query->fetch_assoc();
                $result_lots[$lot_number]['FORGING_TOTAL'] = $row_rejection['FORGING_TOTAL'] ?? 0;
                $result_lots[$lot_number]['CNC_Total'] = $row_rejection['CNC_Total'] ?? 0;
                $result_lots[$lot_number]['VENDOR_TOTAL'] = $row_rejection['VENDOR_TOTAL'] ?? 0;
                $result_lots[$lot_number]['TOTAL_REJECTION'] = $row_rejection['TOTAL_REJECTION'] ?? 0;
            }
        }
        $result_lots = array_values($result_lots); // Convert associative array to indexed array
    } else {
        echo "Error fetching lot data: " . $conn->error;
    }

    // Grand total of total_production where setup = 2 for the entire part code
    $sql_grand_total_production_setup_2 = "SELECT SUM(total_production) AS grand_total_production_setup_2
                                                     FROM production
                                                     WHERE ref_number LIKE '%$partcode%' AND setup = 2";
    $result_grand_total_production_setup_2_result = $conn->query($sql_grand_total_production_setup_2);

    if ($result_grand_total_production_setup_2_result && $result_grand_total_production_setup_2_result->num_rows > 0) {
        $row_grand_total_production_setup_2 = $result_grand_total_production_setup_2_result->fetch_assoc();
        $grand_total_production_setup_2 = $row_grand_total_production_setup_2['grand_total_production_setup_2'];
    }
}

// Determine if we should show running lots or done lots based on button clicked
$show_running_view = false;
$show_done_view = false;

if (isset($_POST['show_running_lots'])) {
    $show_running_view = true;
} elseif (isset($_POST['show_done_lots'])) { // New condition for Done Lots
    $show_done_view = true;
}

// Logic to fetch running lots (potentially filtered by customer)
if ($show_running_view) {
    if (isset($_POST['customer_filter']) && $_POST['customer_filter'] != '') {
        $selected_customer = $_POST['customer_filter'];
    }

    $customer_filter_sql = "";
    if ($selected_customer != "") {
        $customer_filter_sql = " AND pl.customer = '" . $conn->real_escape_string($selected_customer) . "'";
    }

    $sql_running_lots = "SELECT
                            pl.ref_number,
                            pl.lot_number,
                            MAX(pl.lot_qty) AS lot_qty,
                            SUM(CASE WHEN pl.setup = 2 THEN pl.total_production ELSE 0 END) AS total_production_setup_2,
                            GROUP_CONCAT(DISTINCT pl.heat_number SEPARATOR ', ') AS heat_numbers,
                            GROUP_CONCAT(DISTINCT pl.grade SEPARATOR ', ') AS grades,
                            GROUP_CONCAT(DISTINCT pl.customer SEPARATOR ', ') AS customers,
                            COALESCE(SUM(rd.FORGING_TOTAL), 0) AS FORGING_TOTAL,
                            COALESCE(SUM(rd.CNC_Total), 0) AS CNC_Total,
                            COALESCE(SUM(rd.VENDOR_TOTAL), 0) AS VENDOR_TOTAL,
                            COALESCE(SUM(rd.TOTAL), 0) AS TOTAL_REJECTION
                        FROM production pl
                        LEFT JOIN dasp.rejectiondata rd ON pl.ref_number = rd.PARTCODE AND pl.lot_number = rd.LOT_NUMBER
                        WHERE 1=1 " . $customer_filter_sql . "
                        GROUP BY pl.ref_number, pl.lot_number
                        HAVING (SUM(CASE WHEN pl.setup = 2 THEN pl.total_production ELSE 0 END) + COALESCE(SUM(rd.TOTAL), 0)) < MAX(pl.lot_qty)"; // Running condition

    $result_running_lots_query = $conn->query($sql_running_lots);
    if ($result_running_lots_query) {
        while ($row_running_lot = $result_running_lots_query->fetch_assoc()) {
            $running_part_codes_data[] = $row_running_lot;
        }
    } else {
        echo "Error fetching running lot data: " . $conn->error;
    }
}

// Logic to fetch done lots (potentially filtered by customer) - NEW BLOCK
if ($show_done_view) {
    if (isset($_POST['customer_filter']) && $_POST['customer_filter'] != '') {
        $selected_customer = $_POST['customer_filter'];
    }

    $customer_filter_sql = "";
    if ($selected_customer != "") {
        $customer_filter_sql = " AND pl.customer = '" . $conn->real_escape_string($selected_customer) . "'";
    }

    $sql_done_lots = "SELECT
                            pl.ref_number,
                            pl.lot_number,
                            MAX(pl.lot_qty) AS lot_qty,
                            SUM(CASE WHEN pl.setup = 2 THEN pl.total_production ELSE 0 END) AS total_production_setup_2,
                            GROUP_CONCAT(DISTINCT pl.heat_number SEPARATOR ', ') AS heat_numbers,
                            GROUP_CONCAT(DISTINCT pl.grade SEPARATOR ', ') AS grades,
                            GROUP_CONCAT(DISTINCT pl.customer SEPARATOR ', ') AS customers,
                            COALESCE(SUM(rd.FORGING_TOTAL), 0) AS FORGING_TOTAL,
                            COALESCE(SUM(rd.CNC_Total), 0) AS CNC_Total,
                            COALESCE(SUM(rd.VENDOR_TOTAL), 0) AS VENDOR_TOTAL,
                            COALESCE(SUM(rd.TOTAL), 0) AS TOTAL_REJECTION
                        FROM production pl
                        LEFT JOIN dasp.rejectiondata rd ON pl.ref_number = rd.PARTCODE AND pl.lot_number = rd.LOT_NUMBER
                        WHERE 1=1 " . $customer_filter_sql . "
                        GROUP BY pl.ref_number, pl.lot_number
                        HAVING (SUM(CASE WHEN pl.setup = 2 THEN pl.total_production ELSE 0 END) + COALESCE(SUM(rd.TOTAL), 0)) >= MAX(pl.lot_qty)"; // Done condition

    $result_done_lots_query = $conn->query($sql_done_lots);
    if ($result_done_lots_query) {
        while ($row_done_lot = $result_done_lots_query->fetch_assoc()) {
            $done_lots_data[] = $row_done_lot;
        }
    } else {
        echo "Error fetching done lot data: " . $conn->error;
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Check Lot Status</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 10px;
            background-color: #f4f4f4;
        }
        h1, h2 {
            color: #333;
            text-align: center;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            text-align: center;
        }
        input[type="text"], select { /* Added select to styling */
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 10px;
        }
        input[type="submit"] {
            background-color: #5cb85c;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .status-done {
            color: green;
            font-weight: bold;
        }
        .status-running {
            color: orange;
            font-weight: bold;
        }
        .no-records {
            color: #777;
            font-style: italic;
            text-align: center;
            padding: 10px;
        }
        .grand-total {
            margin-top: 20px;
            text-align: center;
            font-weight: bold;
            color: #337ab7;
        }
        .clear-button {
            background-color: #d9534f;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 10px;
        }
        .clear-button:hover {
            background-color: #c9302c;
        }
        .running-lots-button {
            background-color: #007bff; /* Blue color */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 10px;
        }
        .running-lots-button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
        /* New style for Done Lots button */
        .done-lots-button {
            background-color: #28a745; /* Green color */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 10px;
        }
        .done-lots-button:hover {
            background-color: #218838; /* Darker green on hover */
        }
    </style>
</head>
<body>
<div class="container">
    <div style="margin: 20px 0; text-align: center;">
        <a href="view_records.php" style="
            background-color: #28a745;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: background-color 0.3s ease;
        " onmouseover="this.style.backgroundColor='#218838'" onmouseout="this.style.backgroundColor='#28a745'">
            Home Page
        </a>
    </div>
    <h1>Check Lot Status</h1>
    <form method="post">
        Part Code: <input type="text" name="partcode" value="<?php echo htmlspecialchars($partcode); ?>">
        <input type="submit" value="Check Status">
        <input type="submit" name="clear" class="clear-button" value="Clear">

        <br><br> Customer:
        <select name="customer_filter">
            <option value="">-- Select Customer --</option>
            <?php foreach ($customers as $customer_name): ?>
                <option value="<?php echo htmlspecialchars($customer_name); ?>" <?php if ($selected_customer == $customer_name) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($customer_name); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <input type="submit" name="show_running_lots" class="running-lots-button" value="Show Running Lots">
        <input type="submit" name="show_done_lots" class="done-lots-button" value="Show Done Lots"> </form>

    <?php if (!empty($result_lots) && $partcode != ""): ?>
        <h2>Lot Status for Part Code: <?php echo htmlspecialchars($partcode); ?></h2>
        <?php if (count($result_lots) > 0): ?>
            <table border='1'>
                <tr>
                    <th>Customer</th>
                    <th>Lot Number</th>
                    <th>Heat Number</th>
                    <th>Grade</th>
                    <th>Lot Quantity</th>
                    <th>Partcount wise Production</th>
                    <th>Rework Nos</th>
                    <th>Forging Rejection</th>
                    <th>CNC Rejection</th>
                    <th>Vendor Rejection</th>
                    <th>Total Rejection</th>
                    <th>Status</th>
                </tr>
                <?php foreach ($result_lots as $row): ?>
                    <?php
                    $lot_number = $row["lot_number"];
                    $lot_qty = $row["lot_qty"];
                    $total_production_setup_2 = $row["total_production_setup_2"];
                    $heat_numbers = $row["heat_numbers"];
                    $grades = $row["grades"];
                    $customers_display = $row["customers"];
                    $forging_total = $row["FORGING_TOTAL"] ?? 0;
                    $cnc_total = $row["CNC_Total"] ?? 0;
                    $vendor_total = $row["VENDOR_TOTAL"] ?? 0;
                    $total_rejection = $row["TOTAL_REJECTION"] ?? 0;
                    $rework_nos = max(0, $total_production_setup_2 - $lot_qty - $total_rejection);
                    $status = (($total_production_setup_2 + $total_rejection) >= $lot_qty) ? "Done" : "Running";
                    $status_class = ($status == "Done") ? "status-done" : "status-running";
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($customers_display); ?></td>
                        <td><?php echo htmlspecialchars($lot_number); ?></td>
                        <td><?php echo htmlspecialchars($heat_numbers); ?></td>
                        <td><?php echo htmlspecialchars($grades); ?></td>
                        <td><?php echo htmlspecialchars($lot_qty); ?></td>
                        <td><?php echo htmlspecialchars($total_production_setup_2); ?></td>
                        <td><?php echo htmlspecialchars($rework_nos); ?></td>
                        <td><?php echo htmlspecialchars($forging_total); ?></td>
                        <td><?php echo htmlspecialchars($cnc_total); ?></td>
                        <td><?php echo htmlspecialchars($vendor_total); ?></td>
                        <td><?php echo htmlspecialchars($total_rejection); ?></td>
                        <td class="<?php echo $status_class; ?>"><?php echo htmlspecialchars($status); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p class="no-records">No production records found for Part Code: <?php echo htmlspecialchars($partcode); ?></p>
        <?php endif; ?>

        <h2 class="grand-total">Grand Total Production for Part Code '<?php echo htmlspecialchars($partcode); ?>': <?php echo htmlspecialchars($grand_total_production_setup_2); ?></h2>
    <?php endif; ?>

    <?php if ($show_running_view): ?>
        <?php if (!empty($running_part_codes_data)): ?>
            <h2>Running Lots <?php echo ($selected_customer != "") ? "for Customer: " . htmlspecialchars($selected_customer) : ""; ?></h2>
            <table border='1'>
                <tr>
                    <th>Part Code</th>
                    <th>Customer</th>
                    <th>Lot Number</th>
                    <th>Heat Number</th>
                    <th>Grade</th>
                    <th>Lot Quantity</th>
                    <th>Partcount wise Production</th>
                    <th>Rework Nos</th>
                    <th>Forging Rejection</th>
                    <th>CNC Rejection</th>
                    <th>Vendor Rejection</th>
                    <th>Total Rejection</th>
                    <th>Status</th>
                </tr>
                <?php foreach ($running_part_codes_data as $row): ?>
                    <?php
                    $partcode_running = $row["ref_number"];
                    $lot_number_running = $row["lot_number"];
                    $lot_qty_running = $row["lot_qty"];
                    $total_production_setup_2_running = $row["total_production_setup_2"];
                    $heat_numbers_running = $row["heat_numbers"];
                    $grades_running = $row["grades"];
                    $customers_running = $row["customers"];
                    $forging_total_running = $row["FORGING_TOTAL"] ?? 0;
                    $cnc_total_running = $row["CNC_Total"] ?? 0;
                    $vendor_total_running = $row["VENDOR_TOTAL"] ?? 0;
                    $total_rejection_running = $row["TOTAL_REJECTION"] ?? 0;

                    $rework_nos_running = max(0, $total_production_setup_2_running - $lot_qty_running - $total_rejection_running);
                    $status_running = (($total_production_setup_2_running + $total_rejection_running) < $lot_qty_running) ? "Running" : "Done";
                    $status_class_running = ($status_running == "Done") ? "status-done" : "status-running";
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($partcode_running); ?></td>
                        <td><?php echo htmlspecialchars($customers_running); ?></td>
                        <td><?php echo htmlspecialchars($lot_number_running); ?></td>
                        <td><?php echo htmlspecialchars($heat_numbers_running); ?></td>
                        <td><?php echo htmlspecialchars($grades_running); ?></td>
                        <td><?php echo htmlspecialchars($lot_qty_running); ?></td>
                        <td><?php echo htmlspecialchars($total_production_setup_2_running); ?></td>
                        <td><?php echo htmlspecialchars($rework_nos_running); ?></td>
                        <td><?php echo htmlspecialchars($forging_total_running); ?></td>
                        <td><?php echo htmlspecialchars($cnc_total_running); ?></td>
                        <td><?php echo htmlspecialchars($vendor_total_running); ?></td>
                        <td><?php echo htmlspecialchars($total_rejection_running); ?></td>
                        <td class="<?php echo $status_class_running; ?>"><?php echo htmlspecialchars($status_running); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p class="no-records">No running lots found<?php echo ($selected_customer != "") ? " for customer '" . htmlspecialchars($selected_customer) . "'" : ""; ?>.</p>
        <?php endif; ?>
    <?php endif; ?>

    <?php // NEW BLOCK FOR DONE LOTS ?>
    <?php if ($show_done_view): ?>
        <?php if (!empty($done_lots_data)): ?>
            <h2>Done Lots <?php echo ($selected_customer != "") ? "for Customer: " . htmlspecialchars($selected_customer) : ""; ?></h2>
            <table border='1'>
                <tr>
                    <th>Part Code</th>
                    <th>Customer</th>
                    <th>Lot Number</th>
                    <th>Heat Number</th>
                    <th>Grade</th>
                    <th>Lot Quantity</th>
                    <th>Partcount wise Production</th>
                    <th>Rework Nos</th>
                    <th>Forging Rejection</th>
                    <th>CNC Rejection</th>
                    <th>Vendor Rejection</th>
                    <th>Total Rejection</th>
                    <th>Status</th>
                </tr>
                <?php foreach ($done_lots_data as $row): ?>
                    <?php
                    $partcode_done = $row["ref_number"];
                    $lot_number_done = $row["lot_number"];
                    $lot_qty_done = $row["lot_qty"];
                    $total_production_setup_2_done = $row["total_production_setup_2"];
                    $heat_numbers_done = $row["heat_numbers"];
                    $grades_done = $row["grades"];
                    $customers_done = $row["customers"];
                    $forging_total_done = $row["FORGING_TOTAL"] ?? 0;
                    $cnc_total_done = $row["CNC_Total"] ?? 0;
                    $vendor_total_done = $row["VENDOR_TOTAL"] ?? 0;
                    $total_rejection_done = $row["TOTAL_REJECTION"] ?? 0;

                    $rework_nos_done = max(0, $total_production_setup_2_done - $lot_qty_done - $total_rejection_done);
                    $status_done = (($total_production_setup_2_done + $total_rejection_done) >= $lot_qty_done) ? "Done" : "Running";
                    $status_class_done = ($status_done == "Done") ? "status-done" : "status-running";
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($partcode_done); ?></td>
                        <td><?php echo htmlspecialchars($customers_done); ?></td>
                        <td><?php echo htmlspecialchars($lot_number_done); ?></td>
                        <td><?php echo htmlspecialchars($heat_numbers_done); ?></td>
                        <td><?php echo htmlspecialchars($grades_done); ?></td>
                        <td><?php echo htmlspecialchars($lot_qty_done); ?></td>
                        <td><?php echo htmlspecialchars($total_production_setup_2_done); ?></td>
                        <td><?php echo htmlspecialchars($rework_nos_done); ?></td>
                        <td><?php echo htmlspecialchars($forging_total_done); ?></td>
                        <td><?php echo htmlspecialchars($cnc_total_done); ?></td>
                        <td><?php echo htmlspecialchars($vendor_total_done); ?></td>
                        <td><?php echo htmlspecialchars($total_rejection_done); ?></td>
                        <td class="<?php echo $status_class_done; ?>"><?php echo htmlspecialchars($status_done); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p class="no-records">No done lots found<?php echo ($selected_customer != "") ? " for customer '" . htmlspecialchars($selected_customer) . "'" : ""; ?>.</p>
        <?php endif; ?>
    <?php endif; ?>

</body>
</html>

<?php
$conn->close();
$conn_rejection->close();
?>