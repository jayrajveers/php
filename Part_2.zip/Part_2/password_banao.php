<?php
$sado_password = "cncdep"; // "tamaro_password_aahiya" ni jaga par tamaro sacho password lakho (jem ke, "123456")
$hashed_password = password_hash($sado_password, PASSWORD_DEFAULT);
echo "Hashed Password: " . $hashed_password . "\n";
echo "Aa hashed password copy karo ane tamara database ma paste karo.";
?>