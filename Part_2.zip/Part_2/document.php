<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drive Manager (Tree View)</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Keep your existing CSS here. Add or modify as needed. */
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            background-color: #f8f9fa;
            color: #3c4043;
            display: flex;
            min-height: 100vh;
        }
        .main-container {
            display: flex;
            width: 100%;
            height: 100vh;
            overflow: hidden;
        }

        /* --- Left Panel (Folder Tree) --- */
        .left-panel {
            width: 280px;
            background-color: #ffffff;
            border-right: 1px solid #dadce0;
            box-shadow: 0 1px 3px 0 rgba(60,64,67,.05), 0 4px 8px 3px rgba(60,64,67,.08);
            padding-top: 20px;
            overflow-y: auto;
        }
        .left-panel-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .left-panel-header h2 {
            margin: 0;
            font-size: 1.2em;
            color: #202124;
        }
        .add-folder-btn {
            background-color: #1a73e8;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.9em;
            display: flex;
            align-items: center;
            gap: 5px;
            transition: background-color 0.2s;
        }
        .add-folder-btn:hover {
            background-color: #1558c4;
        }

        .folder-tree {
            list-style: none;
            padding: 10px 0;
            margin: 0;
        }
        .folder-item {
            display: flex;
            align-items: center;
            padding: 8px 20px;
            cursor: pointer;
            position: relative;
            user-select: none;
            transition: background-color 0.15s, color 0.15s;
        }
        .folder-item:hover {
            background-color: #e8f0fe;
        }
        .folder-item.active {
            background-color: #cfe2ff;
            color: #1a73e8;
            font-weight: 500;
        }
        .folder-item-icon {
            margin-right: 10px;
            color: #5f6368;
        }
        .folder-item.active .folder-item-icon {
            color: #1a73e8;
        }
        .folder-name {
            flex-grow: 1;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .folder-toggle-icon {
            margin-left: 5px;
            font-size: 0.8em;
            color: #5f6368;
        }
        .folder-item.expanded .folder-toggle-icon .fa-caret-right {
            transform: rotate(90deg);
        }
        .folder-item.expanded .folder-toggle-icon .fa-caret-right,
        .folder-item .folder-toggle-icon .fa-caret-down {
            transition: transform 0.2s;
        }

        .sub-folders-container {
            list-style: none;
            padding-left: 25px;
            margin: 0;
            display: none;
        }
        .folder-item.expanded + .sub-folders-container {
            display: block;
        }

        /* --- Right Panel (Content Display) --- */
        .right-panel {
            flex-grow: 1;
            padding: 30px;
            overflow-y: auto;
            background-color: #ffffff;
        }
        .right-panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        .right-panel-header h2 {
            margin: 0;
            font-size: 1.8em;
            color: #202124;
        }
        .add-file-btn {
            background-color: #34a853;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1em;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background-color 0.2s;
        }
        .add-file-btn:hover {
            background-color: #2c8c45;
        }
        .upload-form {
            background-color: #e9ecef;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .upload-form input[type="file"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
        }
        .upload-form input[type="submit"] {
            background-color: #4285f4;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.2s;
        }
        .upload-form input[type="submit"]:hover {
            background-color: #3367d6;
        }

        .file-list-container ul {
            list-style: none;
            padding: 0;
            margin: 0;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            overflow: hidden;
        }
        .item-row {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-bottom: 1px solid #f0f0f0;
            background-color: #fff;
            transition: background-color 0.15s;
        }
        .item-row:last-child {
            border-bottom: none;
        }
        .item-row:hover {
            background-color: #f6f6f6;
        }
        .item-icon {
            margin-right: 15px;
            font-size: 1.2em;
            color: #7f878f;
            width: 25px;
            text-align: center;
        }
        .item-row a {
            text-decoration: none;
            color: #202124;
            font-weight: 400;
            flex-grow: 1;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-size: 1.05em;
        }
        .item-row a:hover {
            text-decoration: underline;
        }
        .item-actions {
            margin-left: 15px;
            display: flex;
            gap: 10px;
        }

        /* Delete Button in Right Panel */
        .delete-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.85em;
            display: flex;
            align-items: center;
            gap: 5px;
            transition: background-color 0.2s;
        }
        .delete-btn:hover {
            background-color: #c82333;
        }

        .message {
            padding: 12px 20px;
            margin-bottom: 20px;
            border-radius: 5px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .message.success {
            background-color: #e6ffed;
            color: #1a7f37;
            border: 1px solid #b3e6c3;
        }
        .message.error {
            background-color: #ffe6e6;
            color: #cc0000;
            border: 1px solid #ffb3b3;
        }
        .no-items-message {
            text-align: center;
            padding: 40px;
            color: #70757a;
            font-style: italic;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: #fefefe;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            width: 90%;
            max-width: 450px;
            position: relative;
        }
        .close-button {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 10px;
            right: 15px;
            cursor: pointer;
        }
        .close-button:hover, .close-button:focus {
            color: black;
            text-decoration: none;
        }
        .modal-content h2 {
            margin-top: 0;
            margin-bottom: 20px;
            color: #202124;
            font-size: 1.5em;
        }
        .modal-content label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #5f6368;
        }
        .modal-content input[type="text"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #dadce0;
            border-radius: 5px;
            font-size: 1em;
        }
        .modal-content button[type="submit"] {
            background-color: #1a73e8;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.2s;
        }
        .modal-content button[type="submit"]:hover {
            background-color: #1558c4;
        }
        #modalMessage {
            margin-top: 15px;
        }

        /* --- Search Bar Styles --- */
        .search-container {
            margin-bottom: 20px;
            position: relative;
        }
        .search-container input[type="text"] {
            width: calc(100% - 40px);
            padding: 10px 15px 10px 40px;
            border: 1px solid #dadce0;
            border-radius: 20px;
            font-size: 1em;
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }
        .search-container .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #5f6368;
        }
        .search-container input[type="text"]:focus {
            outline: none;
            border-color: #8ab4f8;
            box-shadow: 0 1px 2px rgba(0,0,0,0.08), 0 3px 6px rgba(0,0,0,0.05);
        }
        /* Style for global search results (to show path) */
        .search-result-item {
            display: flex;
            flex-direction: column; /* Stack name and path */
            align-items: flex-start;
            padding: 10px 15px;
            border-bottom: 1px solid #f0f0f0;
            background-color: #fff;
            transition: background-color 0.15s;
        }
        .search-result-item:hover {
            background-color: #f6f6f6;
        }
        .search-result-item-name {
            font-weight: 500;
            color: #202124;
            text-decoration: none;
            margin-bottom: 2px; /* Space between name and path */
        }
        .search-result-item-path {
            font-size: 0.85em;
            color: #5f6368;
        }
        .search-result-item .item-icon {
            margin-right: 15px;
            font-size: 1.2em;
            color: #7f878f;
            width: 25px;
            text-align: center;
        }
        .search-result-item-content {
            display: flex;
            align-items: center;
            width: 100%; /* Take full width */
        }
        .search-result-item-content > div {
            flex-grow: 1;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <div class="left-panel">
            <div class="left-panel-header">
                <h2>Drive</h2>
                <button id="addRootFolderBtn" class="add-folder-btn" data-parent-path="uploads/">
                    <i class="fas fa-plus"></i> New Folder
                </button>
            </div>
            <ul class="folder-tree" id="folderTree">
                <?php
                function displayFolderTree($currentDirPath, $baseUploadDir, $level = 0) {
                    $items = scandir($currentDirPath);
                    $items = array_diff($items, array('.', '..'));

                    usort($items, function($a, $b) use ($currentDirPath) {
                        $pathA = $currentDirPath . '/' . $a;
                        $pathB = $currentDirPath . '/' . $b;
                        if (is_dir($pathA) && !is_dir($pathB)) return -1;
                        if (!is_dir($pathA) && is_dir($pathB)) return 1;
                        return strcasecmp($a, $b);
                    });

                    foreach ($items as $item) {
                        $itemPath = $currentDirPath . '/' . $item;
                        if (is_dir($itemPath)) {
                            $folderName = htmlspecialchars($item);
                            $uniqueId = str_replace(['/', '.'], '_', $itemPath);
                            ?>
                            <li class="folder-item" data-path="<?php echo htmlspecialchars($itemPath); ?>" id="folder-<?php echo $uniqueId; ?>">
                                <span class="folder-toggle-icon">
                                    <i class="fas fa-caret-right"></i>
                                </span>
                                <span class="folder-item-icon"><i class="fas fa-folder"></i></span>
                                <span class="folder-name"><?php echo $folderName; ?></span>
                            </li>
                            <ul class="sub-folders-container">
                                <?php displayFolderTree($itemPath, $baseUploadDir, $level + 1); ?>
                            </ul>
                            <?php
                        }
                    }
                }

                $baseUploadDir = 'uploads/';
                if (!is_dir($baseUploadDir)) {
                    mkdir($baseUploadDir, 0777, true);
                }
                ?>
                <li class="folder-item root-folder-item active" data-path="uploads/" id="folder-uploads_">
                    <span class="folder-toggle-icon">
                        <i class="fas fa-caret-down"></i>
                    </span>
                    <span class="folder-item-icon"><i class="fas fa-home"></i></span>
                    <span class="folder-name">My Drive</span>
                </li>
                <ul class="sub-folders-container" style="display: block;">
                    <?php displayFolderTree($baseUploadDir, $baseUploadDir, 0); ?>
                </ul>
            </ul>
        </div>

        <div class="right-panel" id="rightPanelContent">
            <p class="no-items-message">Select a folder.</p>
        </div>
    </div>

    <div id="addFolderModal" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close-button">&times;</span>
            <h2>Create New Folder</h2>
            <form id="createFolderForm">
                <label for="newFolderName">Folder Name:</label>
                <input type="text" id="newFolderName" name="new_folder_name" placeholder="Enter new folder name" required>
                <input type="hidden" id="parentFolderPath" name="parent_folder" value="">
                <button type="submit">Create Folder</button>
                <div id="modalMessage" class="message"></div>
            </form>
        </div>
    </div>

    <script>
        let activeFolderPath = 'uploads/'; // Default active path
        let currentSelectedFolder = document.getElementById('folder-uploads_'); // Reference to currently selected folder DOM element
        let currentFolderItems = []; // To store the list of items for local search filtering (now used for global search display)
        let isGlobalSearchActive = false; // Flag to check if global search results are displayed

        // Function to load folder contents into the right panel OR display search results
        function loadContent(path, isSearch = false, searchResults = null) {
            const rightPanelContent = document.getElementById('rightPanelContent');
            
            // Render the search bar initially
            let contentHtml = `
                <div class="search-container">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" id="searchBar" placeholder="Search files and folders...">
                </div>
            `;

            if (isSearch) {
                isGlobalSearchActive = true;
                // Display search results
                contentHtml += `<div class="right-panel-header"><h2>Search Results for "${searchResults.searchTerm}"</h2></div>`;
                if (searchResults.items && searchResults.items.length > 0) {
                    contentHtml += `<div class="file-list-container"><ul>`;
                    searchResults.items.forEach(item => {
                        const iconClass = item.type === 'folder' ? 'fas fa-folder' : 'fas fa-file';
                        const fileExtension = item.name.split('.').pop().toLowerCase();
                        let specificIcon = '';

                        // Assign specific icons based on common file extensions
                        switch (fileExtension) {
                            case 'pdf': specificIcon = 'fas fa-file-pdf'; break;
                            case 'doc':
                            case 'docx': specificIcon = 'fas fa-file-word'; break;
                            case 'xls':
                            case 'xlsx': specificIcon = 'fas fa-file-excel'; break;
                            case 'ppt':
                            case 'pptx': specificIcon = 'fas fa-file-powerpoint'; break;
                            case 'zip':
                            case 'rar': specificIcon = 'fas fa-file-archive'; break;
                            case 'jpg':
                            case 'jpeg':
                            case 'png':
                            case 'gif': specificIcon = 'fas fa-file-image'; break;
                            case 'mp3':
                            case 'wav': specificIcon = 'fas fa-file-audio'; break;
                            case 'mp4':
                            case 'avi':
                            case 'mov': specificIcon = 'fas fa-file-video'; break;
                            case 'txt': specificIcon = 'fas fa-file-alt'; break;
                            case 'html':
                            case 'htm': specificIcon = 'fas fa-file-code'; break;
                            default: specificIcon = iconClass; // Default to general file/folder icon
                        }

                        // For folders, allow clicking to open the folder
                        const itemLink = item.type === 'folder' ? '#' : `download_file.php?path=${encodeURIComponent(item.path)}`;
                        const linkTarget = item.type === 'file' ? '_blank' : '_self'; // Open files in new tab

                        contentHtml += `
                            <li class="item-row search-result-item" data-path="${item.path}" data-type="${item.type}">
                                <div class="item-icon"><i class="${specificIcon}"></i></div>
                                <div class="search-result-item-content">
                                    <div>
                                        <a href="${itemLink}" target="${linkTarget}" class="search-result-item-name">${item.name}</a>
                                        <div class="search-result-item-path">${item.displayPath}</div>
                                    </div>
                                    <div class="item-actions">
                                        ${item.type === 'file' ? `<button class="delete-btn" data-path="${item.path}" data-type="file"><i class="fas fa-trash"></i> Delete</button>` : ''}
                                        ${item.type === 'folder' ? `<button class="delete-btn" data-path="${item.path}" data-type="folder"><i class="fas fa-trash"></i> Delete</button>` : ''}
                                    </div>
                                </div>
                            </li>
                        `;
                    });
                    contentHtml += `</ul></div>`;
                } else {
                    contentHtml += `<p class="no-items-message">No matching items found.</p>`;
                }
                rightPanelContent.innerHTML = contentHtml;
                // Keep the search term in the search bar if it's a search result view
                const searchBar = document.getElementById('searchBar');
                if (searchBar && searchResults.searchTerm) {
                    searchBar.value = searchResults.searchTerm;
                }

            } else {
                isGlobalSearchActive = false;
                // Load regular folder content
                activeFolderPath = path;
                fetch(`get_folder_contents.php?path=${encodeURIComponent(path)}`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok ' + response.statusText);
                        }
                        return response.text();
                    })
                    .then(html => {
                        contentHtml += html; // Add the fetched folder content
                        rightPanelContent.innerHTML = contentHtml;

                        // After content is loaded (and search bar is re-created),
                        // re-initialize currentFolderItems and attach event listener
                        currentFolderItems = Array.from(rightPanelContent.querySelectorAll('.item-row'));

                        // Re-attach search bar event listener
                        const searchBar = document.getElementById('searchBar');
                        if (searchBar) {
                            searchBar.removeEventListener('keyup', handleSearchInput); // Remove old listener
                            searchBar.addEventListener('keyup', handleSearchInput);    // Add new listener
                            searchBar.value = ''; // Clear search bar when returning to folder view
                        }

                        // Re-attach event listeners for other dynamically loaded content (e.g., "Upload File" button)
                        const addFileButton = document.getElementById('addFileButton');
                        if (addFileButton) {
                            addFileButton.addEventListener('click', function() {
                                const uploadForm = document.getElementById('fileUploadForm');
                                if (uploadForm) {
                                    uploadForm.style.display = uploadForm.style.display === 'none' ? 'flex' : 'none';
                                }
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error loading folder contents:', error);
                        contentHtml += `<div class="message error">Error loading content.</div>`;
                        rightPanelContent.innerHTML = contentHtml;
                        const searchBar = document.getElementById('searchBar');
                        if (searchBar) {
                            searchBar.removeEventListener('keyup', handleSearchInput);
                            searchBar.addEventListener('keyup', handleSearchInput);
                            searchBar.value = '';
                        }
                    });
            }

            // Ensure search bar event listener is attached or re-attached after content is set
            const searchBar = document.getElementById('searchBar');
            if (searchBar) {
                // If it's a search result view, the listener is already attached or will be.
                // If it's a folder view, we re-attach it inside the fetch success.
                // This ensures it's always active.
                if (!isSearch) { // Only re-attach if not already in search mode
                    searchBar.removeEventListener('keyup', handleSearchInput);
                    searchBar.addEventListener('keyup', handleSearchInput);
                }
            }
        }

        // New function to handle search input - calls global search
        let searchTimeout; // To debounce search requests
        function handleSearchInput() {
            const searchBar = document.getElementById('searchBar');
            const searchTerm = searchBar.value.trim(); // Trim whitespace

            clearTimeout(searchTimeout); // Clear previous timeout

            if (searchTerm.length > 2) { // Only search if more than 2 characters
                searchTimeout = setTimeout(() => {
                    performGlobalSearch(searchTerm);
                }, 300); // Debounce by 300ms
            } else if (searchTerm.length === 0 && isGlobalSearchActive) {
                // If search bar is empty and we were in global search mode, return to active folder content
                loadContent(activeFolderPath, false); // Load regular folder content
            } else if (searchTerm.length <= 2 && isGlobalSearchActive) {
                // If search term is too short but still in search mode, clear results
                document.getElementById('rightPanelContent').innerHTML = `
                    <div class="search-container">
                        <i class="fas fa-search search-icon"></i>
                        <input type="text" id="searchBar" placeholder="Search files and folders..." value="${searchTerm}">
                    </div>
                    <p class="no-items-message">Type more characters to search...</p>
                `;
                 const newSearchBar = document.getElementById('searchBar');
                if (newSearchBar) {
                    newSearchBar.addEventListener('keyup', handleSearchInput);
                }
            }
        }


        // Function to perform the global search via AJAX
        function performGlobalSearch(searchTerm) {
            fetch(`global_search.php?term=${encodeURIComponent(searchTerm)}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok ' + response.statusText);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.error) {
                        console.error('Search error:', data.error);
                        document.getElementById('rightPanelContent').innerHTML = `
                            <div class="search-container">
                                <i class="fas fa-search search-icon"></i>
                                <input type="text" id="searchBar" placeholder="Search files and folders..." value="${searchTerm}">
                            </div>
                            <div class="message error">Error during search: ${data.error}</div>
                        `;
                        const newSearchBar = document.getElementById('searchBar');
                        if (newSearchBar) {
                            newSearchBar.addEventListener('keyup', handleSearchInput);
                        }
                    } else {
                        loadContent(null, true, { items: data, searchTerm: searchTerm }); // Pass null for path as it's global
                    }
                })
                .catch(error => {
                    console.error('Error during global search fetch:', error);
                    document.getElementById('rightPanelContent').innerHTML = `
                        <div class="search-container">
                            <i class="fas fa-search search-icon"></i>
                            <input type="text" id="searchBar" placeholder="Search files and folders..." value="${searchTerm}">
                        </div>
                        <div class="message error">An error occurred while searching.</div>
                    `;
                    const newSearchBar = document.getElementById('searchBar');
                    if (newSearchBar) {
                        newSearchBar.addEventListener('keyup', handleSearchInput);
                    }
                });
        }


        // Event listener for folder tree clicks (Delegation)
        document.getElementById('folderTree').addEventListener('click', function(event) {
            const folderItem = event.target.closest('.folder-item');
            if (folderItem) {
                const folderPath = folderItem.dataset.path;
                
                // Remove active class from previous and add to new
                if (currentSelectedFolder) {
                    currentSelectedFolder.classList.remove('active');
                }
                folderItem.classList.add('active');
                currentSelectedFolder = folderItem;

                // Toggle expansion only if clicking on the toggle icon or name, not action buttons
                const isToggleClick = event.target.closest('.folder-toggle-icon') || event.target.classList.contains('folder-name');
                if (isToggleClick) {
                    folderItem.classList.toggle('expanded');
                    
                    const caretIcon = folderItem.querySelector('.folder-toggle-icon .fa-caret-right, .folder-toggle-icon .fa-caret-down');
                    if (caretIcon) {
                        if (folderItem.classList.contains('expanded')) {
                            caretIcon.classList.remove('fa-caret-right');
                            caretIcon.classList.add('fa-caret-down');
                        } else {
                            caretIcon.classList.remove('fa-caret-down');
                            caretIcon.classList.add('fa-caret-right');
                        }
                    }
                }
                
                // Always load contents into the right panel when a folder item is clicked
                // This will switch out of global search mode if it was active
                loadContent(folderPath);
            }
        });

        // Event listener for "Create Folder" modal (Root and Subfolders)
        var modal = document.getElementById("addFolderModal");
        var closeButton = document.querySelector("#addFolderModal .close-button");
        var createFolderForm = document.getElementById("createFolderForm");
        var newFolderNameInput = document.getElementById("newFolderName");
        var parentFolderPathInput = document.getElementById("parentFolderPath");
        var modalMessage = document.getElementById("modalMessage");

        document.getElementById("addRootFolderBtn").onclick = function() {
            openModal(this.dataset.parentPath);
        };

        // Delegated event listener for "Create Subfolder" buttons (if they exist in right panel content)
        document.getElementById('rightPanelContent').addEventListener('click', function(event) {
            const addSubfolderBtn = event.target.closest('.add-subfolder-btn');
            if (addSubfolderBtn) {
                openModal(addSubfolderBtn.dataset.parentPath);
            }
        });

        function openModal(parentPath) {
            modal.style.display = "flex"; // Use flex to center the modal
            newFolderNameInput.value = '';
            modalMessage.textContent = '';
            modalMessage.className = 'message';
            parentFolderPathInput.value = parentPath;
        }

        closeButton.onclick = function() {
            modal.style.display = "none";
        }
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        createFolderForm.addEventListener('submit', function(e) {
            e.preventDefault();
            var formData = new FormData(this);

            fetch('create_folder.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    modalMessage.textContent = data.message;
                    modalMessage.className = 'message success';
                    newFolderNameInput.value = '';

                    // Reload the entire page to update the folder tree
                    setTimeout(location.reload.bind(location), 1500);
                    
                } else {
                    modalMessage.textContent = data.message;
                    modalMessage.className = 'message error';
                }
            })
            .catch(error => {
                console.error('Error creating folder:', error);
                modalMessage.textContent = 'An error occurred, please try again.';
                modalMessage.className = 'message error';
            });
        });

        // Delegation for Delete buttons (in right panel content)
        document.getElementById('rightPanelContent').addEventListener('click', function(event) {
            const deleteButton = event.target.closest('.delete-btn');
            if (deleteButton) {
                const itemPath = deleteButton.dataset.path;
                const itemType = deleteButton.dataset.type;
                const confirmMessage = `Are you sure you want to delete this ${itemType === 'folder' ? 'folder' : 'file'}?\nThis action cannot be undone.`;

                if (confirm(confirmMessage)) {
                    fetch('delete_item.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'path=' + encodeURIComponent(itemPath)
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok ' + response.statusText);
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.status === 'success') {
                            alert(data.message);
                            // After deletion, reload the right panel content
                            if (isGlobalSearchActive) {
                                // If in search mode, re-run the search
                                const searchBar = document.getElementById('searchBar');
                                if (searchBar) {
                                    performGlobalSearch(searchBar.value.trim());
                                }
                            } else {
                                // Otherwise, reload the current folder content
                                loadContent(activeFolderPath);
                            }
                            // If a folder was deleted, the tree might need a full reload
                            if (itemType === 'folder') {
                                location.reload(); // Reload page to update the folder tree
                            }
                        } else {
                            alert('Error: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error deleting item:', error);
                        alert('Error while deleting.');
                    });
                }
            }
        });

        // Delegation for file upload form submission (in right panel content)
        document.getElementById('rightPanelContent').addEventListener('submit', function(event) {
            if (event.target && event.target.matches('.upload-form form')) {
                event.preventDefault();
                const form = event.target;
                const formData = new FormData(form);

                fetch('upload_file.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok ' + response.statusText);
                    }
                    return response.json();
                })
                .then(data => {
                    alert(data.message);
                    if (data.status === 'success') {
                        // Reload the right panel content after successful upload
                        loadContent(activeFolderPath);
                        // Hide the upload form
                        const uploadFormDiv = document.getElementById('fileUploadForm');
                        if (uploadFormDiv) {
                            uploadFormDiv.style.display = 'none';
                        }
                    }
                })
                .catch(error => {
                    console.error('Error uploading file:', error);
                    alert('Error while uploading file.');
                });
            }
        });
        
        // Delegation for search results (to open file/folder)
        document.getElementById('rightPanelContent').addEventListener('click', function(event) {
            const resultLink = event.target.closest('.search-result-item-name');
            if (resultLink && !resultLink.href.includes('download_file.php')) { // If it's a folder link
                event.preventDefault(); // Prevent default anchor behavior
                const itemRow = event.target.closest('.search-result-item');
                const folderPath = itemRow.dataset.path;
                
                // Load the contents of the found folder
                loadContent(folderPath);

                // Find the corresponding folder in the tree and make it active and expanded
                const treeFolderElement = document.querySelector(`.folder-item[data-path="${CSS.escape(folderPath)}"]`);
                if (treeFolderElement) {
                    if (currentSelectedFolder) {
                        currentSelectedFolder.classList.remove('active');
                    }
                    treeFolderElement.classList.add('active');
                    currentSelectedFolder = treeFolderElement;

                    // Expand parent folders in the tree view if necessary
                    let currentPathParts = folderPath.split('/');
                    let accumulatedPath = '';
                    for (let i = 0; i < currentPathParts.length; i++) {
                        accumulatedPath += (i === 0 ? '' : '/') + currentPathParts[i];
                        const parentFolderElement = document.querySelector(`.folder-item[data-path="${CSS.escape(accumulatedPath)}"]`);
                        if (parentFolderElement) {
                            parentFolderElement.classList.add('expanded');
                            const caretIcon = parentFolderElement.querySelector('.folder-toggle-icon .fa-caret-right, .folder-toggle-icon .fa-caret-down');
                            if (caretIcon) {
                                caretIcon.classList.remove('fa-caret-right');
                                caretIcon.classList.add('fa-caret-down');
                            }
                            const subContainer = parentFolderElement.nextElementSibling;
                            if (subContainer && subContainer.classList.contains('sub-folders-container')) {
                                subContainer.style.display = 'block';
                            }
                        }
                    }
                }
            }
        });


        // Initial load of root folder contents when page loads
        document.addEventListener('DOMContentLoaded', function() {
            loadContent(activeFolderPath);
        });

    </script>
</body>
</html>