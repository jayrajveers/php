<?php

// --- 1. ડેટાબેઝ ગોઠવણી ---
// આ ફાઇલ માટે ડેટાબેઝ કનેક્શન અહીં જ સ્થાપિત કરો.
define('DB_SERVER', 'localhost'); // તમારું ડેટાબેઝ સર્વર
define('DB_USERNAME', 'root'); // તમારું ડેટાબેઝ યુઝરનેમ
define('DB_PASSWORD', ''); // તમારો ડેટાબેઝ પાસવર્ડ
define('DB_NAME', 'dasp'); // તમારા ડેટાબેઝનું નામ

// ડેટાબેઝ કનેક્શન બનાવો
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// કનેક્શન તપાસો
if ($conn->connect_error) {
    die("કનેક્શન નિષ્ફળ થયું: " . $conn->connect_error);
}

// PHP માં HTML સ્પેશિયલ કેરેક્ટરને એસ્કેપ કરવા માટેનું હેલ્પર ફંક્શન
function escape_html($str) {
    if (is_string($str)) {
        return htmlspecialchars($str, ENT_QUOTES | ENT_HTML5, 'UTF-8', false);
    }
    return $str;
}

/**
 * બધા પાર્ટ નંબર અને તેમના ID મેળવે છે.
 * @return array પાર્ટ રેકોર્ડ્સનો એરે.
 */
function getAllPartNumbers() {
    global $conn;
    $parts = [];
    $sql = "SELECT id AS part_id, part_number, part_name FROM parts ORDER BY part_number";
    $result = $conn->query($sql);
    if ($result === false) {
        error_log("getAllPartNumbers માં ક્વેરી ભૂલ: " . $conn->error);
    }
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $parts[] = $row;
        }
    }
    return $parts;
}

/**
 * આપેલ part_id માટે અનન્ય સેટઅપ માહિતી મેળવે છે.
 * @param int $part_id
 * @return array સેટઅપ માહિતીનો એરે.
 */
function getSetupsByPartId($part_id) {
    global $conn;
    $setups = [];
    $sql = "SELECT DISTINCT setup_info FROM part_parameters WHERE part_id = ? AND setup_info IS NOT NULL AND setup_info != '' ORDER BY setup_info";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (Setups): " . $conn->error);
        return [];
    }
    $stmt->bind_param("i", $part_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $setups[] = $row;
    }
    $stmt->close();
    return $setups;
}

/**
 * આપેલ part_id અને setup_info માટે ઇન-પ્રોસેસ માપન ડેટા મેળવે છે.
 * આ ફંક્શનમાં લોટ/બેચ નંબર અને તારીખ ફિલ્ટર ઉમેરવામાં આવ્યું છે.
 * @param int $part_id
 * @param string $setup_info
 * @param string|null $batch_number ફિલ્ટર કરવા માટેનો બેચ/લોટ નંબર. જો null, તો બધા બેચ નંબર માટે.
 * @param string|null $selected_date રિપોર્ટ માટે ચોક્કસ તારીખ (YYYY-MM-DD). જો null, તો બધી તારીખો માટે.
 * @return array માપનોનો એરે.
 */
function getInProcessMeasurementsForReport($part_id, $setup_info, $batch_number = null, $selected_date = null) {
    global $conn;
    $measurements = [];
    $sql = "SELECT ipm.id, ipm.measured_value, ipm.variance, ipm.positive_deviation_input, ipm.negative_deviation_input, ipm.measurement_date, ipm.operator_name, ipm.batch_number, ipm.heat_number, ipm.machine_id,
                    ipm.is_conforming, ipm.nonconformity_details, ipm.corrective_action_taken,
                    pp.parameter_name, pp.specification, pp.spec_positive, pp.spec_negative, pp.setup_info, pp.id AS parameter_id,
                    p.part_number, p.part_name, p.part_code, p.grade_as_per_drawing AS grade -- CORRECTED COLUMN NAME AND ALIAS
				    FROM inprocess_measurements AS ipm
             JOIN part_parameters AS pp ON ipm.parameter_id = pp.id
             JOIN parts AS p ON ipm.part_id = p.id
             WHERE ipm.part_id = ? AND pp.setup_info = ?";

    $types = "is";
    $params = [$part_id, $setup_info];

    if ($batch_number !== null && $batch_number !== '') {
        $sql .= " AND ipm.batch_number = ?";
        $types .= "s";
        $params[] = $batch_number;
    }

    if ($selected_date !== null && $selected_date !== '') {
        $sql .= " AND DATE(ipm.measurement_date) = ?"; // Filter by exact date
        $types .= "s";
        $params[] = $selected_date;
    }

    $sql .= " ORDER BY ipm.measurement_date ASC, pp.parameter_name ASC"; // Order by date/time and then parameter name

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (In-process Report View): " . $conn->error);
        return [];
    }

    // Dynamic binding of parameters
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $measurements[] = $row;
    }
    $stmt->close();
    return $measurements;
}

/**
 * આપેલ part_id અને setup_info માટે અનન્ય લોટ/બેચ નંબર મેળવે છે.
 * @param int $part_id
 * @param string $setup_info
 * @return array લોટ/બેચ નંબરનો એરે.
 */
function getBatchNumbersByPartAndSetup($part_id, $setup_info) {
    global $conn;
    $batch_numbers = [];
    $sql = "SELECT DISTINCT ipm.batch_number
             FROM inprocess_measurements AS ipm
             JOIN part_parameters AS pp ON ipm.parameter_id = pp.id
             WHERE ipm.part_id = ? AND pp.setup_info = ? AND ipm.batch_number IS NOT NULL AND ipm.batch_number != ''
             ORDER BY ipm.batch_number";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (Batch Numbers): " . $conn->error);
        return [];
    }
    $stmt->bind_param("is", $part_id, $setup_info);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $batch_numbers[] = $row;
    }
    $stmt->close();
    return $batch_numbers;
}

/**
 * આપેલ part_id, setup_info અને batch_number માટે ઉપલબ્ધ અનન્ય માપન તારીખો મેળવે છે.
 * @param int $part_id
 * @param string $setup_info
 * @param string|null $batch_number
 * @return array તારીખોનો એરે (YYYY-MM-DD ફોર્મેટમાં).
 */
function getMeasurementDatesByPartSetupAndBatch($part_id, $setup_info, $batch_number = null) {
    global $conn;
    $dates = [];
    $sql = "SELECT DISTINCT DATE(ipm.measurement_date) AS measurement_date
             FROM inprocess_measurements AS ipm
             JOIN part_parameters AS pp ON ipm.parameter_id = pp.id
             WHERE ipm.part_id = ? AND pp.setup_info = ?";

    $types = "is";
    $params = [$part_id, $setup_info];

    if ($batch_number !== null && $batch_number !== '') {
        $sql .= " AND ipm.batch_number = ?";
        $types .= "s";
        $params[] = $batch_number;
    }

    $sql .= " ORDER BY measurement_date DESC"; // Most recent dates first

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (Measurement Dates): " . $conn->error);
        return [];
    }

    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $dates[] = $row;
    }
    $stmt->close();
    return $dates;
}


// AJAX: Part ID ના આધારે સેટઅપ મેળવો
if (isset($_GET['action']) && $_GET['action'] == 'get_setups_for_part') {
    $part_id = $_GET['part_id'] ?? 0;
    $setups = getSetupsByPartId($part_id);
    header('Content-Type: application/json');
    echo json_encode($setups);
    exit;
}

// AJAX: Part ID અને Setup Info ના આધારે બેચ નંબર મેળવો
if (isset($_GET['action']) && $_GET['action'] == 'get_batch_numbers_for_setup') {
    $part_id = $_GET['part_id'] ?? 0;
    $setup_info = $_GET['setup_info'] ?? '';
    $batch_numbers = getBatchNumbersByPartAndSetup($part_id, $setup_info);
    header('Content-Type: application/json');
    echo json_encode($batch_numbers);
    exit;
}

// AJAX: Part ID, Setup Info અને Batch Number ના આધારે માપન તારીખો મેળવો
if (isset($_GET['action']) && $_GET['action'] == 'get_measurement_dates') {
    $part_id = $_GET['part_id'] ?? 0;
    $setup_info = $_GET['setup_info'] ?? '';
    $batch_number = $_GET['batch_number'] ?? null;
    $measurement_dates = getMeasurementDatesByPartSetupAndBatch($part_id, $setup_info, $batch_number);
    header('Content-Type: application/json');
    echo json_encode($measurement_dates);
    exit;
}

// AJAX: રિપોર્ટ ડેટા મેળવો
if (isset($_GET['action']) && $_GET['action'] == 'get_inprocess_report_data') {
    $part_id = $_GET['part_id'] ?? 0;
    $setup_info = $_GET['setup_info'] ?? '';
    $batch_number = $_GET['batch_number'] ?? null;
    $selected_date = $_GET['selected_date'] ?? null; // Get selected date for filtering

    $report_data = getInProcessMeasurementsForReport($part_id, $setup_info, $batch_number, $selected_date);
    header('Content-Type: application/json');
    echo json_encode($report_data);
    exit;
}

$allPartNumbers = getAllPartNumbers();

?>

<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IATF ઇન-પ્રોસેસ કંટ્રોલ રિપોર્ટ વ્યૂ</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="add-button-container">
        <a href="inprocess_master.php" class="add-button">
            Home Page
        </a>
    </div>
    
    <div class="add-button-container">
        <a href="inprocess_report_view_.php" class="add-button">
            Singl Value Formate
        </a>
    </div>
    
    <h1>IATF ઇન-પ્રોસેસ કંટ્રોલ રિપોર્ટ વ્યૂ</h1>

    <div class="section selection-area">
        <h2>માહિતી પસંદ કરો</h2>
        <div class="form-group">
            <label for="part_id">પાર્ટ નંબર:</label>
            <select id="part_id" onchange="loadSetups()">
                <option value="">-- પાર્ટ નંબર પસંદ કરો --</option>
                <?php
                foreach ($allPartNumbers as $part) {
                    echo "<option value='" . escape_html($part['part_id']) . "'>" . escape_html($part['part_number']) . " - " .escape_html($part['part_name']) . "</option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="setup_info">સેટઅપ:</label>
            <select id="setup_info" onchange="loadBatchNumbers()">
                <option value="">-- સેટઅપ પસંદ કરો --</option>
            </select>
        </div>

        <div class="form-group">
            <label for="batch_number_filter">બેચ/લોટ નંબર (ફિલ્ટર):</label>
            <select id="batch_number_filter" onchange="loadMeasurementDates()">
                <option value="">-- બધા બેચ/લોટ નંબર --</option>
            </select>
        </div>

        <div class="form-group">
            <label for="measurement_date_filter">તારીખ પસંદ કરો:</label>
            <select id="measurement_date_filter">
                <option value="">-- બધી તારીખો --</option>
            </select>
        </div>

        <button onclick="loadReport()">રિપોર્ટ જુઓ</button>
    </div>

    <div class="section report-area" id="report_area" style="display: none;">
        <h2>ઇન-પ્રોસેસ માપન રિપોર્ટ</h2>
        <div id="inprocess_report_table">
            <p>રિપોર્ટ અહીં પ્રદર્શિત થશે.</p>
        </div>
        <div id="runchart_container" style="display: none;">
            <h3>રનચાર્ટ</h3>
        </div>
    </div>
    
    <script src="script.js"></script>
</body>
</html>