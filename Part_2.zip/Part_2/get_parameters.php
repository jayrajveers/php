<?php
// --- ડેટાબેઝ ગોઠવણી ---
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'dasp');

// ડેટાબેઝ કનેક્શન બનાવો
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// કનેક્શન તપાસો
if ($conn->connect_error) {
    die("કનેક્શન નિષ્ફળ થયું: " . $conn->connect_error);
}

header('Content-Type: application/json'); // JSON રિસ્પોન્સ માટે હેડર સેટ કરો

$part_id = $_GET['part_id'] ?? 0;
$setup_info = $_GET['setup_info'] ?? '';

$parameters = [];

if ($part_id > 0 && !empty($setup_info)) {
    $stmt = $conn->prepare("SELECT id AS parameter_id, parameter_name, setup_info, spec_positive, spec_negative, specification FROM part_parameters WHERE part_id = ? AND setup_info = ? ORDER BY parameter_name");
    $stmt->bind_param("is", $part_id, $setup_info);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $parameters[] = $row;
    }
    $stmt->close();
}

echo json_encode($parameters);

$conn->close();
?>