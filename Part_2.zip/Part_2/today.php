<?php
    session_start();

    // Check karo ke user logged in chhe ke nahi.
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        // Jo logged in nathi, to login page par redirect karo.
        header("location: login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PRODCUTION LOGS</title>
    <style>
        /* અગાઉની CSS અહીં પેસ્ટ કરો */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            color: #1c1e21;
            margin: 20px;
            padding: 0;
            line-height: 1.6;
        }

        .home-button-container {
            margin-bottom: 20px;
            text-align: center;
        }

        .home-button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .home-button:hover {
            background-color: #45a049;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15);
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
        }

        form > div {
            text-align: center;
        }

        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #4b4f56;
        }

        input[type="date"], select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            width: 200px; /* ડ્રોપડાઉનની પહોળાઈ */
        }

        input[type="submit"] {
            background-color: #1877f2;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #166fe6;
        }

        button[type="button"] {
            background-color: #f44336;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button[type="button"]:hover {
            background-color: #d32f2f;
        }

        hr {
            border: 1px solid #e9e9e9;
            margin: 20px 0;
        }

        h2 {
            color: #1c1e21;
            margin-bottom: 15px;
            font-size: 20px;
            font-weight: 600;
            text-align: center;
        }

        .scrollable-table-container {
            height: 400px;
            overflow-y: auto;
            background-color: #fff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15);
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .scrollable-table-container table {
            width: 100%;
            border-collapse: collapse;
        }

        .scrollable-table-container th,
        .scrollable-table-container td {
            border-bottom: 1px solid #e9e9e9;
            padding: 12px;
            text-align: left;
            white-space: nowrap;
        }

        .scrollable-table-container th {
            background-color: #f7f7f7;
            font-weight: 500;
            color: #4b4f56;
            position: sticky;
            top: 0;
            z-index: 1;
        }

        .scrollable-table-container tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .scrollable-table-container tr:nth-child(odd) {
            background-color: #fff;
        }
    </style>
</head>
<body>

<div class="home-button-container">
    <a href="view_records.php" class="home-button">Home Page</a>
</div>

<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dasp";

$conn = null;

// ફોર્મ સબમિટ થયા પછી તારીખો અને કસ્ટમરને જાળવી રાખવા માટે
$yesterday_value = isset($_POST['yesterday']) ? $_POST['yesterday'] : date("Y-m-d", strtotime("-1 day"));
$today_value = isset($_POST['today']) ? $_POST['today'] : date("Y-m-d");
$selected_customer = isset($_POST['customer']) ? $_POST['customer'] : '';

try {
    // ડેટાબેઝ સાથે કનેક્ટ કરો (ફક્ત કસ્ટમર લિસ્ટ માટે)
    $conn_customer = new mysqli($servername, $username, $password, $dbname);
    if ($conn_customer->connect_error) {
        throw new Exception("Customer list connection failed: " . $conn_customer->connect_error);
    }

    // યુનિક કસ્ટમર નામો મેળવો
    $sql_customers = "SELECT DISTINCT customer FROM production ORDER BY customer ASC";
    $result_customers = $conn_customer->query($sql_customers);
    $customers = [];
    if ($result_customers->num_rows > 0) {
        while ($row = $result_customers->fetch_assoc()) {
            $customers[] = $row['customer'];
        }
    }
    $conn_customer->close();

    // તારીખ અને કસ્ટમર પસંદગી માટેનું ફોર્મ
    echo "<form method='post'>";
    echo "<div><label for='yesterday'>Select Yesterday's Date:</label><input type='date' id='yesterday' name='yesterday' value='" . htmlspecialchars($yesterday_value) . "'></div>";
    echo "<div><label for='today'>Select Today's Date:</label><input type='date' id='today' name='today' value='" . htmlspecialchars($today_value) . "'></div>";
    echo "<div><label for='customer'>Select Customer:</label><select id='customer' name='customer'>";
    echo "<option value=''>All Customers</option>";
    foreach ($customers as $customer) {
        $selected = ($customer == $selected_customer) ? 'selected' : '';
        echo "<option value='" . htmlspecialchars($customer) . "' " . $selected . ">" . htmlspecialchars($customer) . "</option>";
    }
    echo "</select></div>";
    echo "<input type='submit' value='Show Data'>";
    echo "<button type='button' onclick='resetDates()'>Reset Dates</button>";
    echo "</form>";

    echo "<hr>";

    // ફોર્મ સબમિટ થયા પછી જ ડેટા પ્રોસેસ કરો અને બતાવો
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // ડેટાબેઝ સાથે કનેક્ટ કરો (મુખ્ય ડેટા માટે)
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            throw new Exception("Data connection failed: " . $conn->connect_error);
        }

        $yesterday = $_POST["yesterday"];
        $today = $_POST["today"];
        $customer_filter = $_POST["customer"];

        $where_clause = "WHERE date = ?";
        $params = [$yesterday];
        $types = "s";

        if (!empty($customer_filter)) {
            $where_clause .= " AND customer = ?";
            $params[] = $customer_filter;
            $types .= "s";
        }

        // ગઈ કાલના ચાલતા ભાગોની વિગતો મેળવો (ફિલ્ટર સાથે)
       $sql_yesterday = "SELECT DISTINCT ref_number, machine_number, setup, lot_number, lot_qty, cycle_minutes, cycle_seconds, hourly_target
                            FROM production
                            " . $where_clause . "
                            ORDER BY ref_number DESC, machine_number ASC, setup ASC";
        $stmt_yesterday = $conn->prepare($sql_yesterday);
        $stmt_yesterday->bind_param($types, ...$params);
        $stmt_yesterday->execute();
        $result_yesterday = $stmt_yesterday->get_result();

        $running_yesterday_details = [];
        if ($result_yesterday->num_rows > 0) {
            while ($row = $result_yesterday->fetch_assoc()) {
                $running_yesterday_details[$row["ref_number"] . "-" . $row["machine_number"] . "-" . $row["setup"]] = $row;
            }
        }
        $stmt_yesterday->close();

        // આજના ચાલતા ભાગોની વિગતો મેળવો (ફિલ્ટર સાથે)
        $where_clause_today = "WHERE date = ?";
        $params_today = [$today];
        $types_today = "s";

        if (!empty($customer_filter)) {
            $where_clause_today .= " AND customer = ?";
            $params_today[] = $customer_filter;
            $types_today .= "s";
        }

        $sql_today = "SELECT DISTINCT ref_number, machine_number, setup, lot_number, lot_qty, cycle_minutes, cycle_seconds, hourly_target
                            FROM production
                            " . $where_clause_today . "
                            ORDER BY ref_number DESC, machine_number ASC, setup ASC";
        $stmt_today = $conn->prepare($sql_today);
        $stmt_today->bind_param($types_today, ...$params_today);
        $stmt_today->execute();
        $result_today = $stmt_today->get_result();

        $running_today_details = [];
        if ($result_today->num_rows > 0) {
            while ($row = $result_today->fetch_assoc()) {
                $running_today_details[$row["ref_number"] . "-" . $row["machine_number"] . "-" . $row["setup"]] = $row;
            }
        }
        $stmt_today->close();

        // પૂર્ણ થયેલા ભાગો બતાવો
        echo "<h2>Parts running on " . date("d-m-Y", strtotime($yesterday)) . " but finished on " . date("d-m-Y", strtotime($today)) . ":</h2>";
        if (!empty($finished_today_details = array_diff_key($running_yesterday_details, $running_today_details))) {
            echo "<div class='scrollable-table-container'>";
            echo "<table>";
            echo "<tr><th>Part Number</th><th>Machine Number</th><th>Setup</th><th>Lot Number</th><th>Lot Qty</th><th>Cycle Time (Minutes)</th><th>Cycle Time (Seconds)</th><th>Hourly Target</th></tr>";
            foreach ($finished_today_details as $details) {
                echo "<tr><td>" . htmlspecialchars($details["ref_number"]) . "</td><td>" . htmlspecialchars($details["machine_number"]) . "</td><td>" . htmlspecialchars($details["setup"]) . "</td><td>" . htmlspecialchars($details["lot_number"]) . "</td><td>" . htmlspecialchars($details["lot_qty"]) . "</td><td>" . htmlspecialchars($details["cycle_minutes"]) . "</td><td>" . htmlspecialchars($details["cycle_seconds"]) . "</td><td>" . htmlspecialchars($details["hourly_target"]) . "</td></tr>";
            }
            echo "</table>";
            echo "</div>";
        } else {
            echo "<p style='text-align: center;'>No parts were running on " . date("d-m-Y", strtotime($yesterday)) . " and finished on " . date("d-m-Y", strtotime($today)) . " for the selected customer.</p>";
        }

        echo "<br>";

        // આજે ચાલી રહેલા ભાગો બતાવો
        echo "<h2>Parts running on " . date("d-m-Y", strtotime($today)) . ":</h2>";
        if (!empty($running_today_details)) {
            echo "<div class='scrollable-table-container'>";
            echo "<table>";
            echo "<tr><th>Part Number</th><th>Machine Number</th><th>Setup</th><th>Lot Number</th><th>Lot Qty</th><th>Cycle Time (Minutes)</th><th>Cycle Time (Seconds)</th><th>Hourly Target</th></tr>";
            foreach ($running_today_details as $details) {
                echo "<tr><td>" . htmlspecialchars($details["ref_number"]) . "</td><td>" . htmlspecialchars($details["machine_number"]) . "</td><td>" . htmlspecialchars($details["setup"]) . "</td><td>" . htmlspecialchars($details["lot_number"]) . "</td><td>" . htmlspecialchars($details["lot_qty"]) . "</td><td>" . htmlspecialchars($details["cycle_minutes"]) . "</td><td>" . htmlspecialchars($details["cycle_seconds"]) . "</td><td>" . htmlspecialchars($details["hourly_target"]) . "</td></tr>";
            }
            echo "</table>";
            echo "</div>";
        } else {
            echo "<p style='text-align: center;'>No parts are running today (" . date("d-m-Y", strtotime($today)) . ") for the selected customer.</p>";
        }

        $conn->close();

    }

} catch (Exception $e) {
    echo "<p style='color: red; text-align: center;'>An error occurred: " . $e->getMessage() . "</p>";
} finally {
    if ($conn) {
        // ક્લોઝ કનેક્શન જો તે પહેલાં ખુલ્લું ન થયું હોય
    }
}

?>

<script>
    function resetDates() {
        document.getElementById('yesterday').value = "<?php echo date("Y-m-d", strtotime("-1 day")); ?>";
        document.getElementById('today').value = "<?php echo date("Y-m-d"); ?>";
        document.getElementById('customer').value = ""; // કસ્ટમરને પણ રિસેટ કરો
    }
</script>

</body>
</html>