<?php
include('db_connection.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM production WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('✅ Record deleted successfully.'); window.location.href='search.php';</script>";
    } else {
        echo "❌ Error deleting record: " . $conn->error;
    }

    $conn->close();
} else {
    echo "❌ Invalid Request.";
}
?>
