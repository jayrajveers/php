<?php
    session_start();

    // Check karo ke user logged in chhe ke nahi.
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        // Jo logged in nathi, to login page par redirect karo.
        header("location: login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <meta charset="UTF-8">
    <title>Rejection Data Entry</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
    /* Custom Theme CSS based on the provided dashboard image */
    * {
        box-sizing: border-box;
    }

    body {
        font-family: 'Poppins', sans-serif; /* Poppins font for modern look */
        background-color: #f0f2f5; /* Light grey background */
        margin: 0;
        padding: 20px;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        min-height: 100vh;
    }

    .container {
        background-color: #ffffff; /* White background for the main form */
        margin-top: 20px;
        padding: 30px 40px;
        border-radius: 12px; /* More rounded corners like the dashboard cards */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow for depth */
        max-width: 1200px; /* Slightly wider for better field distribution */
        width: 95%;
        border-top: 5px solid #4a90e2; /* Blue accent line at the top */
    }

    h2 {
        text-align: center;
        color: #333; /* Darker text for main heading */
        margin-bottom: 30px;
        font-size: 28px;
        font-weight: 600;
    }

    .home-button-container {
        text-align: center;
        margin-bottom: 30px;
    }

    .home-button {
        background-color: #4a90e2; /* Primary blue color */
        color: white;
        padding: 14px 30px;
        text-decoration: none;
        border-radius: 8px; /* Rounded button */
        font-weight: bold;
        font-size: 17px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        transition: background-color 0.3s ease, transform 0.2s ease;
        display: inline-block; /* Allows padding and margin to work correctly */
    }

    .home-button:hover {
        background-color: #357ABD; /* Slightly darker blue on hover */
        transform: translateY(-2px); /* Slight lift effect */
    }

    form {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); /* Adjusted grid columns for better spacing */
        gap: 25px; /* Increased gap between fields */
    }

    label {
        font-weight: 600; /* Bolder labels */
        margin-bottom: 8px;
        display: block;
        color: #555; /* Slightly lighter text for labels */
        font-size: 15px;
    }

    input[type="text"],
    input[type="number"],
    input[type="date"],
    select {
        width: 100%;
        padding: 12px; /* Increased padding for inputs */
        border-radius: 8px; /* Rounded input fields */
        border: 1px solid #e0e0e0; /* Lighter, more subtle border */
        font-size: 16px;
        background-color: #fcfcfc; /* Very light background for inputs */
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    input:focus, select:focus {
        border-color: #4a90e2; /* Blue border on focus */
        box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.2); /* Soft blue glow on focus */
        outline: none; /* Remove default outline */
    }

    .full-width {
        grid-column: 1 / -1; /* Spans across all columns */
        text-align: center;
        margin-top: 15px; /* Space before section heading */
        margin-bottom: 5px; /* Space after section heading */
    }

    h3 {
        color: #4a90e2; /* Blue for section titles */
        font-size: 22px;
        font-weight: 600;
        padding-bottom: 10px;
        border-bottom: 2px solid #e0e0e0; /* Subtle line below section titles */
        display: inline-block; /* Makes border-bottom only as wide as text */
        margin: 0 auto; /* Center the inline-block element */
    }

    button[type="submit"] {
        background-color: #28a745; /* Green submit button */
        color: #fff;
        border: none;
        padding: 14px 25px;
        font-size: 18px;
        font-weight: bold;
        border-radius: 8px;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.2s ease;
        margin-top: 25px;
        width: auto; /* Allow button to size based on content */
        display: block; /* Make it a block element to use margin auto for centering */
        margin-left: auto;
        margin-right: auto;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }

    button[type="submit"]:hover {
        background-color: #218838; /* Darker green on hover */
        transform: translateY(-2px);
    }

    /* Select2 specific styling to match the theme */
    .select2-container--default .select2-selection--single {
        height: 44px; /* Match input height */
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        background-color: #fcfcfc;
        display: flex;
        align-items: center; /* Vertically align text */
    }

    .select2-container--default .select2-selection--single .select2-selection__rendered {
        line-height: 44px; /* Ensure text is centered vertically */
        padding-left: 12px;
        color: #333;
    }

    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 42px; /* Adjust arrow height */
        right: 5px;
        top: 1px;
    }

    .select2-container--default .select2-results__option--highlighted.select2-results__option--selectable {
        background-color: #4a90e2; /* Highlight color in dropdown */
        color: white;
    }

    .select2-container--default .select2-results__option--selected {
        background-color: #f0f2f5; /* Selected item background */
        color: #333;
    }

    @media (max-width: 768px) {
        form {
            grid-template-columns: 1fr; /* Stack elements on smaller screens */
        }
        .container {
            padding: 20px;
        }
        h2 {
            font-size: 24px;
        }
        h3 {
            font-size: 20px;
        }
    }
    </style>
</head>
<body>
<script>
  document.addEventListener('keydown', function(event) {
    if (event.ctrlKey && event.key === 'Enter') {
      document.querySelector('form').submit();
    }
  });
</script>
<div class="container">
    <div class="home-button-container">
        <a href="add_data.php" class="home-button">
            Home Page
        </a>
    </div>
    <h2>Rejection Data Entry</h2>
    <form action="rejection.php" method="post">
        <label>Date: <input type="date" name="date" id="date" required></label>
        <label>Shift:<select name="shift" id="shift"><option value="">Select shift</option></select></label>
        <label>Machine Number:<select name="machine_number" id="machine_number"><option value="">Select Machine</option></select></label>
        <label>Part Code: <input type="text" name="ref_number" id="ref_number"></label>
        <label>Lot Number: <input type="text" name="lot_number" id="lot_number" readonly></label>
        <label>Operator: <input type="text" name="operator_name" id="operator_name" readonly></label>
        <label>Setter: <input type="text" name="setter" id="setter" readonly></label>

        <div class="full-width">
            <h3>Forging Section</h3>
        </div>
        <label>OD UNFILL: <input type="number" name="FORGING_OD_UNFILL" value="0"></label>
        <label>OD LAPING: <input type="number" name="FORGING_OD_LAPING" value="0"></label>
        <label>OD CRAKE: <input type="number" name="FORGING_OD_CRAKE" value="0"></label>
        <label>ID UNFILL: <input type="number" name="FORGING_BORE_UNFILL" value="0"></label>
        <label>ID LAPING: <input type="number" name="FORGING_BORE_LAPING" value="0"></label>
        <label>ID CRAKE: <input type="number" name="FORGING_BORE_CRAKE" value="0"></label>
        <label>FACE UNFILL: <input type="number" name="FORGING_WIDTH_UNFILL" value="0"></label>
        <label>FACE LAPING: <input type="number" name="FORGING_WIDTH_LAPING" value="0"></label>
        <label>FACE CRAKE: <input type="number" name="FORGING_WIDTH_CRAKE" value="0"></label>
        <label>TRACK UNFILL: <input type="number" name="FORGING_TRACK_UNFILL" value="0"></label>
        <label>TRACK LAPING: <input type="number" name="FORGING_TRACK_LAPING" value="0"></label>
        <label>TRACK CARKE: <input type="number" name="FORGING_TRACK_CARKE" value="0"></label>

        <div class="full-width">
            <h3>Inhouse & Vendor</h3>
        </div>
        <label>INHOUSE: <input type="number" name="INHOUSE" value="0"></label>
        <label>Vendor Name: <input type="text" name="VendorName" value="-"></label>
        <label>Vendor nos: <input type="number" name="Vendornos" value="0"></label>

        <div class="full-width">
            <h3>CNC Section</h3>
        </div>
        <label>WIDTH: <input type="number" name="CNC_WIDTH" value="0"></label>
        <label>ID: <input type="number" name="CNC_ID" value="0"></label>
        <label>OD: <input type="number" name="CNC_OD" value="0"></label>
        <label>TRACK: <input type="number" name="CNC_TRACK" value="0"></label>
        <label>LOCATION: <input type="number" name="CNC_LOCATION" value="0"></label>
        <label>LOADING MISTAKE: <input type="number" name="CNC_LOADING_MISTAKE" value="0"></label>
        <label>GROOVE: <input type="number" name="CNC_GROOVE" value="0"></label>
        <label>SETTING: <input type="number" name="CNC_SETTING" value="0"></label>
        <label>OTHER: <input type="number" name="CNC_OTHER" value="0"></label>

        <div class="full-width">
            <h3>Total</h3>
        </div>
        <label>FORGING TOTAL: <input type="number" name="FORGING_TOTAL" value="0" readonly></label>
        <label>CNC Total: <input type="number" name="CNC_Total" value="0" readonly></label>
        <label>VENDOR TOTAL: <input type="number" name="VENDOR_TOTAL" value="0" readonly></label>
        <label>TOTAL: <input type="number" name="TOTAL" value="0" readonly></label>

        <div class="full-width">
            <button type="submit">✅ Submit</button>
        </div>
    </form>
</div>
<script>
    function calculateTotals() {
        // FORGING SECTION TOTAL
        let forgingFields = [
            "FORGING_OD_UNFILL", "FORGING_OD_LAPING", "FORGING_OD_CRAKE",
            "FORGING_BORE_UNFILL", "FORGING_BORE_LAPING", "FORGING_BORE_CRAKE",
            "FORGING_WIDTH_UNFILL", "FORGING_WIDTH_LAPING", "FORGING_WIDTH_CRAKE",
            "FORGING_TRACK_UNFILL", "FORGING_TRACK_LAPING", "FORGING_TRACK_CARKE"
        ];
        let forgingTotal = forgingFields.reduce((sum, field) => {
            return sum + (parseInt(document.getElementsByName(field)[0].value) || 0);
        }, 0);
        document.getElementsByName("FORGING_TOTAL")[0].value = forgingTotal;

        // CNC SECTION TOTAL
        let cncFields = [
            "CNC_WIDTH", "CNC_ID", "CNC_OD", "CNC_TRACK",
            "CNC_LOCATION", "CNC_LOADING_MISTAKE", "CNC_GROOVE",
            "CNC_SETTING", "CNC_OTHER"
        ];
        let cncTotal = cncFields.reduce((sum, field) => {
            return sum + (parseInt(document.getElementsByName(field)[0].value) || 0);
        }, 0);
        document.getElementsByName("CNC_Total")[0].value = cncTotal;

        // VENDOR TOTAL (INHOUSE + Vendornos)
        let inhouse = parseInt(document.getElementsByName("INHOUSE")[0].value) || 0;
        let vendorNos = parseInt(document.getElementsByName("Vendornos")[0].value) || 0;
        let vendorTotal = inhouse + vendorNos;
        document.getElementsByName("VENDOR_TOTAL")[0].value = vendorTotal;

        // FINAL TOTAL
        let finalTotal = forgingTotal + cncTotal + vendorTotal;
        document.getElementsByName("TOTAL")[0].value = finalTotal;
    }

    // Auto-update totals when any input changes
    document.querySelectorAll('input[type="number"]').forEach(input => {
        input.addEventListener('input', calculateTotals);
    });

    $(document).ready(function() {
        $('#date').on('change', function() {
            var selectedDate = $(this).val();
            $('#shift').empty().append('<option value="">Select shift</option>');
            $('#machine_number').empty().append('<option value="">Select Machine</option>');
            $('#ref_number').val('');
            $('#lot_number').val('');
            $('#operator_name').val('');
            $('#setter').val('');

            if (selectedDate) {
                $.ajax({
                    url: 'get_shifts.php', // નવી PHP ફાઇલ
                    type: 'POST',
                    data: { date: selectedDate },
                    dataType: 'json',
                    success: function(data) {
                        var shiftSelect = $('#shift');
                        shiftSelect.empty().append('<option value="">Select shift</option>');
                        $.each(data, function(key, value) {
                            shiftSelect.append('<option value="' + value + '">' + value + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching shifts:", error);
                    }
                });
            }
        });

        $('#shift').on('change', function() {
            var selectedShift = $(this).val();
            var selectedDate = $('#date').val();
            $('#machine_number').empty().append('<option value="">Select Machine</option>');
            $('#ref_number').val('');
            $('#lot_number').val('');
            $('#operator_name').val('');
            $('#setter').val('');

            if (selectedShift && selectedDate) {
                $.ajax({
                    url: 'get_machines.php', // તમારી જૂની get_machines.php ફાઇલ
                    type: 'POST',
                    data: { date: selectedDate, shift: selectedShift },
                    dataType: 'json',
                    success: function(data) {
                        var machineSelect = $('#machine_number');
                        machineSelect.empty().append('<option value="">Select Machine</option>');
                        $.each(data, function(key, value) {
                            machineSelect.append('<option value="' + value + '">' + value + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching machines:", error);
                    }
                });
            }
        });

        $('#machine_number').on('change', function() {
            var selectedMachine = $(this).val();
            var selectedDate = $('#date').val();
            var selectedShift = $('#shift').val();
            if (selectedMachine && selectedDate && selectedShift) {
                $.ajax({
                    url: 'get_machine_details.php',
                    type: 'POST',
                    data: { date: selectedDate, machine: selectedMachine, shift: selectedShift },
                    dataType: 'json',
                    success: function(data) {
                        if (data) {
                            $('#ref_number').val(data.ref_number || '');
                            $('#lot_number').val(data.lot_number || '');
                            $('#operator_name').val(data.operator_name || '');
                            $('#setter').val(data.setter_name || '');
                        } else {
                            $('#ref_number').val('');
                            $('#lot_number').val('');
                            $('#operator_name').val('');
                            $('#setter').val('');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching machine details:", error);
                    }
                });
            } else {
                $('#ref_number').val('');
                $('#lot_number').val('');
                $('#operator_name').val('');
                $('#setter').val('');
            }
        });
    });
</script>

</body>
</html>