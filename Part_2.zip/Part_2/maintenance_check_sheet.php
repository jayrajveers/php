<?php
$machineNumber = isset($_GET['machine']) ? htmlspecialchars($_GET['machine']) : '';
$checkDate = isset($_GET['date']) ? htmlspecialchars($_GET['date']) : '';
$shiftValue = isset($_GET['shift']) ? htmlspecialchars($_GET['shift']) : '';
?>

<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CNC मशीन डेली मेंटेनेंस चेकशीट</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            background-color: #f0f2f5;
            color: #1c1e21;
        }

        h1, h2 {
            text-align: center;
            color: #1877f2;
            margin-bottom: 20px;
        }

        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            max-width: 750px;
            margin: 30px auto;
            padding: 25px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }

        select,
        input[type="date"],
        input[type="text"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 18px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .check-item {
            border-bottom: 1px solid #eee;
            padding-bottom: 18px;
            margin-bottom: 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .check-item:last-child {
            border-bottom: none;
        }

        .param {
            font-style: italic;
            color: #65676b;
            font-size: 14px;
        }

        .check-label {
            font-weight: bold;
            flex-grow: 1;
        }

        .check-input {
            width: 100px;
            text-align: center;
        }

        h2 {
            margin-top: 25px;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
        }

        button[type="submit"] {
            background-color: #1877f2;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            transition: background-color 0.3s ease;
            margin-top: 20px;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

        button[type="submit"]:hover {
            background-color: #166fe5;
        }

        .radio-group {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .error-message {
            margin-top: 20px;
            padding: 10px;
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
        }

        .success-message {
            margin-top: 20px;
            padding: 10px;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>CNC मशीन डेली मेंटेनेंस चेकशीट</h1>

        <label for="machine_number">मशीन नंबर:</label>
        <input type="text" id="machine_number" name="machine_number" value="<?php echo $machineNumber; ?>" readonly><br>

        <label for="date">तारीख:</label>
        <input type="date" id="date" name="date" value="<?php echo $checkDate; ?>" readonly><br>

        <label for="shift">शिफ्ट:</label>
        <input type="text" id="shift" name="shift" value="<?php echo $shiftValue; ?>" readonly><br>

        <h2>डेली चेक
            <span class="param">Note: In case of minor abnormality, like air / oil leakage, plan to attend during lunch period. </span>
        </h2>

        <form method="POST" action="submit_maintenance.php">
            <div class="check-item">
                <span class="check-label">लुब्रिकेशन टैंक ऑयल की मात्रा चेक कीजिए:</span>
                <span class="param">60% तक मिनिमम</span>
                <div class="radio-group">
                    <label><input type="radio" name="lubrication_tank_oil_level" value="ok" required>ओके</label>
                    <label><input type="radio" name="lubrication_tank_oil_level" value="low">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">हाइड्रोलिक टैंक के ऑयल की मात्रा चेक कीजिए:</span>
                <span class="param">60% तक मिनिमम</span>
                <div class="radio-group">
                    <label><input type="radio" name="hydraulic_tank_oil_level" value="ok" required>ओके</label>
                    <label><input type="radio" name="hydraulic_tank_oil_level" value="low">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">हाइड्रोलिक का दबाव चेक कीजिए:</span>
                <span class="param">30 केजी/सीएम²</span>
                <input type="text" class="check-input" name="hydraulic_pressure" required>
            </div>

            <div class="check-item">
                <span class="check-label">एक्सिस स्लाइड कवर चेक कीजिए:</span>
                <span class="param">हर रोज</span>
                <div class="radio-group">
                    <label><input type="radio" name="axis_slide_cover" value="ok" required>ओके</label>
                    <label><input type="radio" name="axis_slide_cover" value="not_ok">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">मशीन मेसें और मशीन के आसपास ऑयल, कूलेंट और एयर लीकेज चेक कीजिए:</span>
                <span class="param">हर रोज</span>
                <div class="radio-group">
                    <label><input type="radio" name="machine_mess_oil_coolant_leakage" value="no_leakage" required>ओके</label>
                    <label><input type="radio" name="machine_mess_oil_coolant_leakage" value="leakage_found">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">चिप्स मशीन कन्वेयर काम कर रहा है कि नहीं उसकी जांच करें:</span>
                <span class="param">हर रोज</span>
                <div class="radio-group">
                    <label><input type="radio" name="chips_machine_conveyor_working" value="working" required>ओके</label>
                    <label><input type="radio" name="chips_machine_conveyor_working" value="not_working">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">केंद्रीय टैंक का कूलेंट लेवल चेक कीजिए:</span>
                <span class="param">40% तक मिनिमम</span>
                <div class="radio-group">
                    <label><input type="radio" name="central_tank_coolant_level" value="ok" required>ओके</label>
                    <label><input type="radio" name="central_tank_coolant_level" value="low">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">कूलेंट पी. एच. चेक कीजिए:</span>
                <span class="param">8% - 10%</span>
                <input type="text" class="check-input" name="coolant_ph" required>
            </div>

            <div class="check-item">
                <span class="check-label">चिप्स कन्वेयर की मोटर काम कर रही है कि नहीं उसकी जांच करें:</span>
                <span class="param">निर्धारित गति</span>
                <div class="radio-group">
                    <label><input type="radio" name="chips_conveyor_motor_working" value="working" required>ओके</label>
                    <label><input type="radio" name="chips_conveyor_motor_working" value="not_working">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">तापमान चेक करे (A.C. के लिए):</span>
                <span class="param">30 ~ 42</span>
                <input type="text" class="check-input" name="tapan_check_ac" required>
            </div>

            <div class="check-item">
                <span class="check-label">ए. सी. गार्ड स्वच्छ करे:</span>
                <span class="param">धूल से मुक्त</span>
                <div class="radio-group">
                    <label><input type="radio" name="ac_guard_clean" value="yes" required>ओके</label>
                    <label><input type="radio" name="ac_guard_clean" value="no">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">ए. सी. फिल्टर चेक करे:</span>
                <span class="param">धूल से मुक्त</span>
                <div class="radio-group">
                    <label><input type="radio" name="ac_filter_check" value="ok" required>ओके</label>
                    <label><input type="radio" name="ac_filter_check" value="dirty">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">चक, जोस और कोलेट स्वच्छ करे:</span>
                <span class="param">धूल और चिप्स से मुक्त</span>
                <div class="radio-group">
                    <label><input type="radio" name="chuck_jaws_collet_clean" value="yes" required>ओके</label>
                    <label><input type="radio" name="chuck_jaws_collet_clean" value="no">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">C.N.C. गार्ड सभी स्वच्छ करे:</span>
                <span class="param">धूल और चिप्स से मुक्त</span>
                <div class="radio-group">
                    <label><input type="radio" name="cnc_guard_clean_all" value="yes" required>ओके</label>
                    <label><input type="radio" name="cnc_guard_clean_all" value="no">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">टूल और इन्सर्टर होल्डर की जांच करे:</span>
                <span class="param">तनाव</span>
                <div class="radio-group">
                    <label><input type="radio" name="tool_inner_holder_check" value="tight" required>ओके</label>
                    <label><input type="radio" name="tool_inner_holder_check" value="loose">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">Check Tool & Inserter Holder:</span>
                <span class="param">Tightness</span>
                <div class="radio-group">
                    <label><input type="radio" name="check_tool_inserter_holder_tightness" value="tight" required>ओके</label>
                    <label><input type="radio" name="check_tool_inserter_holder_tightness" value="loose">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">चक का दबाव चेक करे:</span>
                <span class="param">3 ~ 12 Kg / Cm2</span>
                <input type="text" class="check-input" name="chuck_pressure_check" required>
            </div>

            <div class="check-item">
                <span class="check-label">एक्सिस स्लाइड कवर मूवमेंट की जांच करे:</span>
                <span class="param">निर्धारित गति</span>
                <div class="radio-group">
                    <label><input type="radio" name="axis_slide_cover_movement_check" value="ok" required>ओके</label>
                    <label><input type="radio" name="axis_slide_cover_movement_check" value="not_ok">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">चक का ग्रीसिंग चेक करे:</span>
                <span class="param">हर रोज</span>
                <div class="radio-group">
                    <label><input type="radio" name="chuck_greasing_check" value="done" required>ओके</label>
                    <label><input type="radio" name="chuck_greasing_check" value="not_done">नोट ओके</label>
                </div>
            </div>

            <div class="check-item">
                <span class="check-label">मशीन मेसें किसी भी असामान्य ध्वनि चेक कीजिए:</span>
                <span class="param">हर रोज</span>
                <div class="radio-group">
                    <label><input type="radio" name="machine_mess_abnormal_sound_check" value="no" required>ओके</label>
                    <label><input type="radio" name="machine_mess_abnormal_sound_check" value="yes">नोट ओके</label>
                </div>
            </div>

            <input type="hidden" name="machine_number" value="<?php echo $machineNumber; ?>">
    <input type="hidden" name="date" value="<?php echo $checkDate; ?>">
    <input type="hidden" name="shift" value="<?php echo $shiftValue; ?>">
    <button type="submit" name="submit_all_data">सबमिट करे और वापस जाएँ</button>
</form>
    </div>
</body>
</html>