// Helper function to escape HTML for display
function escapeHtml(str) {
    // Check if str is null, undefined, or not a string/number
    if (typeof str !== 'string' && typeof str !== 'number') {
        return ''; // Return an empty string if it's null, undefined, or not a string/number
    }
    var div = document.createElement('div');
    // Ensure str is treated as a string for textNode
    div.appendChild(document.createTextNode(String(str))); // Convert to string before creating text node
    return div.innerHTML;
}

// Function to load setups based on selected part ID
function loadSetups() {
    const partId = document.getElementById('part_id').value;
    const setupSelect = document.getElementById('setup_info');
    setupSelect.innerHTML = '<option value="">-- સેટઅપ પસંદ કરો --</option>'; // Clear existing options
    document.getElementById('batch_number_filter').innerHTML = '<option value="">-- બધા બેચ/લોટ નંબર --</option>'; // Clear batch numbers
    document.getElementById('measurement_date_filter').innerHTML = '<option value="">-- બધી તારીખો --</option>'; // Clear dates
    document.getElementById('report_area').style.display = 'none'; // Hide report area

    if (partId) {
        fetch(`inprocess_report_view.php?action=get_setups_for_part&part_id=${partId}`)
            .then(response => response.json())
            .then(data => {
                data.forEach(setup => {
                    const option = document.createElement('option');
                    option.value = escapeHtml(setup.setup_info);
                    option.textContent = escapeHtml(setup.setup_info);
                    setupSelect.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Error loading setups:', error);
                alert('સેટઅપ્સ લોડ કરવામાં ભૂલ થઈ.');
            });
    }
}

// Function to load batch numbers based on selected part ID and setup info
function loadBatchNumbers() {
    const partId = document.getElementById('part_id').value;
    const setupInfo = document.getElementById('setup_info').value;
    const batchNumberSelect = document.getElementById('batch_number_filter');
    batchNumberSelect.innerHTML = '<option value="">-- બધા બેચ/લોટ નંબર --</option>'; // Clear existing options
    document.getElementById('measurement_date_filter').innerHTML = '<option value="">-- બધી તારીખો --</option>'; // Clear dates
    document.getElementById('report_area').style.display = 'none'; // Hide report area

    if (partId && setupInfo) {
        fetch(`inprocess_report_view.php?action=get_batch_numbers_for_setup&part_id=${partId}&setup_info=${encodeURIComponent(setupInfo)}`)
            .then(response => response.json())
            .then(data => {
                data.forEach(batch => {
                    const option = document.createElement('option');
                    option.value = escapeHtml(batch.batch_number);
                    option.textContent = escapeHtml(batch.batch_number);
                    batchNumberSelect.appendChild(option);
                });
                // After loading batch numbers, load measurement dates
                loadMeasurementDates();
            })
            .catch(error => {
                console.error('Error loading batch numbers:', error);
                alert('બેચ નંબર લોડ કરવામાં ભૂલ થઈ.');
            });
    }
}

// Function to load measurement dates based on selected part ID, setup info, and batch number
function loadMeasurementDates() {
    const partId = document.getElementById('part_id').value;
    const setupInfo = document.getElementById('setup_info').value;
    const batchNumber = document.getElementById('batch_number_filter').value;
    const dateSelect = document.getElementById('measurement_date_filter');
    dateSelect.innerHTML = '<option value="">-- બધી તારીખો --</option>'; // Clear existing options
    document.getElementById('report_area').style.display = 'none'; // Hide report area

    if (partId && setupInfo) {
        let url = `inprocess_report_view.php?action=get_measurement_dates&part_id=${partId}&setup_info=${encodeURIComponent(setupInfo)}`;
        if (batchNumber) {
            url += `&batch_number=${encodeURIComponent(batchNumber)}`;
        }

        fetch(url)
            .then(response => response.json())
            .then(data => {
                data.forEach(dateEntry => {
                    const option = document.createElement('option');
                    option.value = escapeHtml(dateEntry.measurement_date);
                    // Format date for display (e.g., DD-MM-YYYY)
                    const displayDate = new Date(dateEntry.measurement_date).toLocaleDateString('gu-IN');
                    option.textContent = escapeHtml(displayDate);
                    dateSelect.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Error loading measurement dates:', error);
                alert('માપનની તારીખો લોડ કરવામાં ભૂલ થઈ.');
            });
    }
}

// Global variable to hold all chart instances
let inProcessChartInstances = {};

// Function to load the report and generate runcharts
function loadReport() {
    const partId = document.getElementById('part_id').value;
    const setupInfo = document.getElementById('setup_info').value;
    const batchNumber = document.getElementById('batch_number_filter').value;
    const selectedDate = document.getElementById('measurement_date_filter').value;

    const reportTableDiv = document.getElementById('inprocess_report_table');
    const reportArea = document.getElementById('report_area');
    const runchartContainer = document.getElementById('runchart_container'); // Get the runchart container

    reportTableDiv.innerHTML = '<p>લોડ કરી રહ્યું છે...</p>';
    reportArea.style.display = 'none';
    runchartContainer.style.display = 'none'; // Hide runchart container initially

    // Clear previous charts
    for (const chartId in inProcessChartInstances) {
        if (inProcessChartInstances[chartId]) {
            inProcessChartInstances[chartId].destroy();
        }
    }
    inProcessChartInstances = {}; // Reset the object
    runchartContainer.innerHTML = ''; // Clear the container of old canvases

    if (!partId || !setupInfo) {
        reportTableDiv.innerHTML = '<p>કૃપા કરીને પાર્ટ નંબર અને સેટઅપ પસંદ કરો.</p>';
        return;
    }

    let url = `inprocess_report_view.php?action=get_inprocess_report_data&part_id=${partId}&setup_info=${encodeURIComponent(setupInfo)}`;
    if (batchNumber) {
        url += `&batch_number=${encodeURIComponent(batchNumber)}`;
    }
    if (selectedDate) {
        url += `&selected_date=${encodeURIComponent(selectedDate)}`;
    }

    fetch(url)
        .then(response => response.json())
        .then(reportData => {
            reportTableDiv.innerHTML = ''; // Clear loading message

            if (reportData.length > 0) {
                // --- TABLE GENERATION ---
                const groupedData = {};
                let distinctTimes = new Set();
                reportData.forEach(row => {
                    const dateTimeKey = row.measurement_date;
                    distinctTimes.add(dateTimeKey);

                    if (!groupedData[dateTimeKey]) {
                        groupedData[dateTimeKey] = {
                            operator_name: row.operator_name,
                            batch_number: row.batch_number,
                            heat_number: row.heat_number,
                            machine_id: row.machine_id,
                            measurements: []
                        };
                    }
                    groupedData[dateTimeKey].measurements.push(row);
                });

                const sortedDates = Array.from(distinctTimes).sort();

                const uniqueParameters = [];
                const parameterMap = new Map();
                reportData.forEach(row => {
                    if (!parameterMap.has(row.parameter_id)) {
                        parameterMap.set(row.parameter_id, {
                            parameter_id: row.parameter_id,
                            parameter_name: row.parameter_name,
                            specification: row.specification,
                            spec_positive: row.spec_positive,
                            spec_negative: row.spec_negative
                        });
                        uniqueParameters.push({
                            parameter_id: row.parameter_id,
                            parameter_name: row.parameter_name,
                            specification: row.specification,
                            spec_positive: row.spec_positive,
                            spec_negative: row.spec_negative
                        });
                    }
                });
                // Sort unique parameters by name for consistent display
                uniqueParameters.sort((a, b) => a.parameter_name.localeCompare(b.parameter_name));

                const firstRow = reportData[0]; // Use data from the first row for general info

                let tableHtml = `
                <div class="report-header">
                    <div class="header-row">
                        <div class="header-cell"></div>
                        <div class="header-cell header-title">FINAL INSPECTION REPORT (AQL 0.65%)</div>
                        <div class="header-cell header-info">
                            <p><strong>Formate No.</strong> F QA 52</p>
                            <p><strong>Revi. No./Date</strong> 01/18-03-2025</p>
                            <p><strong>Inspection Date</strong> ${firstRow.measurement_date ? new Date(firstRow.measurement_date).toLocaleDateString('gu-IN') : ''}</p>
                        </div>
                    </div>
                    <div class="header-details">
                        <div class="detail-row">
                            <p><strong>Po No:</strong> </p>
                            <p><strong>Part Name:</strong> ${escapeHtml(firstRow.part_name ?? '')}</p>
                            <p><strong>Heat No:</strong> ${escapeHtml(firstRow.heat_number ?? '')}</p>
                        </div>
                        <div class="detail-row">
                            <p><strong>Dispatch Qty:</strong> </p>
                            <p><strong>Part. No:</strong> ${escapeHtml(firstRow.part_number ?? '')} ${firstRow.part_code ? `(${escapeHtml(firstRow.part_code ?? '')})` : ''}</p>
                            <p><strong>Grade:</strong> ${escapeHtml(firstRow.grade ?? '')}</p>
                        </div>
                        <div class="detail-row">
                            <p><strong>Challan No:</strong> </p>
                            <p><strong>Customer Drg. No. & REV.</strong> ${escapeHtml(firstRow.drawing_revision ?? '')}</p>
                            <p><strong>Lot No:</strong> ${escapeHtml(firstRow.batch_number ?? '')}</p>
                        </div>
                        <div class="detail-row">
                            <p><strong>SPCR No:</strong> </p>
                            <p><strong>Customer Name:</strong> ${escapeHtml(firstRow.customer_name ?? '')}</p>
                            <p><strong>Lot Qty:</strong> </p>
                        </div>
                        <div class="detail-row">
                            <p><strong>RMTC No:</strong> </p>
                            <p><strong>Opretor Name:</strong> ${escapeHtml(firstRow.operator_name ?? '')}</p>
                            <p><strong>Machine No:</strong> ${escapeHtml(firstRow.machine_id ?? '')}</p>
                        </div>
                    </div>
                </div>
                <table>
                `;

                tableHtml += '<h2>All Dimensions are in mm</h2>';

                tableHtml += `
                    <table>
                        <thead>
                            <tr>
                                <th rowspan="2">No</th>
                                <th rowspan="2">Parameter</th>
                                <th rowspan="2">Specification</th>
                                <th colspan="${sortedDates.length * 2}">Observation ( All Dimensions are in mm.) Hourly Inspection Qty 5pcs & Recorded 2 Pcs.</th>
                            </tr>
                            <tr>
                `;

                // Add dynamic time columns with + and - sub-columns
                sortedDates.forEach((date, index) => {
                    const displayTime = new Date(date).toLocaleTimeString('gu-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
                    tableHtml += `<th colspan="2">${index + 1} Nos Time <br> (${displayTime})</th>`;
                });

                tableHtml += `
                            </tr>
                            <tr>
                `;

                // Add + અને - headers for each time slot
                tableHtml += `<th colspan="3"></th>`; // Empty cells for No, Parameter, Specification
                sortedDates.forEach(() => {
                    tableHtml += `<th>+ વિચલન</th><th>- વિચલન</th>`; // + and - deviation headers
                });
                tableHtml += `</tr>`;

                tableHtml += `
                        </thead>
                        <tbody>
                `;

                // Populate table rows for each parameter
                uniqueParameters.forEach((param, index) => {
                    tableHtml += `
                        <tr>
                            <td>${index + 1}</td>
                            <td>${escapeHtml(param.parameter_name)}</td>
                            <td>${escapeHtml(param.specification ?? '')} ${param.spec_positive !== null && param.spec_negative !== null ? `(+${escapeHtml(param.spec_positive)} / -${escapeHtml(param.spec_negative)})` : ''}</td>
                    `;

                    // Add measurement values for each time slot with separate + and - columns
                    sortedDates.forEach(dateKey => {
                        const measurementsForThisTimeAndParam = reportData.filter(m =>
                            m.parameter_id === param.parameter_id && m.measurement_date === dateKey
                        );

                        let positiveCellContent = '';
                        let negativeCellContent = '';
                        let isConformingRow = true; // Assume conforming initially for the row

                        if (measurementsForThisTimeAndParam.length > 0) {
                            const measurement = measurementsForThisTimeAndParam[0]; // Take the first for now
                            const positiveDeviation = measurement.positive_deviation_input;
                            const negativeDeviation = measurement.negative_deviation_input;
                            const isConforming = measurement.is_conforming == 1;

                            if (positiveDeviation !== null && positiveDeviation !== '') {
                                positiveCellContent = escapeHtml(positiveDeviation);
                                if (!isConforming) {
                                    positiveCellContent = `<span class="non-conforming-value">${positiveCellContent} (NG)</span>`;
                                    isConformingRow = false; // Mark row as non-conforming
                                }
                            }

                            if (negativeDeviation !== null && negativeDeviation !== '') {
                                negativeCellContent = escapeHtml(negativeDeviation);
                                if (!isConforming) {
                                    negativeCellContent = `<span class="non-conforming-value">${negativeCellContent} (NG)</span>`;
                                    isConformingRow = false; // Mark row as non-conforming
                                }
                            }
                        }

                        tableHtml += `<td>${positiveCellContent}</td><td>${negativeCellContent}</td>`;
                    });
                    tableHtml += `</tr>`;
                });

                tableHtml += '</tbody></table>';

                // Add Footer HTML
                tableHtml += `
                    <div class="report-footer">
                        <div class="footer-section">
                            <p><strong>CONTRACER:</strong> Verified at setting approval n=1 FOUND OKAY</p>
                        </div>
                        <div class="footer-section">
                            <p><strong>CRACK DETECTOR (MPI):</strong></p>
                        </div>
                        <div class="footer-section">
                            <p><strong>RUST & APO.:</strong> Free from rust - Okay accepted and applied Ferrocoate 5856 RFT3 XRO and packed with VCI bags</p>
                            <p>SAP-Spherodised Annealing Process No.</p>
                        </div>
                        <div class="footer-section">
                            <p><strong>MATERIAL CHECK:</strong></p>
                        </div>
                        <div class="footer-section imte-section">
                            <p><strong>IMTE:</strong></p>
                            <div class="imte-list">
                                <p>1. Slip Gauge</p>
                                <p>2. Spin Gauge With Dial Indicator</p>
                                <p>3. Micro Meter</p>
                                <p>4. Vernier Calipers</p>
                                <p>5. Crack Detector (MPI)</p>
                                <p>6. CMM</p>
                                <p>7. Contracer</p>
                                <p>8. Visual</p>
                                <p>9. Niton Gun</p>
                            </div>
                        </div>
                        <div class="footer-prepared-approved">
                            <p><strong>Prepared By:</strong> ${escapeHtml(firstRow.inspector_name ?? '')}</p>
                            <p><strong>Approved By:</strong>Jankbhai Dalvadi</p>
                        </div>
                    </div>
                `;

                reportTableDiv.innerHTML = tableHtml;
                reportArea.style.display = 'block'; // Show report area

                // --- RUNCHART GENERATION ---
                createRunchart(reportData, uniqueParameters); // Pass reportData and uniqueParameters to the chart function
                runchartContainer.style.display = 'block'; // Show the runchart container
            } else {
                reportTableDiv.innerHTML = '<p>આ પાર્ટ, સેટઅપ, બેચ નંબર અને પસંદ કરેલી તારીખ માટે કોઈ ઇન-પ્રોસેસ માપન મળ્યા નથી.</p>';
                runchartContainer.style.display = 'none'; // Hide runchart if no data
            }
        })
        .catch(error => {
            console.error('Error loading in-process report data:', error);
            reportTableDiv.innerHTML = '<p class="info-message error">રિપોર્ટ ડેટા લોડ કરવામાં ભૂલ થઈ.</p>';
            runchartContainer.style.display = 'none'; // Hide runchart on error
        });
}

// Function to create individual runcharts for each parameter
function createRunchart(reportData, uniqueParameters) {
    const runchartContainer = document.getElementById('runchart_container');

    // Clear previous charts and their containers
    for (const chartId in inProcessChartInstances) {
        if (inProcessChartInstances[chartId]) {
            inProcessChartInstances[chartId].destroy();
        }
    }
    inProcessChartInstances = {}; // Reset the object
    runchartContainer.innerHTML = ''; // Clear the container of old canvases

    if (uniqueParameters.length === 0) {
        runchartContainer.innerHTML = '<p>ચાર્ટ બનાવવા માટે કોઈ પેરામીટર ડેટા ઉપલબ્ધ નથી.</p>';
        return;
    }

    // Extract all unique measurement dates/times once for consistent X-axis
    const allMeasurementDates = [...new Set(reportData.map(d => d.measurement_date))].sort();
    const labels = allMeasurementDates.map(dateStr => {
        // Format time for chart labels (e.g., 10:00 AM)
        return new Date(dateStr).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
    });

    uniqueParameters.forEach(param => {
        // Create a new canvas for each parameter
        const chartId = `chart_${param.parameter_id}`;
        const chartTitle = `રનચાર્ટ: ${escapeHtml(param.parameter_name)}`; // Chart title based on parameter name

        const paramChartDiv = document.createElement('div');
        paramChartDiv.style.marginBottom = '30px'; // Add some spacing between charts
        paramChartDiv.innerHTML = `<h4>${chartTitle}</h4><canvas id="${chartId}"></canvas>`;
        runchartContainer.appendChild(paramChartDiv);

        const ctx = document.getElementById(chartId).getContext('2d');

        const measuredData = [];
        // Use spec_positive and spec_negative to calculate limits
        const specificationValue = parseFloat(param.specification);
        const specPositive = parseFloat(param.spec_positive);
        const specNegative = parseFloat(param.spec_negative);

        let lowerSpec = null;
        let upperSpec = null;

        // Calculate LSL and USL based on specification and deviations
        if (!isNaN(specificationValue) && !isNaN(specNegative)) {
            lowerSpec = specificationValue - specNegative;
        }
        if (!isNaN(specificationValue) && !isNaN(specPositive)) {
            upperSpec = specificationValue + specPositive;
        }

        // Populate data points for this specific parameter across all measurement times
        allMeasurementDates.forEach(dateStr => {
            const measurement = reportData.find(d =>
                d.parameter_id === param.parameter_id && d.measurement_date === dateStr
            );
            // For runchart, use the measured_value as it represents the actual point.
            measuredData.push(measurement ? parseFloat(measurement.measured_value) : null);
        });

        const datasets = [
            {
                label: `માપેલ મૂલ્ય`,
                data: measuredData,
                borderColor: 'rgba(75, 192, 192, 1)', // A standard color for measured value
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                fill: false,
                tension: 0.1,
                pointRadius: 5,
                pointHoverRadius: 8
            }
        ];

        // Add specification lines if available and meaningful (e.g., if spec is a number)
        if (!isNaN(specificationValue)) {
            datasets.push({
                label: `નોમિનલ સ્પષ્ટીકરણ`,
                data: Array(labels.length).fill(specificationValue),
                borderColor: 'rgba(0, 0, 255, 0.7)', // Blue for nominal spec
                borderDash: [5, 5],
                fill: false,
                pointRadius: 0
            });
        }
        if (lowerSpec !== null && !isNaN(lowerSpec)) {
             datasets.push({
                label: `નીચી મર્યાદા (LSL)`,
                data: Array(labels.length).fill(lowerSpec),
                borderColor: 'rgba(255, 0, 0, 0.7)', // Red for lower spec limit
                borderDash: [5, 5],
                fill: false,
                pointRadius: 0
            });
        }
        if (upperSpec !== null && !isNaN(upperSpec)) {
            datasets.push({
                label: `ઉચ્ચ મર્યાદા (USL)`,
                data: Array(labels.length).fill(upperSpec),
                borderColor: 'rgba(255, 0, 0, 0.7)', // Red for upper spec limit
                borderDash: [5, 5],
                fill: false,
                pointRadius: 0
            });
        }

        // Create the chart for the current parameter
        inProcessChartInstances[chartId] = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: chartTitle
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'માપનનો સમય'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'માપેલ મૂલ્ય (mm)' // Assuming mm, adjust as needed
                        }
                    }
                }
            }
        });
    });
}

// Initial load of setups when the page loads
document.addEventListener('DOMContentLoaded', loadSetups);