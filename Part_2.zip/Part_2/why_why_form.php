<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CNC Production Why-Why Analysis (IATF Compliant)</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f8f9fa;
            color: #333;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            max-width: 900px;
            margin: auto;
            border-top: 5px solid #0056b3;
        }
        h2 {
            color: #0056b3;
            text-align: center;
            margin-bottom: 25px;
            font-size: 2em;
        }
        h3 {
            color: #007bff;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-top: 30px;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 18px;
        }
        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
            color: #555;
        }
        input[type="text"],
        input[type="date"],
        input[type="time"],
        textarea,
        select {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            font-size: 1rem;
            box-sizing: border-box; /* Ensures padding doesn't affect width */
        }
        textarea {
            resize: vertical;
            min-height: 80px;
        }
        .why-field, .team-member-field {
            margin-top: 10px;
            padding-left: 20px;
            border-left: 3px solid #007bff;
            background-color: #e9f5ff;
            padding: 15px;
            border-radius: 5px;
        }
        .why-field label, .team-member-field label {
            color: #0056b3;
        }
        button {
            background-color: #28a745;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1rem;
            display: block;
            width: 100%;
            margin-top: 30px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #218838;
        }
        .add-btn {
            background-color: #007bff;
            width: auto;
            padding: 8px 15px;
            margin-top: 5px;
            float: right;
        }
        .add-btn:hover {
            background-color: #0056b3;
        }
        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }
        .checkbox-group {
            display: flex;
            align-items: center;
            margin-top: 10px;
        }
        .checkbox-group input {
            width: auto;
            margin-right: 10px;
        }
        /* Style for the new Home Page button */
        .home-button {
            display: inline-block;
            background-color: #6c757d; /* Grey color */
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            margin-bottom: 20px; /* Space below the button */
            transition: background-color 0.3s ease;
            text-align: center;
            float: left; /* Align to the left */
        }
        .home-button:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="add_data.php" class="home-button">HOME PAGE</a>
        <div class="clearfix"></div> <h2>CNC પ્રોડક્શન Why-Why Analysis ફોર્મ</h2>

        <form action="process_why_why_iatf.php" method="POST">

            <h3>સામાન્ય માહિતી (General Information)</h3>
            <div class="form-group">
                <label for="analysis_date">એનાલિસિસ તારીખ:</label>
                <input type="date" id="analysis_date" name="analysis_date" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label for="machine_id">મશીન ID:</label>
                <input type="text" id="machine_id" name="machine_id" placeholder="દા.ત. CNC-001" required>
            </div>
            <div class="form-group">
                <label for="part_name">પાર્ટનું નામ / જોબ ID:</label>
                <input type="text" id="part_name" name="part_name" placeholder="દા.ત. Bracket-V2 / J-501" required>
            </div>

            <h3>સમસ્યા/બિન-અનુરૂપતાનું વર્ણન (Problem/Nonconformity Description)</h3>
            <div class="form-group">
                <label for="problem_statement">મુખ્ય સમસ્યાનું સંક્ષિપ્ત વર્ણન (Problem Statement):</label>
                <textarea id="problem_statement" name="problem_statement" placeholder="મુખ્ય સમસ્યાનું સંક્ષિપ્ત વર્ણન કરો." required></textarea>
            </div>
            <div class="form-group">
                <label for="what_happened">શું થયું? (What happened? - બિન-અનુરૂપ ઉત્પાદન/પ્રક્રિયા):</label>
                <textarea id="what_happened" name="what_happened" placeholder="દા.ત. 'પાર્ટ પર ડાયમેન્શન આઉટ ઓફ સ્પેશિફિકેશન છે (X.XX mm)'"></textarea>
            </div>
            <div class="form-group">
                <label for="where_happened">ક્યાં થયું? (Where happened? - મશીન, પ્રક્રિયા, લાઇન):</label>
                <input type="text" id="where_happened" name="where_happened" placeholder="દા.ત. 'મશીન #3, ઓપરેશન 20, પ્રોડક્શન લાઇન A'">
            </div>
            <div class="form-group">
                <label for="when_happened_date">ક્યારે થયું? (When happened? - તારીખ):</label>
                <input type="date" id="when_happened_date" name="when_happened_date">
                <label for="when_happened_time">ક્યારે થયું? (સમય):</label>
                <input type="time" id="when_happened_time" name="when_happened_time">
            </div>
            <div class="form-group">
                <label for="who_found">કોણે શોધ્યું? (Who found? - ઓપરેટર, QC, સુપરવાઈઝર):</label>
                <input type="text" id="who_found" name="who_found" placeholder="દા.ત. 'ઓપરેટર રમેશભાઈ, શિફ્ટ B'">
            </div>
            <div class="form-group">
                <label for="how_much_impact">કેટલું થયું? (How much? - માત્રા/ટકાવારી, અસર):</label>
                <input type="text" id="how_much_impact" name="how_much_impact" placeholder="દા.ત. '50 પાર્ટ્સ (10%), સમગ્ર બેચ અસરગ્રસ્ત'">
            </div>
            <div class="form-group">
                <label for="customer_impact">ગ્રાહક પર સંભવિત અસર (Potential Customer Impact):</label>
                <textarea id="customer_impact" name="customer_impact" placeholder="દા.ત. 'ડિલિવરી વિલંબ, આગલા ઓપરેશનમાં રિજેક્શન'"></textarea>
            </div>

            <h3>કન્ટેઈનમેન્ટ એક્શન (Containment Actions)</h3>
            <div class="form-group">
                <label for="containment_action">તાત્કાલિક લેવાયેલા કન્ટેઈનમેન્ટ પગલાં:</label>
                <textarea id="containment_action" name="containment_action" placeholder="દા.ત. 'શંકાસ્પદ સ્ટોક અલગ કર્યો, 100% ઇન્સ્પેક્શન શરૂ કર્યું'"></textarea>
            </div>
            <div class="checkbox-group">
                <input type="checkbox" id="containment_effectiveness_verified" name="containment_effectiveness_verified" value="1">
                <label for="containment_effectiveness_verified">કન્ટેઈનમેન્ટ એક્શનની અસરકારકતા ચકાસવામાં આવી?</label>
            </div>
            <div class="form-group">
                <label for="containment_verified_by">ચકાસણી કરનાર વ્યક્તિ:</label>
                <input type="text" id="containment_verified_by" name="containment_verified_by" placeholder="નામ/હોદ્દો">
            </div>
            <div class="form-group">
                <label for="containment_verification_date">ચકાસણી તારીખ:</label>
                <input type="date" id="containment_verification_date" name="containment_verification_date">
            </div>

            <h3>ક્રોસ-ફંક્શનલ ટીમ (Cross-Functional Team - CFT)</h3>
            <div class="form-group">
                <label for="team_leader">ટીમ લીડર:</label>
                <input type="text" id="team_leader" name="team_leader" placeholder="નામ, હોદ્દો" required>
            </div>
            <div id="teamMemberContainer">
                <div class="form-group team-member-field">
                    <label for="team_member_1">ટીમ સભ્ય 1 (નામ, હોદ્દો):</label>
                    <input type="text" name="team_members[]" placeholder="દા.ત. 'અનિલ પટેલ, પ્રોડક્શન'">
                </div>
            </div>
            <div class="clearfix">
                <button type="button" id="addTeamMember" class="add-btn">વધુ ટીમ સભ્ય ઉમેરો</button>
            </div>

            <h3>શા માટે? (Why?) - મૂળ કારણ વિશ્લેષણ (Root Cause Analysis)</h3>
            <div id="whyContainer">
                <div class="form-group why-field">
                    <label for="why_1">શા માટે 1 (Why 1):</label>
                    <textarea id="why_1" name="whys[]" placeholder="મુખ્ય સમસ્યા શા માટે થઈ?"></textarea>
                </div>
            </div>
            <div class="clearfix">
                <button type="button" id="addWhy" class="add-btn">વધુ 'શા માટે' ઉમેરો</button>
            </div>
            <div class="form-group">
                <label for="root_cause">ઓળખાયેલ મૂળ કારણ (Identified Root Cause):</label>
                <textarea id="root_cause" name="root_cause" placeholder="Why-Why Analysis ના અંતે ઓળખાયેલ મૂળ કારણ અહીં લખો." required></textarea>
            </div>

            <h3>કરેક્ટિવ અને પ્રિવેન્ટિવ એક્શન (Corrective & Preventive Actions)</h3>
            <div class="form-group">
                <label for="corrective_action">કરેક્ટિવ એક્શન (મૂળ કારણને દૂર કરવા માટેના કાયમી પગલાં):</label>
                <textarea id="corrective_action" name="corrective_action" placeholder="દા.ત. 'મશીન XYZ માં ઓપરેશન ટાઈમિંગ સેટિંગ અપડેટ કર્યું.'"></textarea>
            </div>
            <div class="form-group">
                <label for="ca_responsible_person">CA માટે જવાબદાર વ્યક્તિ:</label>
                <input type="text" id="ca_responsible_person" name="ca_responsible_person" placeholder="નામ/હોદ્દો">
            </div>
            <div class="form-group">
                <label for="ca_target_date">CA પૂર્ણ કરવાની લક્ષ્ય તારીખ:</label>
                <input type="date" id="ca_target_date" name="ca_target_date">
            </div>

            <div class="form-group">
                <label for="preventive_action">પ્રિવેન્ટિવ એક્શન (ભવિષ્યમાં પુનરાવૃત્તિ ટાળવા માટે):</label>
                <textarea id="preventive_action" name="preventive_action" placeholder="દા.ત. 'આ જ પ્રકારની સમસ્યા અન્ય સમાન મશીનો પર ન થાય તેની ખાતરી કરવા FMEA અપડેટ કર્યું.'"></textarea>
            </div>
            <div class="form-group">
                <label for="pa_responsible_person">PA માટે જવાબદાર વ્યક્તિ:</label>
                <input type="text" id="pa_responsible_person" name="pa_responsible_person" placeholder="નામ/હોદ્દો">
            </div>
            <div class="form-group">
                <label for="pa_target_date">PA પૂર્ણ કરવાની લક્ષ્ય તારીખ:</label>
                <input type="date" id="pa_target_date" name="pa_target_date">
            </div>

            <div class="form-group">
                <label for="system_documents_updated">અપડેટ થયેલ સિસ્ટમ દસ્તાવેજો (જો કોઈ હોય તો):</label>
                <textarea id="system_documents_updated" name="system_documents_updated" placeholder="દા.ત. 'FMEA, કંટ્રોલ પ્લાન, વર્ક ઇન્સ્ટ્રક્શન #WI-005'"></textarea>
            </div>

            <h3>અસરકારકતાની ચકાસણી (Verification of Effectiveness)</h3>
            <div class="form-group">
                <label for="verification_method">ચકાસણીની પદ્ધતિ:</label>
                <textarea id="verification_method" name="verification_method" placeholder="દા.ત. '30 દિવસ માટે પ્રોડક્શન ડેટા મોનિટર કરવો, ઓડિટ'"></textarea>
            </div>
            <div class="form-group">
                <label for="verification_date">ચકાસણીની તારીખ:</label>
                <input type="date" id="verification_date" name="verification_date">
            </div>
            <div class="form-group">
                <label for="verification_results">ચકાસણીના પરિણામો:</label>
                <textarea id="verification_results" name="verification_results" placeholder="દા.ત. 'સમસ્યા ફરીથી ઉદ્ભવી નથી, ગુણવત્તા સ્વીકાર્ય છે.'"></textarea>
            </div>
            <div class="form-group">
                <label for="verified_by">ચકાસણી કરનાર વ્યક્તિ:</label>
                <input type="text" id="verified_by" name="verified_by" placeholder="નામ/હોદ્દો">
            </div>

            <h3>શીખેલા પાઠ (Lessons Learned)</h3>
            <div class="form-group">
                <label for="lessons_learned">શીખેલા પાઠનો સારાંશ:</label>
                <textarea id="lessons_learned" name="lessons_learned" placeholder="આ સમસ્યામાંથી શું શીખ્યા અને ભવિષ્યમાં તેનો કેવી રીતે ઉપયોગ કરી શકાય?"></textarea>
            </div>

            <button type="submit">એનાલિસિસ સબમિટ કરો</button>
        </form>
    </div>

    <script>
        // JavaScript for adding more 'Why' fields
        let whyCounter = 1;
        document.getElementById('addWhy').addEventListener('click', function() {
            whyCounter++;
            const whyContainer = document.getElementById('whyContainer');
            const newWhyDiv = document.createElement('div');
            newWhyDiv.className = 'form-group why-field';
            newWhyDiv.innerHTML = `
                <label for="why_${whyCounter}">શા માટે ${whyCounter} (Why ${whyCounter}):</label>
                <textarea id="why_${whyCounter}" name="whys[]" placeholder="પહેલાના 'શા માટે' શા માટે થયું?"></textarea>
            `;
            whyContainer.appendChild(newWhyDiv);
        });

        // JavaScript for adding more Team Member fields
        let teamMemberCounter = 1;
        document.getElementById('addTeamMember').addEventListener('click', function() {
            teamMemberCounter++;
            const teamMemberContainer = document.getElementById('teamMemberContainer');
            const newTeamMemberDiv = document.createElement('div');
            newTeamMemberDiv.className = 'form-group team-member-field';
            newTeamMemberDiv.innerHTML = `
                <label for="team_member_${teamMemberCounter}">ટીમ સભ્ય ${teamMemberCounter} (નામ, હોદ્દો):</label>
                <input type="text" name="team_members[]" placeholder="દા.ત. 'અનિલ પટેલ, પ્રોડક્શન'">
            `;
            teamMemberContainer.appendChild(newTeamMemberDiv);
        });
    </script>
</body>
</html>