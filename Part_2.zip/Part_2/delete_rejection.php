<?php
// આ ફાઈલ ડેટાબેઝમાંથી રેકોર્ડ ડિલીટ કરવા માટે છે.
// તમારે તમારા ડેટાબેઝ કનેક્શનની માહિતી અહીં આપવાની રહેશે.

// ડેટાબેઝ કનેક્શનની માહિતી
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dasp";

try {
    // PDO નો ઉપયોગ કરીને ડેટાબેઝ કનેક્શન બનાવો
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // ભૂલોને હેન્ડલ કરવા માટે PDO એક્સેપ્શન સેટ કરો
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // GET પદ્ધતિ દ્વારા મોકલવામાં આવેલ ID તપાસો
    if (isset($_GET['id']) && is_numeric($_GET['id'])) {
        $idToDelete = $_GET['id'];

        // ડિલીટ ક્વેરી તૈયાર કરો
        $sql = "DELETE FROM rejectiondata WHERE ID = :id"; // 'your_table_name' ને તમારા ટેબલના નામથી બદલો
        $stmt = $conn->prepare($sql);

        // ID ને બાઈન્ડ કરો
        $stmt->bindParam(':id', $idToDelete, PDO::PARAM_INT);

        // ક્વેરી એક્ઝીક્યુટ કરો
        if ($stmt->execute()) {
            echo "Record with ID: " . $idToDelete . " deleted successfully.";
        } else {
            echo "Error deleting record.";
        }
    } else {
        echo "Invalid ID provided.";
    }
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

// કનેક્શન બંધ કરો
$conn = null;
?>