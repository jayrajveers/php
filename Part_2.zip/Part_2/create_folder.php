<?php
header('Content-Type: application/json');

$baseUploadDir = 'uploads/'; // Your base upload directory path

$response = ['status' => 'error', 'message' => 'Invalid request.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_folder_name']) && isset($_POST['parent_folder'])) {
    $newFolderName = trim($_POST['new_folder_name']);
    $parentFolder = urldecode($_POST['parent_folder']);

    // Security check: Ensure parentFolder starts with baseUploadDir
    if (strpos($parentFolder, $baseUploadDir) !== 0) {
        $response['message'] = 'Security warning: Invalid parent folder path.';
        echo json_encode($response);
        exit;
    }

    if (empty($newFolderName)) {
        $response['message'] = 'Folder name cannot be empty.';
    } elseif (!preg_match('/^[a-zA-Z0-9_\-\s.]+$/', $newFolderName)) { // Allowed characters: alphanumeric, underscore, hyphen, space, dot
        $response['message'] = 'Folder name can only contain letters, numbers, underscores, hyphens, spaces, and dots.';
    } else {
        $newFolderPath = rtrim($parentFolder, '/') . '/' . $newFolderName;

        if (file_exists($newFolderPath)) {
            $response['message'] = 'A folder with this name already exists.';
        } else {
            if (mkdir($newFolderPath, 0777, true)) { // recursive true
                $response['status'] = 'success';
                $response['message'] = htmlspecialchars($newFolderName) . ' folder created successfully.';
                // Return the full path of the new folder so JavaScript can add it to the tree
                $response['fullPath'] = $newFolderPath;
                $response['folderName'] = htmlspecialchars($newFolderName); // Also send back the name
            } else {
                $response['message'] = 'Failed to create folder. Check permissions.';
            }
        }
    }
}

echo json_encode($response);
?>
