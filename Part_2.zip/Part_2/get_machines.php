<?php
$connection = mysqli_connect("localhost", "root", "", "dasp");
if(!$connection){
    die("Connection Failed: " . mysqli_connect_error());
}

$date = mysqli_real_escape_string($connection, $_POST['date']);
$shift = mysqli_real_escape_string($connection, $_POST['shift']); // શિફ્ટની વેલ્યુ મેળવો

$query = "SELECT DISTINCT machine_number FROM production WHERE `date` = '$date' AND shift = '$shift'";
$result = mysqli_query($connection, $query);

$machines = [];
if ($result) {
    while($row = mysqli_fetch_assoc($result)){
        $machines[] = $row['machine_number'];
    }
}

echo json_encode($machines);
mysqli_close($connection);
?>