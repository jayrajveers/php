<?php
header('Content-Type: application/json');

$baseUploadDir = 'uploads/'; // Your base directory to search within

// Function to recursively search for files and folders
function searchDirectory($dir, $searchTerm, &$results, $baseUploadDir) {
    // Ensure the directory exists and is readable
    if (!is_dir($dir) || !is_readable($dir)) {
        return;
    }

    $items = scandir($dir);
    $items = array_diff($items, array('.', '..')); // Remove . and ..

    foreach ($items as $item) {
        $itemPath = $dir . '/' . $item;
        $itemName = $item; // Original item name
        $lowerItemName = strtolower($itemName); // For case-insensitive comparison
        $lowerSearchTerm = strtolower($searchTerm);

        // Check if item name contains the search term
        if (str_contains($lowerItemName, $lowerSearchTerm)) {
            // Get the relative path from the base upload directory
            $relativePath = str_replace($baseUploadDir, '', $itemPath);
            $relativePath = ltrim($relativePath, '/'); // Remove leading slash if any

            $type = is_dir($itemPath) ? 'folder' : 'file';
            $results[] = [
                'name' => $itemName,
                'path' => $itemPath, // Full path for internal use (e.g., opening file)
                'displayPath' => $relativePath, // Path for display in UI
                'type' => $type
            ];
        }

        // If it's a directory, recursively search inside it
        if (is_dir($itemPath)) {
            searchDirectory($itemPath, $searchTerm, $results, $baseUploadDir);
        }
    }
}

$searchTerm = isset($_GET['term']) ? $_GET['term'] : '';
$results = [];

if (!empty($searchTerm)) {
    // Ensure the base directory exists
    if (!is_dir($baseUploadDir)) {
        echo json_encode(['error' => 'Base upload directory not found.']);
        exit;
    }
    searchDirectory($baseUploadDir, $searchTerm, $results, $baseUploadDir);
}

echo json_encode($results);
?>