<?php
// તમારી ડેટાબેઝ કનેક્શનની માહિતી અહીં નાખો
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dasp";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error); // એરર મેસેજમાં કનેક્શન એરરને સમાવો
}

$date = mysqli_real_escape_string($conn, $_POST['date']);

$query = "SELECT DISTINCT shift FROM production WHERE `date` = '$date'";
$result = $conn->query($query); // mysqli_query ની જગ્યાએ $conn->query નો ઉપયોગ કરો

$shifts = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()){
        $shifts[] = $row['shift'];
    }
}

$conn->close(); // કનેક્શન બંધ કરો

echo json_encode($shifts);
?>