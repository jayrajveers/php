<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $receivedData = json_decode(file_get_contents('php://input'), true);

    if (isset($receivedData['headers']) && isset($receivedData['data'])) {
        $headers = $receivedData['headers'];
        $data = $receivedData['data'];

        // Excel headers
        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=visible_production_data.xls");

        echo "<table border='1'>";

        // Print table headers
        echo "<thead><tr>";
        foreach ($headers as $header) {
            echo "<th>" . htmlspecialchars($header) . "</th>";
        }
        echo "</tr></thead><tbody>";

        // Print table data
        foreach ($data as $row) {
            echo "<tr>";
            foreach ($row as $cell) {
                echo "<td>" . htmlspecialchars($cell) . "</td>";
            }
            echo "</tr>";
        }

        echo "</tbody></table>";
        exit();

    } else {
        http_response_code(400);
        echo "Invalid data format received.";
    }
} else {
    http_response_code(405);
    echo "Method Not Allowed";
}
?>