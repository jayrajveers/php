<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Production Records</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }

        /* Stylish Add Button */
        .add-button-container {
            margin: 20px 0;
            text-align: center;
        }
        .add-button {
            background-color: #28a745;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: background-color 0.3s ease;
        }
        .add-button:hover {
            background-color: #218838;
        }
        /* Search Form */
        .filter-form-container {
            text-align: center;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        .filter-input-group {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
            margin-bottom: 10px;
        }
        .filter-label {
            font-size: 14px;
            font-weight: bold;
        }
        .filter-input {
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .filter-button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .filter-button:hover {
            background-color: #0056b3;
        }
        .reset-button {
            background-color: #6c757d;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .reset-button:hover {
            background-color: #545b62;
        }
        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border-radius: 4px;
            overflow: hidden;
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #343a40;
            color: #fff;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #e9f7ef;
        }
        a {
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .edit-button {
            background-color: #007bff;
            color: white;
            padding: 8px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            margin-right: 5px;
        }
        .edit-button:hover {
            background-color: #0056b3;
        }
        .delete-button {
            background-color: #dc3545;
            color: white;
            padding: 8px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            cursor: pointer;
        }
        .delete-button:hover {
            background-color: #c82333;
        }
        .no-records {
            color: red;
            text-align: center;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="add-button-container">
            <a href="rejection.html" class="add-button">➕ Add New Rejection Record</a>
        </div>

        <div class="filter-form-container">
            
                <label for="filterDate" class="filter-label">Date:</label>
                <input type="date" id="filterDate" class="filter-input">
            
            
                <label for="filterShift" class="filter-label">Shift:</label>
                <select id="filterShift" class="filter-input">
                    <option value="">All</option>
                    <option value="Day">Day</option>
                    <option value="Night">Night</option>
                    </select>
            
            
                <label for="filterMachineNumber" class="filter-label">Machine Number:</label>
                <input type="text" id="filterMachineNumber" class="filter-input" placeholder="Enter Machine Number">
            
            
                <label for="filterPartCode" class="filter-label">Part Code:</label>
                <input type="text" id="filterPartCode" class="filter-input" placeholder="Enter Part Code">
            
            <button class="filter-button" onclick="filterData()">Search</button>
            <button class="reset-button" onclick="resetFilter()">Reset</button>
        </div>

        <h2 align="center">Rejection Data Records</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Shift</th>
                    <th>Machine Number</th>
                    <th>Part Code</th>
                    <th>Lot Number</th>
                    <th>Operator</th>
                    <th>Setter</th>
                    <th>Forging OD UNFILL</th>
                    <th>Forging OD LAPING</th>
                    <th>Forging OD CRAKE</th>
                    <th>Forging BORE UNFILL</th>
                    <th>Forging BORE LAPING</th>
                    <th>Forging BORE CRAKE</th>
                    <th>Forging WIDTH UNFILL</th>
                    <th>Forging WIDTH LAPING</th>
                    <th>Forging WIDTH CRAKE</th>
                    <th>Forging TRACK UNFILL</th>
                    <th>Forging TRACK LAPING</th>
                    <th>Forging TRACK CARKE</th>
                    <th>Inhouse</th>
                    <th>Vendor Name</th>
                    <th>Vendor Nos</th>
                    <th>CNC WIDTH</th>
                    <th>CNC ID</th>
                    <th>CNC OD</th>
                    <th>CNC TRACK</th>
                    <th>CNC LOCATION</th>
                    <th>CNC LOADING MISTAKE</th>
                    <th>CNC GROOVE</th>
                    <th>CNC SETTING</th>
                    <th>CNC OTHER</th>
                    <th>Forging Total</th>
                    <th>CNC Total</th>
                    <th>Vendor Total</th>
                    <th>Total</th>
                  <th>Edit</th>
				  <th>Delete</th> </tr>
				
            </thead>
            <tbody id="rejectionData">
            </tbody>
        </table>
    </div>

    <script>
        let allRejectionData = []; // બધા ડેટાનો સ્ટોર કરવા માટે વેરીએબલ

        function loadRejectionData() {
            fetch('get_rejection_data.php')
                .then(response => response.json())
                .then(data => {
                    allRejectionData = data; // બધા ડેટાને સ્ટોર કરો
                    displayRejectionData(data); // ડેટાને ડિસ્પ્લે કરવા માટે ફંક્શન કોલ કરો
                })
                .catch(error => console.error('Error fetching data:', error));
        }

        function displayRejectionData(data) {
            const tableBody = document.getElementById('rejectionData');
            tableBody.innerHTML = ''; // જૂનો ડેટા સાફ કરો
            if (data.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="38" class="no-records">No records found</td></tr>';
                return;
            }
            data.forEach(record => {
                let row = tableBody.insertRow();
                row.insertCell().textContent = record.ID;
                row.insertCell().textContent = record.EntryDate;
                row.insertCell().textContent = record.Shift;
                row.insertCell().textContent = record.MachineNumber;
                row.insertCell().textContent = record.PartCode;
                row.insertCell().textContent = record.lot_number;
                row.insertCell().textContent = record.Operator;
                row.insertCell().textContent = record.Setter;
                row.insertCell().textContent = record.FORGING_OD_UNFILL;
                row.insertCell().textContent = record.FORGING_OD_LAPING;
                row.insertCell().textContent = record.FORGING_OD_CRAKE;
                row.insertCell().textContent = record.FORGING_BORE_UNFILL;
                row.insertCell().textContent = record.FORGING_BORE_LAPING;
                row.insertCell().textContent = record.FORGING_BORE_CRAKE;
                row.insertCell().textContent = record.FORGING_WIDTH_UNFILL;
                row.insertCell().textContent = record.FORGING_WIDTH_LAPING;
                row.insertCell().textContent = record.FORGING_WIDTH_CRAKE;
                row.insertCell().textContent = record.FORGING_TRACK_UNFILL;
                row.insertCell().textContent = record.FORGING_TRACK_LAPING;
                row.insertCell().textContent = record.FORGING_TRACK_CARKE;
                row.insertCell().textContent = record.INHOUSE;
                row.insertCell().textContent = record.VendorName;
                row.insertCell().textContent = record.vendor_nos;
                row.insertCell().textContent = record.CNC_WIDTH;
                row.insertCell().textContent = record.CNC_ID;
                row.insertCell().textContent = record.CNC_OD;
                row.insertCell().textContent = record.CNC_TRACK;
                row.insertCell().textContent = record.CNC_LOCATION;
                row.insertCell().textContent = record.CNC_LOADING_MISTAKE;
                row.insertCell().textContent = record.CNC_GROOVE;
                row.insertCell().textContent = record.CNC_SETTING;
                row.insertCell().textContent = record.CNC_OTHER;
                row.insertCell().textContent = record.FORGING_TOTAL;
                row.insertCell().textContent = record.CNC_Total;
                row.insertCell().textContent = record.VENDOR_TOTAL;
                row.insertCell().textContent = record.TOTAL;
				    
                // Edit Link
        let editCell = row.insertCell();
        let editLink = document.createElement('a');
        editLink.textContent = '✏Edit';
        editLink.href = 'edit_rejection_form.php?id=' + record.ID;
        editLink.className = 'edit-button';
        editCell.appendChild(editLink);

        // Delete Button
        let deleteCell = row.insertCell();
        let deleteButton = document.createElement('button');
        deleteButton.textContent = '🗑️ Delete';
        deleteButton.className = 'delete-button';
        deleteButton.onclick = function() {
            deleteRecord(record.ID); // Delete ફંક્શન કોલ કરો
        };
        deleteCell.appendChild(deleteButton);
    });
        }

        function filterData() {
            const filterDate = document.getElementById('filterDate').value;
            const filterShift = document.getElementById('filterShift').value;
            const filterMachineNumber = document.getElementById('filterMachineNumber').value.toLowerCase();
            const filterPartCode = document.getElementById('filterPartCode').value.toLowerCase();

            const filteredData = allRejectionData.filter(record => {
                const dateMatch = !filterDate || record.EntryDate === filterDate;
                const shiftMatch = !filterShift || record.Shift === filterShift;
                const machineNumberMatch = !filterMachineNumber || record.MachineNumber.toLowerCase().includes(filterMachineNumber);
                const partCodeMatch = !filterPartCode || record.PartCode.toLowerCase().includes(filterPartCode);

                return dateMatch && shiftMatch && machineNumberMatch && partCodeMatch;
            });

            displayRejectionData(filteredData);
        }

        function resetFilter() {
            document.getElementById('filterDate').value = '';
            document.getElementById('filterShift').value = '';
            document.getElementById('filterMachineNumber').value = '';
            document.getElementById('filterPartCode').value = '';
            displayRejectionData(allRejectionData); // બધા ડેટા ફરીથી ડિસ્પ્લે કરો
        }

        function deleteRecord(id) {
            if (confirm(`Are you sure you want to delete record with ID: ${id}?`)) {
                // અહીં તમે તમારા સર્વર-સાઇડ ડિલીટ કોડને કોલ કરશો
                fetch(`delete_rejection.php?id=${id}`, {
                    method: 'GET', // અથવા 'DELETE' જો તમારું સર્વર તે રીતે હેન્ડલ કરતું હોય
                })
                .then(response => response.text())
                .then(data => {
                    alert(data); // સર્વર તરફથી મળેલ મેસેજ ડિસ્પ્લે કરો
                    loadRejectionData(); // ડેટાને ફરીથી લોડ કરો
                })
                .catch(error => console.error('Error deleting record:', error));
            }
        }

        // પેજ લોડ થાય ત્યારે ડેટા લોડ કરો
        window.onload = loadRejectionData;
    </script>
</body>
</html>