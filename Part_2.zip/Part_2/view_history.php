<?php
// --- 1. ડેટાબેઝ ગોઠવણી ---
define('DB_SERVER', 'localhost'); // તમારું ડેટાબેઝ સર્વર
define('DB_USERNAME', 'root'); // તમારું ડેટાબેઝ યુઝરનેમ
define('DB_PASSWORD', ''); // તમારો ડેટાબેઝ પાસવર્ડ
define('DB_NAME', 'dasp'); // આપણે બનાવેલા ડેટાબેઝનું નામ

// dasp ડેટાબેઝ કનેક્શન બનાવો
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// કનેક્શન તપાસો
if ($conn->connect_error) {
    die("કનેક્શન નિષ્ફળ થયું: " . $conn->connect_error);
}

// --- 2. કાર્યક્ષમતાઓ ---

// પેજિનેશન સેટિંગ્સ
$records_per_page = 20; // એક પેજ પર 20 એન્ટ્રી

/**
 * બધા ઇતિહાસ રેકોર્ડ્સ મેળવે છે, સર્ચ ફિલ્ટર અને પેજિનેશન સાથે.
 * @param string $search_query સર્ચ કરવા માટેની ક્વેરી
 * @param int $offset ડેટાબેઝ ક્વેરી માટે ઓફસેટ
 * @param int $limit ડેટાબેઝ ક્વેરી માટે લિમિટ
 * @return array ઇતિહાસ રેકોર્ડ્સનો એરે.
 */
function getPaginatedHistoryRecords($search_query = '', $offset = 0, $limit = 20) {
    global $conn;
    $history_records = [];
    $sql = "SELECT
                ph.id,
                p.part_name,
                p.part_number,
                c.customer_name,
                ph.change_type,
                ph.description,
                ph.old_value,
                ph.new_value,
                ph.changed_by,
                ph.changed_at
            FROM
                part_history ph
            JOIN
                parts p ON ph.part_id = p.id
            JOIN
                customers c ON p.customer_id = c.id";

    $where_clauses = [];
    $param_types = "";
    $param_values = [];

    if (!empty($search_query)) {
        $search_query_param = "%" . $search_query . "%";
        $where_clauses[] = "(p.part_name LIKE ? OR p.part_number LIKE ? OR c.customer_name LIKE ? OR ph.description LIKE ? OR ph.change_type LIKE ?)";
        $param_types .= "sssss";
        $param_values = array_merge($param_values, [$search_query_param, $search_query_param, $search_query_param, $search_query_param, $search_query_param]);
    }

    if (!empty($where_clauses)) {
        $sql .= " WHERE " . implode(" AND ", $where_clauses);
    }

    $sql .= " ORDER BY ph.changed_at DESC LIMIT ?, ?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (getPaginatedHistoryRecords): " . $conn->error);
        return [];
    }

    // Bind parameters for search and pagination
    $param_types .= "ii";
    $param_values = array_merge($param_values, [$offset, $limit]);

    // Dynamically bind parameters
    $stmt->bind_param($param_types, ...$param_values);

    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $history_records[] = $row;
    }
    $stmt->close();
    return $history_records;
}

/**
 * કુલ ઇતિહાસ રેકોર્ડ્સની સંખ્યા મેળવે છે, સર્ચ ફિલ્ટર સાથે.
 * @param string $search_query સર્ચ કરવા માટેની ક્વેરી
 * @return int કુલ રેકોર્ડ્સની સંખ્યા.
 */
function getTotalHistoryRecordsCount($search_query = '') {
    global $conn;
    $sql = "SELECT COUNT(*) AS total_count
            FROM part_history ph
            JOIN parts p ON ph.part_id = p.id
            JOIN customers c ON p.customer_id = c.id";

    $where_clauses = [];
    $param_types = "";
    $param_values = [];

    if (!empty($search_query)) {
        $search_query_param = "%" . $search_query . "%";
        $where_clauses[] = "(p.part_name LIKE ? OR p.part_number LIKE ? OR c.customer_name LIKE ? OR ph.description LIKE ? OR ph.change_type LIKE ?)";
        $param_types .= "sssss";
        $param_values = array_merge($param_values, [$search_query_param, $search_query_param, $search_query_param, $search_query_param, $search_query_param]);
    }

    if (!empty($where_clauses)) {
        $sql .= " WHERE " . implode(" AND ", $where_clauses);
    }

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("SQL Prepare Error (getTotalHistoryRecordsCount): " . $conn->error);
        return 0;
    }

    if (!empty($param_values)) {
        $stmt->bind_param($param_types, ...$param_values);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $total_count = $row['total_count'];
    $stmt->close();
    return $total_count;
}

// URL માંથી સર્ચ ક્વેરી અને વર્તમાન પેજ નંબર મેળવો
$search_query = $_GET['search_query'] ?? '';
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($current_page < 1) $current_page = 1;

$total_records = getTotalHistoryRecordsCount($search_query);
$total_pages = ceil($total_records / $records_per_page);

// ઓફસેટ ગણતરી
$offset = ($current_page - 1) * $records_per_page;

// પેજિનેટેડ રેકોર્ડ્સ મેળવો
$history_records = getPaginatedHistoryRecords($search_query, $offset, $records_per_page);

?>

<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>તમામ ફેરફારોનો ઇતિહાસ</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
            color: #333;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 {
            color: #0056b3;
        }
        .search-bar {
            margin-bottom: 20px;
            display: flex;
        }
        .search-bar input {
            flex-grow: 1;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 10px;
        }
        .search-bar button {
            background-color: #6c757d;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .history-list {
            margin-top: 20px;
        }
        .history-item {
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px 15px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: background-color 0.2s ease;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .history-item:hover {
            background-color: #e9e9e9;
        }
        .history-item span {
            flex-grow: 1;
        }
        .history-item .date {
            font-size: 0.9em;
            color: #666;
            min-width: 150px; /* તારીખને લપેટાતી અટકાવવા માટે */
            text-align: right;
        }

        /* Modal (Popup) Styles */
        .modal {
            display: none; /* મૂળભૂત રીતે છુપાયેલ */
            position: fixed; /* જગ્યાએ રહો */
            z-index: 1; /* ટોચ પર રહો */
            left: 0;
            top: 0;
            width: 100%; /* સંપૂર્ણ પહોળાઈ */
            height: 100%; /* સંપૂર્ણ ઊંચાઈ */
            overflow: auto; /* જો જરૂર હોય તો સ્ક્રોલ સક્ષમ કરો */
            background-color: rgba(0,0,0,0.4); /* અર્ધ-પારદર્શક કાળો */
        }
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto; /* ટોચથી 5% અને કેન્દ્રિત */
            padding: 25px;
            border: 1px solid #888;
            border-radius: 8px;
            width: 80%; /* સ્ક્રીન સાઇઝના આધારે વધુ કે ઓછું હોઈ શકે છે */
            max-width: 900px; /* વાંચનીયતા માટે મહત્તમ પહોળાઈ */
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            position: relative;
        }
        .close-button {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 10px;
            right: 20px;
        }
        .close-button:hover,
        .close-button:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .modal-content h2 {
            margin-top: 0;
            color: #0056b3;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        .modal-content p {
            margin-bottom: 8px;
            line-height: 1.5;
        }
        .modal-content strong {
            color: #555;
        }
        /* Table Styles for JSON display */
        .json-table-container {
            margin-top: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            overflow-x: auto; /* જો કોષ્ટક મોટું હોય તો સ્ક્રોલ સક્ષમ કરો */
        }
        .json-table {
            width: 100%;
            border-collapse: collapse;
        }
        .json-table th, .json-table td {
            padding: 8px 12px;
            border: 1px solid #eee;
            text-align: left;
        }
        .json-table th {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #555;
        }
        .json-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .json-table .highlight-old {
            background-color: #ffdddd; /* લાલ રંગ - જૂની કિંમત બદલાઈ ગઈ છે */
        }
        .json-table .highlight-new {
            background-color: #ddffdd; /* લીલો રંગ - નવી કિંમત બદલાઈ ગઈ છે */
        }
        .back-button {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 20px;
        }
        .back-button:hover {
            opacity: 0.9;
        }
        /* Pagination Styles */
        .pagination {
            margin-top: 20px;
            text-align: center;
        }
        .pagination a, .pagination span {
            display: inline-block;
            padding: 8px 12px;
            margin: 0 4px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #007bff;
            background-color: #fff;
        }
        .pagination a:hover {
            background-color: #e9e9e9;
        }
        .pagination .current-page {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
            font-weight: bold;
        }
        .pagination .disabled {
            color: #ccc;
            cursor: not-allowed;
            background-color: #f9f9f9;
        }
		/* Styling for a button-like link */
.add-button-container {
    text-align: center; /* જો બટનને સેન્ટરમાં લાવવું હોય તો */
    margin-top: 20px; /* ઉપરથી થોડી જગ્યા માટે */
    margin-bottom: 20px; /* નીચેથી થોડી જગ્યા માટે */
}

.add-button {
    display: inline-block; /* જેથી પેડિંગ અને માર્જિન યોગ્ય રીતે લાગુ પડે */
    padding: 12px 25px; /* બટનની અંદરની જગ્યા */
    background-color: var(--erp-primary-color); /* ERP પ્રાઇમરી કલર */
    color: #ffffff; /* ટેક્સ્ટ કલર સફેદ */
    text-decoration: none; /* લિંકની નીચેની લીટી દૂર કરો */
    border: none; /* કોઈ બોર્ડર નહીં */
    border-radius: 6px; /* ગોળાકાર કિનારીઓ */
    cursor: pointer; /* હોવર કરવા પર પોઇન્ટર બતાવો */
    font-size: 18px; /* ફોન્ટ સાઈઝ */
    font-weight: 500; /* ફોન્ટ વેઇટ */
    transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.2s ease; /* સ્મૂથ ટ્રાન્ઝિશન */
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* હળવો શેડો */
}

.add-button:hover {
    background-color: #303f9f; /* હોવર પર થોડો ઘાટો કલર */
    transform: translateY(-2px); /* હોવર પર થોડું ઉપર ખસેડો */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15); /* હોવર પર શેડો વધારો */
}

.add-button:active {
    transform: translateY(0); /* ક્લિક પર મૂળ સ્થિતિમાં પાછું લાવો */
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1); /* ક્લિક પર શેડો ઓછો કરો */
}
    </style>
</head>
<body>
<div class="add-button-container">
            <a href="inprocess_master.php" class="add-button">
                Home Page
            </a>
        </div>
    <div class="container">
        
        <h1>તમામ ફેરફારોનો ઇતિહાસ</h1>

        <div class="search-bar">
            <input type="text" id="search_input" placeholder="પાર્ટનું નામ, નંબર, ગ્રાહક, વર્ણન અથવા પ્રકાર દ્વારા શોધો..." value="<?= htmlspecialchars($search_query) ?>">
            <button onclick="performSearch()">શોધો</button>
        </div>

        <div class="history-list">
            <?php if (empty($history_records)): ?>
                <p>કોઈ ઇતિહાસ રેકોર્ડ મળ્યો નથી.</p>
            <?php else: ?>
                <?php foreach ($history_records as $record): ?>
                    <div class="history-item" onclick="showHistoryDetail(
                        '<?= htmlspecialchars($record['part_name']) ?>',
                        '<?= htmlspecialchars($record['part_number']) ?>',
                        '<?= htmlspecialchars($record['customer_name']) ?>',
                        '<?= htmlspecialchars($record['change_type']) ?>',
                        '<?= htmlspecialchars($record['description']) ?>',
                        '<?= htmlspecialchars($record['changed_by']) ?>',
                        '<?= htmlspecialchars($record['changed_at']) ?>',
                        '<?= htmlspecialchars($record['old_value'] ?? 'null') ?>',
                        '<?= htmlspecialchars($record['new_value'] ?? 'null') ?>'
                    )">
                        <span>
                            <strong><?= htmlspecialchars($record['change_type']) ?>:</strong>
                            <?= htmlspecialchars($record['description']) ?>
                            (પાર્ટ: <?= htmlspecialchars($record['part_name']) ?> / <?= htmlspecialchars($record['part_number']) ?>)
                        </span>
                        <span class="date"><?= htmlspecialchars($record['changed_at']) ?></span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="pagination">
            <?php
            $query_params = [];
            if (!empty($search_query)) {
                $query_params['search_query'] = urlencode($search_query);
            }

            // પ્રથમ પેજ
            $first_page_link = '?' . http_build_query(array_merge($query_params, ['page' => 1]));
            echo '<a href="' . $first_page_link . '" class="' . ($current_page == 1 ? 'disabled' : '') . '">First</a>';

            // પાછલું પેજ
            $prev_page = $current_page - 1;
            $prev_page_link = '?' . http_build_query(array_merge($query_params, ['page' => $prev_page]));
            echo '<a href="' . $prev_page_link . '" class="' . ($current_page == 1 ? 'disabled' : '') . '">Previous</a>';

            // પેજ નંબર લિંક્સ (આસપાસના થોડા પેજ)
            $start_page = max(1, $current_page - 2);
            $end_page = min($total_pages, $current_page + 2);

            for ($i = $start_page; $i <= $end_page; $i++) {
                $page_link = '?' . http_build_query(array_merge($query_params, ['page' => $i]));
                $class = ($i == $current_page) ? 'current-page' : '';
                echo '<a href="' . $page_link . '" class="' . $class . '">' . $i . '</a>';
            }

            // આગળનું પેજ
            $next_page = $current_page + 1;
            $next_page_link = '?' . http_build_query(array_merge($query_params, ['page' => $next_page]));
            echo '<a href="' . $next_page_link . '" class="' . ($current_page == $total_pages ? 'disabled' : '') . '">Next</a>';
            
            // છેલ્લું પેજ
            $last_page_link = '?' . http_build_query(array_merge($query_params, ['page' => $total_pages]));
            echo '<a href="' . $last_page_link . '" class="' . ($current_page == $total_pages ? 'disabled' : '') . '">Last</a>';
            ?>
        </div>
    </div>

    <div id="historyModal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeModal()">&times;</span>
            <h2 id="modal_title"></h2>
            <p><strong>પાર્ટનું નામ:</strong> <span id="modal_part_name"></span></p>
            <p><strong>પાર્ટ નંબર:</strong> <span id="modal_part_number"></span></p>
            <p><strong>ગ્રાહક:</strong> <span id="modal_customer_name"></span></p>
            <p><strong>ફેરફારનો પ્રકાર:</strong> <span id="modal_change_type"></span></p>
            <p><strong>વર્ણન:</strong> <span id="modal_description"></span></p>
            <p><strong>ફેરફાર કરનાર:</strong> <span id="modal_changed_by"></span></p>
            <p><strong>સમય:</strong> <span id="modal_changed_at"></span></p>
            
            <h3>વિગતોમાં ફેરફાર:</h3>
            <div class="json-table-container">
                <table class="json-table">
                    <thead>
                        <tr>
                            <th>ફિલ્ડ</th>
                            <th>જૂની કિંમત</th>
                            <th>નવી કિંમત</th>
                        </tr>
                    </thead>
                    <tbody id="json_diff_table_body">
                        </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // મોડલ અને તેના ઘટકો મેળવો
        const modal = document.getElementById('historyModal');
        const modalTitle = document.getElementById('modal_title');
        const modalPartName = document.getElementById('modal_part_name');
        const modalPartNumber = document.getElementById('modal_part_number');
        const modalCustomerName = document.getElementById('modal_customer_name');
        const modalChangeType = document.getElementById('modal_change_type');
        const modalDescription = document.getElementById('modal_description');
        const modalChangedBy = document.getElementById('modal_changed_by');
        const modalChangedAt = document.getElementById('modal_changed_at');
        const jsonDiffTableBody = document.getElementById('json_diff_table_body');

        // ઇતિહાસ વિગતો દર્શાવવા માટે
        function showHistoryDetail(partName, partNumber, customerName, changeType, description, changedBy, changedAt, oldValueJson, newValueJson) {
            modalTitle.textContent = "ફેરફાર વિગતો";
            modalPartName.textContent = partName;
            modalPartNumber.textContent = partNumber;
            modalCustomerName.textContent = customerName;
            modalChangeType.textContent = changeType;
            modalDescription.textContent = description;
            modalChangedBy.textContent = changedBy;
            modalChangedAt.textContent = changedAt;

            // JSON ડેટાને પાર્સ કરો
            let oldData = {};
            let newData = {};

            try {
                oldData = JSON.parse(oldValueJson);
            } catch (e) {
                console.error("Error parsing old_value JSON:", e, oldValueJson);
                // જો પાર્સ ન થાય, તો તેને સ્ટ્રિંગ તરીકે લો
                oldData = { "Raw Value": oldValueJson };
            }

            try {
                newData = JSON.parse(newValueJson);
            } catch (e) {
                console.error("Error parsing new_value JSON:", e, newValueJson);
                // જો પાર્સ ન થાય, તો તેને સ્ટ્રિંગ તરીકે લો
                newData = { "Raw Value": newValueJson };
            }
            
            // ટેબલ બોડી સાફ કરો
            jsonDiffTableBody.innerHTML = '';

            // તમામ સંભવિત કી મેળવો (જૂની અને નવી બન્નેમાંથી)
            const allKeys = new Set([...Object.keys(oldData), ...Object.keys(newData)]);

            allKeys.forEach(key => {
                const oldVal = oldData[key] !== undefined && oldData[key] !== null ? oldData[key] : 'N/A';
                const newVal = newData[key] !== undefined && newData[key] !== null ? newData[key] : 'N/A';

                const row = jsonDiffTableBody.insertRow();
                const cellKey = row.insertCell();
                const cellOldValue = row.insertCell();
                const cellNewValue = row.insertCell();

                cellKey.textContent = key;
                cellOldValue.textContent = oldVal;
                cellNewValue.textContent = newVal;

                // જો કિંમતો અલગ હોય, તો હાઇલાઇટ કરો
                if (oldVal !== newVal) {
                    cellOldValue.classList.add('highlight-old');
                    cellNewValue.classList.add('highlight-new');
                }
            });
            
            modal.style.display = 'block';
        }

        // મોડલ બંધ કરવા માટે
        function closeModal() {
            modal.style.display = 'none';
        }

        // જ્યારે યુઝર મોડલની બહાર ક્લિક કરે, ત્યારે તેને બંધ કરો
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }

        // સર્ચ કાર્યક્ષમતા
        function performSearch() {
            const searchQuery = document.getElementById('search_input').value;
            // વર્તમાન પેજ જાળવી રાખવા માટે, પેજ નંબરને 1 પર રીસેટ કરો જ્યારે નવી શોધ થાય
            window.location.href = '?search_query=' + encodeURIComponent(searchQuery) + '&page=1';
        }

        // Enter કી દબાવવા પર સર્ચ ટ્રિગર કરવા માટે
        document.getElementById('search_input').addEventListener('keypress', function(event) {
            if (event.key === 'Enter') {
                performSearch();
            }
        });
    </script>
</body>
</html>

<?php
// ડેટાબેઝ કનેક્શન બંધ કરો
$conn->close();
?>