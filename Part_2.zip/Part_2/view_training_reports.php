<?php
// Database connection parameters - **UPDATE THESE WITH YOUR ACTUAL DETAILS**
$servername = "localhost";
$username = "root"; // e.g., "root"
$password = ""; // e.g., "" for XAMPP default
$dbname = "dasp";   // e.g., "cnc_reports"

$conn = null; // Initialize connection variable

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    $sql = "SELECT id, employee_name, employee_id, department, training_title, training_date, trainer_name, created_at FROM employee_training_records WHERE 1=1";
    $params = [];

    // Filter by Date Range
    $start_date = $_GET['start_date'] ?? '';
    $end_date = $_GET['end_date'] ?? '';
    if (!empty($start_date)) {
        $sql .= " AND training_date >= :start_date";
        $params[':start_date'] = $start_date;
    }
    if (!empty($end_date)) {
        $sql .= " AND training_date <= :end_date";
        $params[':end_date'] = $end_date;
    }

    // Filter by Employee Name (partial match)
    $employee_name_filter = $_GET['employee_name_filter'] ?? '';
    if (!empty($employee_name_filter)) {
        $sql .= " AND employee_name LIKE :employee_name_filter";
        $params[':employee_name_filter'] = '%' . $employee_name_filter . '%';
    }

    $sql .= " ORDER BY training_date DESC, created_at DESC";

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $training_records = $stmt->fetchAll();

} catch (PDOException $e) {
    echo "<p style='color: red;'>ડેટાબેઝ ભૂલ: " . $e->getMessage() . "</p>";
    $training_records = []; // Ensure $training_records is an empty array on error
} finally {
    if ($conn) {
        $conn = null; // Close the database connection
    }
}
?>
<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>કર્મચારી તાલીમ રિપોર્ટ્સ</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f7f6;
            color: #333;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            max-width: 1200px;
            margin: auto;
            border-top: 5px solid #007bff;
        }
        h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 25px;
            font-size: 2.2em;
        }
        .filter-section {
            background-color: #e9f5ff;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 25px;
            display: flex;
            gap: 15px;
            align-items: flex-end;
            flex-wrap: wrap;
        }
        .filter-group {
            flex: 1;
            min-width: 180px;
        }
        .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        .filter-group input[type="date"],
        .filter-group input[type="text"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .filter-group button {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }
        .filter-group button:hover {
            background-color: #218838;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            color: #555;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #e6f7ff;
        }
        .view-details-btn {
            background-color: #007bff;
            color: white;
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 0.9em;
            transition: background-color 0.3s ease;
        }
        .view-details-btn:hover {
            background-color: #0056b3;
        }
        .no-records {
            text-align: center;
            padding: 20px;
            color: #777;
        }
        .nav-buttons {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .nav-buttons a {
            background-color: #6c757d;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .nav-buttons a:hover {
            background-color: #5a6268;
        }
        .nav-buttons .primary-link {
            background-color: #17a2b8; /* Info color */
        }
        .nav-buttons .primary-link:hover {
            background-color: #138496;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="nav-buttons">
            <a href="view_records.php">HOME PAGE</a>
            <a href="training_form.php" class="primary-link">નવો તાલીમ રેકોર્ડ ઉમેરો</a>
        </div>
        <h2>કર્મચારી તાલીમ રિપોર્ટ્સ</h2>

        <div class="filter-section">
            <form method="GET" action="view_training_reports.php" style="display:contents;">
                <div class="filter-group">
                    <label for="employee_name_filter">કર્મચારીનું નામ:</label>
                    <input type="text" id="employee_name_filter" name="employee_name_filter" value="<?php echo htmlspecialchars($employee_name_filter); ?>" placeholder="નામ દાખલ કરો">
                </div>
                <div class="filter-group">
                    <label for="start_date">શરૂઆત તારીખ:</label>
                    <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>">
                </div>
                <div class="filter-group">
                    <label for="end_date">અંત તારીખ:</label>
                    <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>">
                </div>
                <div class="filter-group" style="flex-grow: 0;">
                    <button type="submit">ફિલ્ટર કરો</button>
                </div>
            </form>
        </div>

        <?php if (!empty($training_records)): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>કર્મચારીનું નામ</th>
                        <th>કર્મચારી ID</th>
                        <th>વિભાગ</th>
                        <th>તાલીમનું શીર્ષક</th>
                        <th>તાલીમ તારીખ</th>
                        <th>તાલીમ આપનાર</th>
                        <th>રેકોર્ડ બનાવ્યો</th>
                        <th>એક્શન</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($training_records as $record): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($record['id']); ?></td>
                            <td><?php echo htmlspecialchars($record['employee_name']); ?></td>
                            <td><?php echo htmlspecialchars($record['employee_id'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($record['department'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars(mb_strimwidth($record['training_title'], 0, 50, "...")); ?></td>
                            <td><?php echo htmlspecialchars($record['training_date']); ?></td>
                            <td><?php echo htmlspecialchars($record['trainer_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($record['created_at']); ?></td>
                            <td>
                                <a href="display_full_training_report.php?id=<?php echo htmlspecialchars($record['id']); ?>" class="view-details-btn">જુઓ વિગતો</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="no-records">કોઈ તાલીમ રેકોર્ડ મળ્યા નથી. કૃપા કરીને ફિલ્ટર બદલો અથવા નવો રેકોર્ડ ઉમેરો.</p>
        <?php endif; ?>
    </div>
</body>
</html>