<?php
require('fpdf/fpdf.php');
include('db_connection.php');

class PDF extends FPDF {
    function Header() {
        $this->SetFont('Arial','B',12);
        $this->Cell(0,10,'Production Report',0,1,'C');
        $this->Ln(5);
    }

    // Custom Row Function for wrapped text
    function Row($data, $widths) {
        $nb = 0;
        for($i=0;$i<count($data);$i++) {
            $nb = max($nb, $this->NbLines($widths[$i], $data[$i]));
        }
        $h = 5 * $nb;
        $this->CheckPageBreak($h);
        for($i=0;$i<count($data);$i++) {
            $w = $widths[$i];
            $a = 'L';
            $x = $this->GetX();
            $y = $this->GetY();
            $this->Rect($x, $y, $w, $h);
            $this->MultiCell($w, 5, $data[$i], 0, $a);
            $this->SetXY($x + $w, $y);
        }
        $this->Ln($h);
    }

    function CheckPageBreak($h) {
        if($this->GetY() + $h > $this->PageBreakTrigger) {
            $this->AddPage($this->CurOrientation);
        }
    }

    function NbLines($w, $txt) {
        $cw = &$this->CurrentFont['cw'];
        if($w == 0) $w = $this->w - $this->rMargin - $this->x;
        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', $txt);
        $nb = strlen($s);
        if($nb > 0 && $s[$nb - 1] == "\n") $nb--;
        $sep = -1;
        $i = 0; $j = 0; $l = 0; $nl = 1;
        while($i < $nb) {
            $c = $s[$i];
            if($c == "\n") {
                $i++; $sep = -1; $j = $i; $l = 0; $nl++;
                continue;
            }
            if($c == ' ') $sep = $i;
            $l += $cw[$c];
            if($l > $wmax) {
                if($sep == -1) {
                    if($i == $j) $i++;
                } else {
                    $i = $sep + 1;
                }
                $sep = -1; $j = $i; $l = 0; $nl++;
            } else {
                $i++;
            }
        }
        return $nl;
    }
}

// Columns and Widths
$columns = ['ID', 'Date', 'Shift', 'Shift Start Time', 'Shift End Time', 'Customer', 'Machine Number', 'Setup', 'Cycle Time Minutes', 'Cycle Time Second', 'Loding Time', 'Hourly Targe', 'Shift Target', 'Setter Name', 'Operator Name', 'Ref Number', 'Drowing & Rev.', 'Lot Number', 'Lot Qty', 'Heat Number', 'Grade', '1st Part Count', '2nd Part Count', '3rd Part Count', 'Part Count Wise Production', 'Breakdown List', 'Breakdown Time', 'Total Production'];
$widths = [10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10 , 10 ];

$pdf = new PDF();
$pdf->AddPage('L');
$pdf->SetFont('Arial','B',10);
$pdf->SetFillColor(200,220,255);

$pdf->Row($columns, $widths);
$pdf->SetFont('Arial','',9);

// Fetch data
$sql = "SELECT id, date, shift, shift_start_time, shift_end_time, customer, machine_number, setup, cycle_minutes, cycle_seconds, loading_time, hourly_target, shift_target, setter_name, operator_name,ref_number, drowing, lot_number, lot_qty, heat_number, grade, part_count_1st, part_count_2nd, part_count_3rd, pcwp, breakdown_list, breakdown_time, total_production FROM production";
$result = $conn->query($sql);

while($row = $result->fetch_assoc()) {
    $data = [
         $row['id'],
    $row['date'],
    $row['shift'],
	$row['shift_start_time'],
    $row['shift_end_time'],
	$row['customer'],
	$row['machine_number'],
	$row['setup'],
	$row['cycle_minutes'],
	$row['cycle_seconds'],
	$row['loading_time'],
	$row['hourly_target'],
	$row['shift_target'],
	$row['setter_name'],
	$row['operator_name'],
	$row['ref_number'],
	$row['drowing'],
	$row['lot_number'],
	$row['lot_qty'],
	$row['heat_number'],
	$row['grade'],
	$row['part_count_1st'],
	$row['part_count_2nd'],
	$row['part_count_3rd'],
	$row['pcwp'],
	$row['breakdown_list'],
	$row['breakdown_time'],
	$row['total_production'],
    ];
    $pdf->Row($data, $widths);
}

$pdf->Output("D", "production_report.pdf");
$conn->close();
?>
