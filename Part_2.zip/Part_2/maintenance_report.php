<!DOCTYPE html>
<html>

<head>
    <title>मासिक मशीन डेटा</title>
    <style>
        body {
            font-family: sans-serif;
            background-color: #f0f2f5;
            color: #1c1e21;
            margin: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            color: #1877f2;
            margin-bottom: 30px;
        }

        form {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            width: 300px;
            display: flex;
            flex-direction: column;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #65676b;
        }

        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccd0d5;
            border-radius: 6px;
            font-size: 14px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #1877f2;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #166fe6;
        }

        table {
            width: 98%;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #dddfe2;
            padding: 8px;
            text-align: center;
            white-space: nowrap;
            font-size: 12px;
        }

        th {
            background-color: #f5f6f7;
            font-weight: bold;
            color: #65676b;
            font-size: 13px;
        }

        tr:nth-child(even) {
            background-color: #f0f2f5;
        }

        h2 {
            color: #1c1e21;
            margin-bottom: 15px;
        }

        p {
            color: #1c1e21;
            margin-top: 20px;
        }

        .param {
            font-style: italic;
            color: #65676b;
            font-size: 14px;
        }

        /* Style for the home page button */
        .home-button {
            display: inline-block; /* Allows padding and margin to apply correctly */
            background-color: #42b72a; /* A common "success" or "go" color */
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none; /* Remove underline from link */
            transition: background-color 0.3s ease;
            margin-top: 20px; /* Space it from the form */
        }

        .home-button:hover {
            background-color: #36a420; /* Darker shade on hover */
        }
    </style>
</head>

<body>

    <h1>मासिक मशीन डेटा</h1>

    <a href="home_page.php" class="home-button">HOME PAGE</a>

    <form method="post">
        <label for="month">महीना चुनें:</label>
        <select name="month" id="month">
            <?php
            $currentMonth = date('n');
            for ($m = 1; $m <= 12; $m++) {
                $monthName = date('F', mktime(0, 0, 0, $m, 10));
                $selected = '';
                if (isset($_POST['month']) && $_POST['month'] == $m) {
                    $selected = 'selected';
                } else if (!isset($_POST['month']) && $m == $currentMonth) {
                    $selected = 'selected';
                }
                echo "<option value='" . $m . "' " . $selected . ">" . $monthName . "</option>";
            }
            ?>
        </select>


        <label for="machine">मशीन नंबर चुनें:</label>
        <select name="machine" id="machine">
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "dasp";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql_machines = "SELECT DISTINCT machine_number FROM daily_maintenance_log ORDER BY machine_number ASC";
            $result_machines = $conn->query($sql_machines);

            if ($result_machines->num_rows > 0) {
                $firstMachine = true;
                while ($row_machine = $result_machines->fetch_assoc()) {
                    $machine_number = $row_machine['machine_number'];
                    $selected = '';
                    if (isset($_POST['machine']) && $_POST['machine'] == $machine_number) {
                        $selected = 'selected';
                    } else if (!isset($_POST['machine']) && $firstMachine) {
                        $selected = 'selected';
                        $firstMachine = false;
                    }
                    echo "<option value='" . $machine_number . "'" . $selected . ">" . $machine_number . "</option>";
                }
            } else {
                echo "<option value=''>कोई मशीन नहीं मिली</option>";
            }
            $conn->close();
            ?>
        </select>


        <input type="submit" value="डेटा दिखाएँ">
    </form>

    <br>

    <?php
    if (isset($_POST['month']) && isset($_POST['machine'])) {
        $selected_month = $_POST['month'];
        $selected_machine = $_POST['machine'];

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "dasp";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $fieldMap = [
            'lubrication_tank_oil_level' => ['name' => 'लुब्रिकेशन टैंक ऑयल लेवल - <span class="param">60% तक मिनिमम</span>', 'order' => 1],
            'hydraulic_tank_oil_level' => ['name' => 'हाइड्रोलिक टैंक ऑयल लेवल - <span class="param">60% तक मिनिमम</span>', 'order' => 2],
            'hydraulic_pressure' => ['name' => 'हाइड्रोलिक प्रेशर - <span class="param">30 केजी/सीएम²</span>', 'order' => 3],
            'axis_slide_cover' => ['name' => 'एक्सिस स्लाइड कवर - <span class="param">हर रोज</span>', 'order' => 4],
            'machine_mess_oil_coolant_leakage' => ['name' => 'मशीन मेस ऑयल/कूलेंट लीकेज - <span class="param">हर रोज</span>', 'order' => 5],
            'chips_machine_conveyor_working' => ['name' => 'चिप्स मशीन कन्वेयर कार्यरत - <span class="param">हर रोज</span>', 'order' => 6],
            'central_tank_coolant_level' => ['name' => 'सेंट्रल टैंक कूलेंट लेवल - <span class="param">40% तक मिनिमम</span>', 'order' => 7],
            'coolant_ph' => ['name' => 'कूलेंट pH - <span class="param">8% - 10%</span>', 'order' => 8],
            'chips_conveyor_motor_working' => ['name' => 'चिप्स कन्वेयर मोटर कार्यरत - <span class="param">निर्धारित गति</span>', 'order' => 9],
            'tapan_check_ac' => ['name' => 'AC जाँचें - <span class="param">30 ~ 42</span>', 'order' => 10],
            'ac_guard_clean' => ['name' => 'AC गार्ड साफ़ करें - <span class="param">धूल से मुक्त</span>', 'order' => 11],
            'ac_filter_check' => ['name' => 'AC फ़िल्टर जाँचें - <span class="param">धूल से मुक्त</span>', 'order' => 12],
            'chuck_jaws_collet_clean' => ['name' => 'चक जॉज़/कोलेट साफ़ करें - <span class="param">धूल और चिप्स से मुक्त</span>', 'order' => 13],
            'cnc_guard_clean_all' => ['name' => 'CNC गार्ड सभी साफ़ करें - <span class="param">धूल और चिप्स से मुक्त</span>', 'order' => 14],
            'tool_inner_holder_check' => ['name' => 'टूल इनर होल्डर जाँचें - <span class="param">तनाव</span>', 'order' => 15],
            'check_tool_inserter_holder_tightness' => ['name' => 'टूल इन्सर्टर होल्डर टाइटनेस जाँचें - <span class="param">Tightness</span>', 'order' => 16],
            'chuck_pressure_check' => ['name' => 'चक प्रेशर जाँचें - <span class="param">3 ~ 12 Kg / Cm2</span>', 'order' => 17],
            'axis_slide_cover_movement_check' => ['name' => 'एक्सिस स्लाइड कवर मूवमेंट जाँचें - <span class="param">निर्धारित गति</span>', 'order' => 18],
            'chuck_greasing_check' => ['name' => 'चक ग्रीसिंग जाँचें - <span class="param">हर रोज</span>', 'order' => 19],
            'machine_mess_abnormal_sound_check' => ['name' => 'मशीन मेस असामान्य ध्वनि जाँचें - <span class="param">हर रोज</span>', 'order' => 20]
        ];

        $sql_parts = [];
        foreach ($fieldMap as $db_field_name => $data) {
            $sql_parts[] = "SELECT
                                '" . $db_field_name . "' AS original_field_name,
                                check_date,
                                " . $db_field_name . " AS field_value,
                                machine_number
                            FROM daily_maintenance_log
                            WHERE machine_number = '$selected_machine' AND MONTH(check_date) = $selected_month";
        }
        $union_sql = implode(" UNION ALL ", $sql_parts);

        $sql = "SELECT
                    original_field_name,";

        for ($i = 1; $i <= 31; $i++) {
            $sql .= " MAX(CASE WHEN DAY(check_date) = " . $i . " THEN field_value END) AS '" . $i . "',";
        }

        $sql = rtrim($sql, ',');

        $sql .= " FROM (" . $union_sql . ") AS source_table
                GROUP BY original_field_name
                ORDER BY ";

        $order_clauses = [];
        foreach ($fieldMap as $db_field_name => $data) {
            $order_clauses[] = "WHEN original_field_name = '" . $db_field_name . "' THEN " . $data['order'];
        }
        $sql .= "CASE " . implode(" ", $order_clauses) . " ELSE 99 END";


        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<h2>मशीन नंबर: " . $selected_machine . " - महीना: " . date("F", mktime(0, 0, 0, $selected_month, 10)) . "</h2>";
            echo "<table border='1'>";
            echo "<tr><th>क्रम</th><th>फ़ील्ड</th>";
            for ($i = 1; $i <= 31; $i++) {
                echo "<th>" . $i . "</th>";
            }
            echo "</tr>";
            $counter = 1;

            $ordered_results = [];
            while ($row = $result->fetch_assoc()) {
                $ordered_results[$fieldMap[$row['original_field_name']]['order']] = $row;
            }
            ksort($ordered_results);

            foreach ($ordered_results as $order => $row) {
                echo "<tr><td>" . $counter . "</td><td>" . $fieldMap[$row['original_field_name']]['name'] . "</td>";
                for ($i = 1; $i <= 31; $i++) {
                    echo "<td>" . (isset($row[$i]) ? $row[$i] : '-') . "</td>";
                }
                echo "</tr>";
                $counter++;
            }
            echo "</table>";
        } else {
            echo "<p>चुना गया महीना और मशीन के लिए कोई डेटा नहीं मिला.</p>";
        }
        $conn->close();
    }
    ?>

</body>

</html>