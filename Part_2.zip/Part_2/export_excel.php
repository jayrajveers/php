<?php
include('db_connection.php');

// Excel headers
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=production_data.xls");

// Query all records
$sql = "SELECT * FROM production";
$result = $conn->query($sql);

// Start table
echo "<table border='1'>
<tr>
    <th>ID</th><th>Date</th><th>Shift</th><th>Shift Start Time</th><th>Shift End Time</th>
    <th>Customer</th><th>Machine Number</th><th>Setup</th><th>Cycle Minutes</th>
    <th>Cycle Seconds</th><th>Loading Time</th><th>Hourly Production</th>
    <th>Shift Production</th><th>Setter Name</th><th>Operator Name</th><th>Ref Number</th>
    <th>Drowing & Rev no.</th><th>Lot Number</th><th>Lot Qty</th><th>Heat Number</th>
    <th>Grade</th><th>Part Count 1st</th><th>Part Count 2nd</th><th>Part Count 3rd</th>
    <th>PCWP</th><th>Breakdown List</th><th>Breakdown Time</th><th>Total Production</th>
</tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    foreach ($row as $value) {
        echo "<td>" . $value . "</td>";
    }
    echo "</tr>";
}
echo "</table>";

$conn->close();
?>
