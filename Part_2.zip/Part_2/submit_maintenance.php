<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('db_connection_mach.php'); // તમારી ડેટાબેઝ કનેક્શન ફાઇલનો સમાવેશ કરો

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect data from the form
    $machine_number = $_POST['machine_number'];
    $date = $_POST['date'];
    $shift = $_POST['shift'];
    $lubrication_tank_oil_level = $_POST['lubrication_tank_oil_level'];
    $hydraulic_tank_oil_level = $_POST['hydraulic_tank_oil_level'];
    $hydraulic_pressure = $_POST['hydraulic_pressure'];
    $axis_slide_cover = $_POST['axis_slide_cover'];
    $machine_mess_oil_coolant_leakage = $_POST['machine_mess_oil_coolant_leakage'];
    $chips_machine_conveyor_working = $_POST['chips_machine_conveyor_working'];
    $central_tank_coolant_level = $_POST['central_tank_coolant_level'];
    $coolant_ph = $_POST['coolant_ph'];
    $chips_conveyor_motor_working = $_POST['chips_conveyor_motor_working'];
    $tapan_check_ac = $_POST['tapan_check_ac'];
    $ac_guard_clean = $_POST['ac_guard_clean'];
    $ac_filter_check = $_POST['ac_filter_check'];
    $chuck_jaws_collet_clean = $_POST['chuck_jaws_collet_clean'];
    $cnc_guard_clean_all = $_POST['cnc_guard_clean_all'];
    $tool_inner_holder_check = $_POST['tool_inner_holder_check'];
    $check_tool_inserter_holder_tightness = $_POST['check_tool_inserter_holder_tightness'];
    $chuck_pressure_check = $_POST['chuck_pressure_check'];
    $axis_slide_cover_movement_check = $_POST['axis_slide_cover_movement_check'];
    $chuck_greasing_check = $_POST['chuck_greasing_check'];
    $machine_mess_abnormal_sound_check = $_POST['machine_mess_abnormal_sound_check'];

    // Prepare SQL query
    $sql = "INSERT INTO daily_maintenance_log (
        machine_number, check_date, shift, lubrication_tank_oil_level, hydraulic_tank_oil_level, 
        hydraulic_pressure, axis_slide_cover, machine_mess_oil_coolant_leakage, 
        chips_machine_conveyor_working, central_tank_coolant_level, coolant_ph, 
        chips_conveyor_motor_working, tapan_check_ac, ac_guard_clean, ac_filter_check, 
        chuck_jaws_collet_clean, cnc_guard_clean_all, tool_inner_holder_check, 
        check_tool_inserter_holder_tightness, chuck_pressure_check, 
        axis_slide_cover_movement_check, chuck_greasing_check, machine_mess_abnormal_sound_check
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql); // આ લાઈન બદલો
    if ($stmt === false) {
        echo "Error preparing statement: " . $conn->error;
        exit;
    }

    $stmt->bind_param(
        "sssssssssssssssssssssss",  // Data types: s = string
        $machine_number, $date, $shift, $lubrication_tank_oil_level, $hydraulic_tank_oil_level,
        $hydraulic_pressure, $axis_slide_cover, $machine_mess_oil_coolant_leakage,
        $chips_machine_conveyor_working, $central_tank_coolant_level, $coolant_ph,
        $chips_conveyor_motor_working, $tapan_check_ac, $ac_guard_clean, $ac_filter_check,
        $chuck_jaws_collet_clean, $cnc_guard_clean_all, $tool_inner_holder_check,
        $check_tool_inserter_holder_tightness, $chuck_pressure_check,
        $axis_slide_cover_movement_check, $chuck_greasing_check, $machine_mess_abnormal_sound_check
    );

    if ($stmt->execute()) {
        echo "<div style='text-align:center; margin-top: 50px;'>
                <h2 style='color: green;'>Maintenance checksheet data added successfully!</h2>
                <a href='form.php' style='
                    display: inline-block;
                    margin-top: 20px;
                    padding: 10px 20px;
                    background-color: #007BFF;
                    color: white;
                    text-decoration: none;
                    border-radius: 5px;
                    font-size: 16px;
                '>Back to Form</a>
              </div>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>