<?php
// home_page.php
// તમે અહીં સેશન શરૂ કરી શકો છો અથવા અન્ય કોઈ PHP લોજિક ઉમેરી શકો છો
// session_start();
// જો યુઝર લોગ ઇન ન હોય તો રીડાયરેક્ટ કરી શકાય છે.
?>
<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CNC Department - ERP ડેશબોર્ડ</title>
    <link rel="stylesheet" href="inprocess_report_entry.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* General Body and Layout */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; /* SAP-like font */
            margin: 0;
            padding: 0;
            background-color: #f0f2f5; /* Using direct values as variables are not defined in this snippet */
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }

        /* Header */
        .header {
            background-color: #34495e; /* Example primary color */
            color: #ffffff;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1); /* Example shadow color */
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .header .logo {
            height: 40px; /* Adjust logo size */
            margin-right: 15px;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
			color: #ffffff;
        }

        /* Main Container for Sidebar and Content */
        .main-container {
            display: flex;
            flex: 1;
            width: 100%;
        }

        /* Sidebar Navigation */
        .sidebar {
            width: 250px;
            background-color: #ffffff; /* Example card background */
            box-shadow: 2px 0 5px rgba(0,0,0,0.1); /* Example shadow color */
            padding-top: 20px;
            flex-shrink: 0; /* Prevent sidebar from shrinking */
        }
        .sidebar h3 {
            color: #3498db; /* Example primary color */
            text-align: center;
            margin-bottom: 20px;
            padding: 0 15px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 5px;
        }
        .sidebar ul li a {
            display: block;
            padding: 12px 20px;
            color: #1c1e21; /* Example text color */
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.3s ease, color 0.3s ease;
            border-left: 5px solid transparent;
        }
        .sidebar ul li a:hover,
        .sidebar ul li a.active {
            background-color: #3498db; /* Example primary color */
            color: #ffffff;
            border-left-color: #e67e22; /* Example accent color */
        }

        /* Dropdown specific styles within sidebar */
        .sidebar ul li.dropdown a {
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .sidebar ul li.dropdown .dropdown-content {
            display: none;
            background-color: #f0f2f5; /* Lighter background for dropdown */
            min-width: 100%;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.05); /* Inner shadow for depth */
            z-index: 1;
        }

        .sidebar ul li.dropdown .dropdown-content a {
            color: #1c1e21; /* Example text color */
            padding: 10px 20px 10px 30px; /* Indent sub-items */
            text-decoration: none;
            display: block;
            text-align: left;
            font-size: 15px;
            transition: background-color 0.2s ease;
            border-left: 3px solid transparent; /* Subtle border for sub-items */
        }

        .sidebar ul li.dropdown .dropdown-content a:hover {
            background-color: #e0e0e0; /* Light hover for sub-items */
            color: #3498db; /* Example primary color */
            border-left-color: #e67e22; /* Example accent color */
        }

        .sidebar ul li.dropdown.active > .dropdown-content {
            display: block; /* Show dropdown content if parent is active */
        }

        /* Content Area - MODIFIED FOR FLEXBOX */
        .content-area {
            flex-grow: 1;
            padding: 20px;
            background-color: #f0f2f5; /* Example background color */
            overflow-y: auto; /* Enable scrolling for content */
            display: flex; /* Make it a flex container */
            flex-wrap: wrap; /* Allow items to wrap to the next line */
            gap: 20px; /* Space between flex items */
            justify-content: space-around; /* Distribute items evenly with space around them */
        }

        /* Dashboard-like cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            background-color: #ffffff; /* Example card background */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* Example shadow color */
            padding: 25px;
            text-align: center;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            cursor: pointer;
            border-top: 5px solid #e67e22; /* Example accent color */
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.12);
        }
        .card h2 {
            color: #3498db; /* Example primary color */
            margin-top: 0;
            font-size: 20px;
            margin-bottom: 15px;
        }
        .card p {
            color: #65676b; /* Example light text color */
            font-size: 14px;
        }
        .card .icon {
            font-size: 40px;
            color: #2c3e50; /* Example secondary color */
            margin-bottom: 15px;
        }

        /* Footer */
        .footer {
            background-color: #2c3e50; /* Example secondary color */
            color: #ffffff;
            text-align: center;
            padding: 15px 20px;
            font-size: 14px;
            box-shadow: 0 -2px 4px rgba(0,0,0,0.1); /* Example shadow color */
            margin-top: auto; /* Pushes footer to the bottom */
        }

        /* Chart specific styles - MODIFIED FOR FLEXBOX LAYOUT */
         .chart-container {
            position: relative;
            margin: 0; /* Remove auto margin, flexbox handles spacing */
            max-width: 48%; /* Allow two charts per row with some space */
            flex-basis: 48%; /* Initial size for flex item */
            height: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            /* Ensure charts have enough space to fit in two columns */
            min-width: 300px; /* Prevent charts from becoming too narrow */
        }
        .chart-container h2 {
            text-align: center;
            color: #3498db;
            margin-bottom: 15px;
        }

        /* Basic Responsive Adjustments */
        @media (max-width: 768px) {
            .main-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                padding-top: 10px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }
            .sidebar ul {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }
            .sidebar ul li {
                margin: 5px;
            }
            .sidebar ul li a {
                padding: 10px 15px;
            }
            .header h1 {
                font-size: 20px;
            }
            /* For smaller screens, stack charts again */
            .content-area {
                flex-direction: column; /* Stack charts vertically */
                align-items: center; /* Center charts when stacked */
                gap: 20px; /* Maintain gap between stacked charts */
            }
            .chart-container {
                max-width: 95%; /* Take more width when stacked */
                flex-basis: auto; /* Allow natural sizing */
                min-width: unset; /* Remove min-width when stacking */
            }
        }

    </style>
</head>
<body>
    <div class="header">
        <h1>Duhee Alloy Steel Processors</h1>
    </div>

    <div class="main-container">
        <aside class="sidebar">
            <h3>મેનુ</h3>
            <ul>
                <li><a href="home_page.php">HOME PAGE</a></li>
				<li class="button">
                    <a href="add_data.php">&#10010; ADD</a>
              	<li class="button">
                    <a href="inprocess_master.php">&#128202; INPROCESS</a>
				<li class="button">
					<a href="view_records.php">&#128203; RECORDS</a>
				<li class="dropdown">
                    <a href="#">LOGOUT</a>
                    <div class="dropdown-content">
                        <a href="logout.php">Logout</a>
                    </div>
                </li>
            </ul>
        </aside>

        <main class="content-area">
            <h1>CNC ડિપાર્ટમેન્ટ ડેશબોર્ડ</h1>
            <p>CNC ડિપાર્ટમેન્ટ સંબંધિત કાર્યો માટે અહીંથી નેવિગેટ કરો. નીચેના કાર્ડ્સ તમને મુખ્ય મોડ્યુલો સુધી ઝડપી પહોંચ પ્રદાન કરે છે.</p>

            <div class="chart-container">
                <h2>Daily Production</h2>
                <canvas id="dailyProductionChart"></canvas>
            </div>

            <div class="chart-container">
                <h2>Monthly Production</h2>
                <canvas id="monthlyProductionChart"></canvas>
            </div>

            <div class="chart-container">
                <h2>Daily Rejection</h2>
                <canvas id="dailyRejectionChart"></canvas>
            </div>

            <div class="chart-container">
                <h2>Monthly Rejection</h2>
                <canvas id="monthlyRejectionChart"></canvas>
            </div>
        </main>
    </div>

    <footer class="footer">
        <p>&copy; <?php echo date("Y"); ?> Duhee Allowy Steel All rights reserved.</p>
    </footer>

    <script>
        // JavaScript for dropdown functionality and active link highlighting
        document.addEventListener('DOMContentLoaded', function() {
            const currentPath = window.location.pathname.split('/').pop();
            const sidebarLinks = document.querySelectorAll('.sidebar ul li a');
            const dropdowns = document.querySelectorAll('.sidebar .dropdown');

            // Set active class for direct links
            sidebarLinks.forEach(link => {
                if (link.getAttribute('href') === currentPath) {
                    link.classList.add('active');
                }
            });

            // Handle dropdown click to toggle visibility and active state
            dropdowns.forEach(dropdown => {
                const dropdownToggle = dropdown.querySelector('a');
                const dropdownContent = dropdown.querySelector('.dropdown-content');

                // Check if any sub-link within this dropdown is active
                let hasActiveChild = false;
                if (dropdownContent) {
                    const subLinks = dropdownContent.querySelectorAll('a');
                    subLinks.forEach(subLink => {
                        if (subLink.getAttribute('href') === currentPath) {
                            subLink.classList.add('active'); // Highlight sub-link
                            dropdown.classList.add('active'); // Activate parent dropdown
                            hasActiveChild = true;
                        }
                    });
                }

                // If a child is active, ensure the dropdown content is displayed
                if (hasActiveChild) {
                    dropdownContent.style.display = 'block';
                }

                // Add click listener for dropdown toggle
                dropdownToggle.addEventListener('click', function(event) {
                    event.preventDefault(); // Prevent default link behavior
                    // Toggle the 'active' class on the parent li.dropdown
                    dropdown.classList.toggle('active');
                    // Toggle display of the dropdown content
                    if (dropdownContent) {
                        dropdownContent.style.display = dropdown.classList.contains('active') ? 'block' : 'none';
                    }
                });
            });

            // Chart rendering logic
            fetch('get_chart_data.php')
                .then(response => response.json())
                .then(data => {
                    // Daily Production Chart
                    const dailyProdCtx = document.getElementById('dailyProductionChart').getContext('2d');
                    new Chart(dailyProdCtx, {
                        type: 'line',
                        data: {
                            labels: data.daily_production.map(row => row.date),
                            datasets: [{
                                label: 'Daily Production',
                                data: data.daily_production.map(row => row.total_prod),
                                borderColor: 'rgb(75, 192, 192)',
                                tension: 0.1,
                                fill: false
                            }]
                        },
                        options: {
                            responsive: true,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    title: {
                                        display: true,
                                        text: 'Total Production'
                                    }
                                },
                                x: {
                                    title: {
                                        display: true,
                                        text: 'Date'
                                    }
                                }
                            }
                        }
                    });

                    // Monthly Production Chart
                    const monthlyProdCtx = document.getElementById('monthlyProductionChart').getContext('2d');
                    new Chart(monthlyProdCtx, {
                        type: 'bar',
                        data: {
                            labels: data.monthly_production.map(row => row.month),
                            datasets: [{
                                label: 'Monthly Production',
                                data: data.monthly_production.map(row => row.total_prod),
                                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                                borderColor: 'rgba(54, 162, 235, 1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    title: {
                                        display: true,
                                        text: 'Total Production'
                                    }
                                },
                                x: {
                                    title: {
                                        display: true,
                                        text: 'Month'
                                    }
                                }
                            }
                        }
                    });

                    // Daily Rejection Chart
                    const dailyRejCtx = document.getElementById('dailyRejectionChart').getContext('2d');
                    new Chart(dailyRejCtx, {
                        type: 'line',
                        data: {
                            labels: data.daily_rejection.map(row => row.date),
                            datasets: [{
                                label: 'Daily Rejection',
                                data: data.daily_rejection.map(row => row.total_rej),
                                borderColor: 'rgb(255, 99, 132)',
                                tension: 0.1,
                                fill: false
                            }]
                        },
                        options: {
                            responsive: true,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    title: {
                                        display: true,
                                        text: 'Total Rejection'
                                    }
                                },
                                x: {
                                    title: {
                                        display: true,
                                        text: 'Date'
                                    }
                                }
                            }
                        }
                    });

                    // Monthly Rejection Chart
                    const monthlyRejCtx = document.getElementById('monthlyRejectionChart').getContext('2d');
                    new Chart(monthlyRejCtx, {
                        type: 'bar',
                        data: {
                            labels: data.monthly_rejection.map(row => row.month),
                            datasets: [{
                                label: 'Monthly Rejection',
                                data: data.monthly_rejection.map(row => row.total_rej),
                                backgroundColor: 'rgba(255, 159, 64, 0.6)',
                                borderColor: 'rgba(255, 159, 64, 1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    title: {
                                        display: true,
                                        text: 'Total Rejection'
                                    }
                                },
                                x: {
                                    title: {
                                        display: true,
                                        text: 'Month'
                                    }
                                }
                            }
                        }
                    });
                })
                .catch(error => console.error('Error fetching chart data:', error));
        });
    </script>
</body>
</html>