<?php
// Database connection parameters - **UPDATE THESE WITH YOUR ACTUAL DETAILS**
$servername = "localhost";
$username = "root"; // e.g., "root"
$password = ""; // e.g., "" for XAMPP default
$dbname = "dasp";   // e.g., "cnc_reports"

$conn = null; // Initialize connection variable
$success_messages = [];
$error_messages = [];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve common training details (same for all employees in this batch)
        $training_title = htmlspecialchars($_POST['training_title'] ?? '');
        $training_date = $_POST['training_date'] ?? null;
        $training_type = htmlspecialchars($_POST['training_type'] ?? '');
        $training_provider = htmlspecialchars($_POST['training_provider'] ?? '');
        $duration_hours = $_POST['duration_hours'] ?? null;
        $assessment_results_common = htmlspecialchars($_POST['assessment_results'] ?? ''); // Common assessment
        $competency_level_achieved_common = htmlspecialchars($_POST['competency_level_achieved'] ?? ''); // Common competency
        $next_training_due_date = $_POST['next_training_due_date'] ?? null;
        $trainer_name = htmlspecialchars($_POST['trainer_name'] ?? '');
        $remarks = htmlspecialchars($_POST['remarks'] ?? '');

        // Prepare the INSERT statement
        $stmt = $conn->prepare("INSERT INTO employee_training_records (
            employee_name, employee_id, department, training_title, training_date,
            training_type, training_provider, duration_hours, assessment_results,
            competency_level_achieved, next_training_due_date, trainer_name, remarks
        ) VALUES (
            :employee_name, :employee_id, :department, :training_title, :training_date,
            :training_type, :training_provider, :duration_hours, :assessment_results,
            :competency_level_achieved, :next_training_due_date, :trainer_name, :remarks
        )");

        // Loop through each employee and insert their record
        if (isset($_POST['employees']) && is_array($_POST['employees'])) {
            foreach ($_POST['employees'] as $employee_data) {
                $employee_name = htmlspecialchars($employee_data['name'] ?? '');
                $employee_id = htmlspecialchars($employee_data['id'] ?? '');
                $department = htmlspecialchars($employee_data['department'] ?? '');

                // Use individual assessment/competency if available, otherwise common one
                // You can uncomment the following lines if you enable individual fields in the form
                // $assessment_results = htmlspecialchars($employee_data['assessment_results'] ?? $assessment_results_common);
                // $competency_level_achieved = htmlspecialchars($employee_data['competency_level_achieved'] ?? $competency_level_achieved_common);

                // For now, using common assessment/competency for simplicity
                $assessment_results = $assessment_results_common;
                $competency_level_achieved = $competency_level_achieved_common;


                if (!empty($employee_name)) { // Only process if employee name is provided
                    $stmt->bindParam(':employee_name', $employee_name);
                    $stmt->bindParam(':employee_id', $employee_id);
                    $stmt->bindParam(':department', $department);
                    $stmt->bindParam(':training_title', $training_title);
                    $stmt->bindParam(':training_date', $training_date);
                    $stmt->bindParam(':training_type', $training_type);
                    $stmt->bindParam(':training_provider', $training_provider);
                    $stmt->bindParam(':duration_hours', $duration_hours);
                    $stmt->bindParam(':assessment_results', $assessment_results);
                    $stmt->bindParam(':competency_level_achieved', $competency_level_achieved);
                    $stmt->bindParam(':next_training_due_date', $next_training_due_date);
                    $stmt->bindParam(':trainer_name', $trainer_name);
                    $stmt->bindParam(':remarks', $remarks);

                    $stmt->execute();
                    $success_messages[] = "કર્મચારી <strong>" . htmlspecialchars($employee_name) . "</strong> (ID: " . htmlspecialchars($employee_id) . ") નો રેકોર્ડ સફળતાપૂર્વક સાચવ્યો. (ID: " . $conn->lastInsertId() . ")";
                } else {
                    $error_messages[] = "એક કર્મચારીનું નામ ખાલી છે, તેથી તેનો રેકોર્ડ સાચવવામાં આવ્યો નથી.";
                }
            }
        } else {
            $error_messages[] = "કોઈ કર્મચારી ડેટા મળ્યો નથી. કૃપા કરીને ઓછામાં ઓછો એક કર્મચારી ઉમેરો.";
        }

        echo "<!DOCTYPE html><html lang='gu'><head><meta charset='UTF-8'><title>સબમિશન પરિણામ</title>";
        echo "<style>
            body { font-family: Arial, sans-serif; margin: 20px; background-color: #e9f5ff; color: #333; }
            .container { background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); max-width: 800px; margin: auto; border-top: 5px solid #28a745;}
            h2 { color: #28a745; text-align: center; margin-bottom: 20px; }
            .success-msg { color: #28a745; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 10px; border-radius: 5px; margin-bottom: 10px; }
            .error-msg { color: #dc3545; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; border-radius: 5px; margin-bottom: 10px; }
            .nav-buttons { display: flex; justify-content: space-around; margin-top: 30px; }
            .nav-buttons a { background-color: #007bff; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; transition: background-color 0.3s ease; }
            .nav-buttons a:hover { background-color: #0056b3; }
        </style></head><body><div class='container'>";
        echo "<h2>તાલીમ રેકોર્ડ સબમિશન પરિણામ</h2>";

        foreach ($success_messages as $msg) {
            echo "<p class='success-msg'>" . $msg . "</p>";
        }
        foreach ($error_messages as $msg) {
            echo "<p class='error-msg'>" . $msg . "</p>";
        }

        if (empty($success_messages) && empty($error_messages)) {
            echo "<p class='error-msg'>કોઈ ડેટા સબમિટ થયો નથી.</p>";
        }

        echo "<div class='nav-buttons'>";
        echo "<a href='training_form.php'>નવા બલ્ક રેકોર્ડ ઉમેરો</a>";
        echo "<a href='view_training_reports.php'>તાલીમ રિપોર્ટ્સ જુઓ</a>";
        echo "</div>";
        echo "</div></body></html>";

    } else {
        echo "<p>આ ફાઇલ સીધી એક્સેસ કરી શકાતી નથી. કૃપા કરીને ફોર્મ સબમિટ કરો.</p>";
    }

} catch(PDOException $e) {
    echo "<!DOCTYPE html><html lang='gu'><head><meta charset='UTF-8'><title>ભૂલ</title>";
    echo "<style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f8d7da; color: #721c24; }
        .container { background-color: #ffe8ee; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); max-width: 600px; margin: auto; border-top: 5px solid #dc3545;}
        h2 { color: #dc3545; text-align: center; margin-bottom: 20px; }
        p { line-height: 1.5; }
    </style></head><body><div class='container'>";
    echo "<h2>ડેટાબેઝમાં ડેટા સાચવવામાં ભૂલ!</h2>";
    echo "<p>કૃપા કરીને નીચેની ભૂલ તપાસો:</p>";
    echo "<p><strong>ભૂલ:</strong> " . $e->getMessage() . "</p>";
    echo "<p>કૃપા કરીને ડેટાબેઝ કનેક્શન સેટિંગ્સ (`servername`, `username`, `password`, `dbname`) અને કોષ્ટકની રચના તપાસો.</p>";
    echo "</div></body></html>";
}

$conn = null; // Close the database connection
?>