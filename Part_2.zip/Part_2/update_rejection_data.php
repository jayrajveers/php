<?php
    session_start();

    // Check karo ke user logged in chhe ke nahi.
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        // Jo logged in nathi, to login page par redirect karo.
        header("location: login.php");
        exit;
    }
?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dasp";

// કનેક્શન બનાવો
$conn = new mysqli($servername, $username, $password, $dbname);

// કનેક્શન તપાસો
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // ફોર્મમાંથી ડેટા મેળવો
	$id = $_POST['id'];
	$date = $_POST['Date'];
    $shift = $_POST['Shift'];
    $machineNumber = $_POST['MachineNumber'];
    $partCode = $_POST['ref_number'];
    $lotNumber = $_POST['lot_number'];
    $operator = $_POST['operator_name'];
    $setter = $_POST['setter'];
    $forgingOdUnfill = $_POST['FORGING_OD_UNFILL'];
    $forgingOdLaping = $_POST['FORGING_OD_LAPING'];
    $forgingOdCrake = $_POST['FORGING_OD_CRAKE'];
    $forgingBoreUnfill = $_POST['FORGING_BORE_UNFILL'];
    $forgingBoreLaping = $_POST['FORGING_BORE_LAPING'];
    $forgingBoreCrake = $_POST['FORGING_BORE_CRAKE'];
    $forgingWidthUnfill = $_POST['FORGING_WIDTH_UNFILL'];
    $forgingWidthLaping = $_POST['FORGING_WIDTH_LAPING'];
    $forgingWidthCrake = $_POST['FORGING_WIDTH_CRAKE'];
    $forgingTrackUnfill = $_POST['FORGING_TRACK_UNFILL'];
    $forgingTrackLaping = $_POST['FORGING_TRACK_LAPING'];
    $forgingTrackCarke = $_POST['FORGING_TRACK_CARKE'];
    $inhouse = $_POST['INHOUSE'];
    $vendorName = $_POST['VendorName'];
    $vendorNos = $_POST['Vendornos'];
    $cncWidth = $_POST['CNC_WIDTH'];
    $cncId = $_POST['CNC_ID'];
    $cncOd = $_POST['CNC_OD'];
    $cncTrack = $_POST['CNC_TRACK'];
    $cncLocation = $_POST['CNC_LOCATION'];
    $cncLoadingMistake = $_POST['CNC_LOADING_MISTAKE'];
    $cncGroove = $_POST['CNC_GROOVE'];
    $cncSetting = $_POST['CNC_SETTING'];
    $cncOther = $_POST['CNC_OTHER'];
    $forgingTotal = $_POST['FORGING_TOTAL'];
    $cncTotal = $_POST['CNC_Total'];
    $vendorTotal = $_POST['VENDOR_TOTAL'];
    $total = $_POST['TOTAL'];
	 // SQL ક્વેરી અપડેટ કરો
    $sql = "UPDATE rejectiondata SET
            	FORGING_OD_UNFILL = ?,
                FORGING_OD_LAPING = ?,
                FORGING_OD_CRAKE = ?,
                FORGING_BORE_UNFILL = ?,
                FORGING_BORE_LAPING = ?,
                FORGING_BORE_CRAKE = ?,
                FORGING_WIDTH_UNFILL = ?,
                FORGING_WIDTH_LAPING = ?,
                FORGING_WIDTH_CRAKE = ?,
                FORGING_TRACK_UNFILL = ?,
                FORGING_TRACK_LAPING = ?,
                FORGING_TRACK_CARKE = ?,
                INHOUSE = ?,
                VendorName = ?,
                vendor_nos = ?,
                CNC_WIDTH = ?,
                CNC_ID = ?,
                CNC_OD = ?,
                CNC_TRACK = ?,
                CNC_LOCATION = ?,
                CNC_LOADING_MISTAKE = ?,
                CNC_GROOVE = ?,
                CNC_SETTING = ?,
                CNC_OTHER = ?,
                FORGING_TOTAL = ?,
                CNC_Total = ?,
                VENDOR_TOTAL = ?,
                TOTAL = ?
				    Where id = ?";

    // પ્રિપેર્ડ સ્ટેટમેન્ટ બનાવો
    $stmt = $conn->prepare($sql);

    // પેરામીટર્સને બાઇન્ડ કરો
    $stmt->bind_param("iiiiiiiiiiiiisiiiiiiiiiiiiiii",
                       $forgingOdUnfill, $forgingOdLaping, $forgingOdCrake,
                        $forgingBoreUnfill, $forgingBoreLaping, $forgingBoreCrake,
                        $forgingWidthUnfill, $forgingWidthLaping, $forgingWidthCrake,
                        $forgingTrackUnfill, $forgingTrackLaping, $forgingTrackCarke,
                        $inhouse, $vendorName, $vendorNos,
                        $cncWidth, $cncId, $cncOd, $cncTrack, $cncLocation, $cncLoadingMistake,
                        $cncGroove, $cncSetting, $cncOther,
                        $forgingTotal, $cncTotal, $vendorTotal, $total, $id);

    // ક્વેરી એક્ઝીક્યુટ કરો
    if ($stmt->execute()) {
        echo "<p style='color: green; text-align: center; margin-top: 20px; font-size: 18px;'>Record updated successfully!</p>";
        echo "<p style='text-align: center;'><a href='rejection_data.php' style='text-decoration: none; padding: 10px 15px; background-color: #28a745; color: white; border-radius: 5px;'>Back to Records</a></p>";
    } else {
        echo "<p style='color: red; text-align: center; margin-top: 20px; font-size: 18px;'>Error updating record: " . $stmt->error . "</p>";
        echo "<p style='text-align: center;'><a href='rejection_data.php' style='text-decoration: none; padding: 10px 15px; background-color: #dc3545; color: white; border-radius: 5px;'>Back to Records</a></p>";
    }

    // સ્ટેટમેન્ટ બંધ કરો
    $stmt->close();
}

// કનેક્શન બંધ કરો
$conn->close();
?>