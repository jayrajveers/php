<?php
    session_start();

    // Check karo ke user logged in chhe ke nahi.
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        // Jo logged in nathi, to login page par redirect karo.
        header("location: login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <meta charset="UTF-8">
    <title>Machine Stop Log</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        /* Custom Theme CSS based on the provided dashboard image */
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif; /* Poppins font for modern look */
            background-color: #f0f2f5; /* Light grey background */
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column; /* Arrange items vertically */
            justify-content: flex-start; /* Align items at the top */
            align-items: center; /* Center items horizontally */
            min-height: 100vh;
        }

        .add-button-container {
            margin-bottom: 20px; /* Add space below the button */
            width: 95%; /* Match container width */
            max-width: 1200px; /* Adjusted to match container max-width */
            text-align: right; /* Align the button to the right */
        }

        .add-button {
            display: inline-block;
            background-color: #4a90e2; /* Primary blue color from dashboard */
            color: #fff;
            border: none;
            padding: 14px 30px; /* Larger padding for button */
            font-size: 17px; /* Larger font size */
            font-weight: bold;
            border-radius: 8px; /* Rounded button */
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Soft shadow */
        }

        .add-button:hover {
            background-color: #357ABD; /* Slightly darker blue on hover */
            transform: translateY(-2px); /* Slight lift effect */
        }

        .container {
            background-color: #ffffff; /* White background for the main form */
            padding: 30px 40px; /* More padding inside container */
            border-radius: 12px; /* More rounded corners like the dashboard cards */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow for depth */
            max-width: 1200px; /* Consistent max-width */
            width: 95%;
            border-top: 5px solid #4a90e2; /* Blue accent line at the top */
        }

        h2 {
            color: #333; /* Darker text for main heading */
            text-align: center;
            margin-bottom: 30px; /* More space below heading */
            font-weight: 600; /* Medium bold */
            font-size: 28px; /* Larger heading */
        }

        h2 svg {
            vertical-align: middle; /* Align icon with text */
            margin-right: 10px; /* Space between icon and text */
        }

        form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); /* Adjusted grid columns for better spacing */
            gap: 25px; /* Increased gap between form elements */
        }

        label {
            display: block;
            margin-bottom: 8px; /* Increased margin below labels */
            color: #555; /* Slightly lighter text for labels */
            font-weight: 600; /* Bolder labels */
            font-size: 15px;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        select {
            width: 100%;
            padding: 12px; /* Increased padding for inputs */
            border-radius: 8px; /* Rounded input fields */
            border: 1px solid #e0e0e0; /* Lighter, more subtle border */
            font-size: 16px;
            background-color: #fcfcfc; /* Very light background for inputs */
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        input:focus, select:focus {
            border-color: #4a90e2; /* Blue border on focus */
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.2); /* Soft blue glow on focus */
            outline: none; /* Remove default outline */
        }

        select {
            appearance: none; /* Remove default select arrow */
            background-image: url('data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 14 8" xmlns="http://www.w3.org/2000/svg"><path d="M1 1l6 6 6-6" fill="none" stroke="#666" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>');
            background-repeat: no-repeat;
            background-position: right 12px center;
            background-size: 10px;
        }

        .full-width {
            grid-column: 1 / -1;
        }

        .row {
            display: flex;
            gap: 15px; /* Consistent gap in rows */
        }

        .row input {
            flex: 1;
        }

        button[type="submit"] {
            background-color: #28a745; /* Green submit button */
            color: #fff;
            border: none;
            padding: 14px 25px; /* Adjusted button padding */
            font-size: 18px; /* Larger font size */
            font-weight: bold;
            border-radius: 8px; /* Rounded buttons */
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin-top: 25px;
            width: auto; /* Allow button to size based on content */
            display: block; /* Make it a block element to use margin auto for centering */
            margin-left: auto;
            margin-right: auto;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Subtle button shadow */
        }

        button[type="submit"]:hover {
            background-color: #218838; /* Darker green on hover */
            transform: translateY(-2px); /* Slight lift effect */
        }

        /* Select2 adjustments for enhanced appearance to match the theme */
        .select2-container--default .select2-selection--single {
            height: 44px; /* Match input height */
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            background-color: #fcfcfc;
            display: flex;
            align-items: center; /* Vertically align text */
        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 44px; /* Ensure text is centered vertically */
            padding-left: 12px;
            color: #333;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 42px; /* Adjust arrow height */
            right: 5px;
            top: 1px;
        }

        .select2-container--default .select2-results__option--highlighted.select2-results__option--selectable {
            background-color: #4a90e2; /* Highlight color in dropdown */
            color: white;
        }

        .select2-container--default .select2-results__option--selected {
            background-color: #f0f2f5; /* Selected item background */
            color: #333;
        }

        @media (max-width: 768px) {
            form {
                grid-template-columns: 1fr; /* Stack elements on smaller screens */
            }
            .container {
                padding: 20px;
            }
            h2 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
        <div class="add-button-container">
            <a href="add_data.php" class="add-button">
                Home Page
            </a>
        </div>
    <div class="container">
    <h2><svg viewBox="0 0 32 32" width="28" height="28" fill="#4a90e2"><path d="M22 16c0-3.31-2.69-6-6-6s-6 2.69-6 6 2.69 6 6 6 6-2.69 6-6zM16 2C8.27 2 2 8.27 2 16s6.27 14 14 14 14-6.27 14-14S23.73 2 16 2zm0 26c-6.63 0-12-5.37-12-12s5.37-12 12-12 12 5.37 12 12-5.37 12-12 12z"/></svg> CNC Machine Production Log Entry</h2>
        <form id="logForm" method="post" action="submit.php" onsubmit="return validateForm()">

            <label>Date: <input type="date" id="date" name="date" required></label>

            <label>Shift:
                <select name="shift" id="shift" required onchange="updateShiftTime()">
                    <option value="">Select</option>
                    <option value="Day">Day</option>
                    <option value="Night">Night</option>
                </select>
            </label>

            <label>Shift Start Time: <input type="text" id="start_time" name="shift_start_time" placeholder="HH:MM AM/PM" required></label>
            <label>Shift End Time: <input type="text" id="end_time" name="shift_end_time" placeholder="HH:MM AM/PM" required></label>

            <label>Customer:
                <select id="customer" name="customer"><option>Loading...</option></select>
            </label>

            <label>Machine Number:
                <select id="machine_number" name="machine_number"><option>Loading...</option></select>
            </label>

            <label>Setup:
                <select name="setup" required>
                    <option value="">Select</option>
                    <option value="0">-</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                </select>
            </label>

            <label>Cycle Time:
                <div class="row full-width">
                    <input type="number" name="cycle_minutes" id="cycle_minutes" placeholder="Minutes" required>
                    <input type="number" name="cycle_seconds" id="cycle_seconds" placeholder="Seconds" required>
                </div>
            </label>

            <label>Loading Time (Seconds): <input type="number" name="loading_time" id="loading_time" required></label>

            <label>Hourly Production: <input type="text" name="hourly_target" id="hourly_target" readonly></label>
            <label>Shift Production: <input type="text" name="shift_target" id="shift_target" readonly></label>

            <label>Setter Name:
                <select id="setter_name" name="setter_name"><option>Loading...</option></select>
            </label>

            <label>Operator Name:
                <select id="operator_name" name="operator_name"><option>Loading...</option></select>
            </label>

            <label>Ref Number:
                <select id="ref_number" name="ref_number" style="width: 100%;">
                    <option value="">Select</option>
                    </select>
            </label>

            <label>Drowing & Rev No.: <input type="text" name="drowing"></label>

            <label>Lot Number: <input type="text" name="lot_number" required></label>
            <label>Lot Qty: <input type="number" name="lot_qty" required></label>
            <label>Heat Number: <input type="text" name="heat_number"></label>

            <label>Grade:
                <select id="grade" name="grade"><option>Loading...</option></select>
            </label>

            <label>Part Count 1st: <input type="number" id="count1" name="part_count_1st"></label>
            <label>Part Count 2nd: <input type="number" id="count2" name="part_count_2nd"></label>
            <label>Part Count 3rd: <input type="number" id="count3" name="part_count_3rd"></label>

            <label>Part Count wise Production: <input type="text" name="pcwp" id="pcwp" readonly></label>

            <label>Breakdown List:
                <select id="breakdown_list" name="breakdown_list"><option>Loading...</option></select>
            </label>
            <label>Breakdown Time (Minutes): <input type="number" name="breakdown_time"></label>
            <label>Total Production: <input type="number" name="total_production"></label>
            <div class = "full-width">
                <button type="submit">✅ Submit</button>
            </div>
        </form>
        </div>

    <script>
        function updateShiftTime() {
            const shift = document.getElementById('shift').value;
            const start = document.getElementById('start_time');
            const end = document.getElementById('end_time');
            if (shift === "Day") {
                start.value = "08:00 AM";
                end.value = "08:00 PM";
            } else if (shift === "Night") {
                start.value = "08:00 PM";
                end.value = "08:00 AM";
            } else {
                start.value = "";
                end.value = "";
            }
            calculateTargetProduction();
        }

        function calculateTargetProduction() {
            const min = parseInt(document.getElementById('cycle_minutes').value) || 0;
            const sec = parseInt(document.getElementById('cycle_seconds').value) || 0;
            const loading = parseInt(document.getElementById('loading_time').value) || 0;

            const totalSec = (min * 60) + sec + loading;
            if (totalSec === 0) return;

            const hourly = Math.floor(3600 / totalSec);
            document.getElementById('hourly_target').value = hourly;

            const start = document.getElementById('start_time').value;
            const end = document.getElementById('end_time').value;

            if (start && end) {
                const startDate = new Date("01/01/2022 " + start);
                const endDate = new Date("01/01/2022 " + end);
                let diff = (endDate - startDate) / (1000 * 60 * 60);
                if (diff <= 0) diff += 24;
                document.getElementById('shift_target').value = diff * hourly;
            }
        }

        document.getElementById('cycle_minutes').addEventListener('input', calculateTargetProduction);
        document.getElementById('cycle_seconds').addEventListener('input', calculateTargetProduction);
        document.getElementById('loading_time').addEventListener('input', calculateTargetProduction);
		document.getElementById('start_time').addEventListener('input', calculateTargetProduction);
        document.getElementById('end_time').addEventListener('input', calculateTargetProduction);

        function calculatePCWP() {
            const c1 = parseInt(document.getElementById('count1').value) || 0;
            const c2 = parseInt(document.getElementById('count2').value) || 0;
            const c3 = parseInt(document.getElementById('count3').value) || 0;

            let result = "";

            // Logic for calculating result based on conditions
            if (c1 > 0 && c2 >= c1) {
                result = c2 - c1;
            }
            if (c3 >= c1 && c3 > c2) {
                result = c3 - c1;
            }

            // Setting the calculated result to the pcwp input field
            document.getElementById('pcwp').value = result;
        }

        // Event listeners for updating the pcwp field when input changes
        document.getElementById('count1').addEventListener('input', calculatePCWP);
        document.getElementById('count2').addEventListener('input', calculatePCWP);
        document.getElementById('count3').addEventListener('input', calculatePCWP);


        function validateForm() {
            const selectedDate = document.getElementById('date').value;
            const selectedShift = document.getElementById('shift').value;
            const selectedMachine = document.getElementById('machine_number').value;

            // Perform AJAX request to check for duplicates
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'check_duplicate.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (xhr.status === 200) {
                    if (xhr.responseText === 'duplicate') {
                        const confirmation = confirm('આ તારીખે, આ શિફ્ટમાં, આ મશીનનો ઉપયોગ એકવાર થઈ ગયો છે. શું તમે તેમ છતાં ઉમેરવા માંગો છો?');
                        if (confirmation) {
                            document.getElementById('logForm').submit(); // Allow form submission if user clicks "Yes"
                        } else {
                            return false; // Prevent form submission if user clicks "No"
                        }
                    } else {
                        document.getElementById('logForm').submit(); // Allow form submission if no duplicate
                    }
                } else {
                    alert('ડેટા ચકાસવામાં ભૂલ આવી.');
                    return true; // Allow submission in case of error (can be adjusted)
                }
            };
            xhr.onerror = function() {
                alert('સર્વર સાથે જોડાણમાં ભૂલ આવી.');
                return true; // Allow submission in case of error (can be adjusted)
            };
            xhr.send(`date=${selectedDate}&shift=${selectedShift}&machine_number=${selectedMachine}`);

            // Prevent default form submission while AJAX is in progress
            return false;
        }
    </script>

    <script>
        function loadDropdown(fieldId, columnName) {
            fetch('getOptions.php?type=' + encodeURIComponent(columnName))
                .then(response => response.json())
                .then(data => {
                    const select = document.getElementById(fieldId);
                    select.innerHTML = '<option value="">Select</option>';
                    data.forEach(item => {
                        const option = document.createElement('option');
                        option.value = item;
                        option.textContent = item;
                        select.appendChild(option);
                    });
                })
                .catch(error => {
                    console.error('Error loading ' + columnName + ' options:', error);
                });
        }

        document.addEventListener('DOMContentLoaded', function () {
            loadDropdown('customer', 'Customer');
            loadDropdown('machine_number', 'Machine Number');
            loadDropdown('setter_name', 'Setter Name');
            loadDropdown('operator_name', 'Operator Name');
            loadDropdown('ref_number', 'Ref Number');
            loadDropdown('grade', 'Grade');
            loadDropdown('breakdown_list', 'Breakdown List');
        });

    </script>
    <script>
        $(document).ready(function() {
            $('#ref_number').select2({
                placeholder: "Search Ref Number",
                allowClear: true
            });
        });
    </script>
	 <script>
        $(document).ready(function() {
            $('#operator_name').select2({
                placeholder: "Search Operator Name",
                allowClear: true
            });
        });
    </script>
	 <script>
        $(document).ready(function() {
            $('#grade').select2({
                placeholder: "Search Grade Name",
                allowClear: true
            });
        });
    </script>
	 <script>
        $(document).ready(function() {
            $('#customer').select2({
                placeholder: "Search customer Name",
                allowClear: true
            });
        });
    </script>
	<script>
        $(document).ready(function() {
            $('#setter_name').select2({
                placeholder: "Search Setter Name",
                allowClear: true
            });
        });
    </script>
	<script>
        $(document).ready(function() {
            $('#machine_number').select2({
                placeholder: "Search Machine Number",
                allowClear: true
            });
        });
    </script>
</body>
</html>