<?php

// ડેટાબેઝની વિગતો
$servername = "localhost"; // અથવા તમારો ડેટાબેઝ હોસ્ટ
$username = "root"; // તમારું ડેટાબેઝ વપરાશકર્તા નામ
$password = ""; // તમારું ડેટાબેઝ પાસવર્ડ
$dbname = "dasp";

try {
    // PDO ઓબ્જેક્ટ બનાવીને ડેટાબેઝ સાથે કનેક્ટ કરો
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8mb4", $username, $password);
    // ભૂલો માટે PDO એરર મોડને અપવાદ પર સેટ કરો
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // HTML ફોર્મમાંથી ડેટા મેળવો
    $date = $_POST['date'];
    $shift = $_POST['shift'];
    $machine_number = $_POST['machine_number'];
    $ref_number = $_POST['ref_number'];
    $lot_number = $_POST['lot_number'];
    $operator_name = $_POST['operator_name'];
    $setter = $_POST['setter'];
    $notes = $_POST['notes'];

    // છબીઓને હેન્ડલ કરવા માટે
    $image1 = null;
    $image2 = null;
    $image3 = null;
    $image4 = null;
    $image5 = null;

    if (isset($_FILES['images']) && is_array($_FILES['images']['name'])) {
        $uploadDir = 'uploads/'; // છબીઓ સ્ટોર કરવા માટે ડિરેક્ટરી બનાવો (ખાતરી કરો કે તે અસ્તિત્વમાં છે અને લખવા યોગ્ય છે)
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        for ($i = 0; $i < count($_FILES['images']['name']) && $i < 5; $i++) {
            if ($_FILES['images']['error'][$i] == UPLOAD_ERR_OK) {
                $tmpName = $_FILES['images']['tmp_name'][$i];
                $fileName = basename($_FILES['images']['name'][$i]);
                $uniqueFileName = uniqid() . '_' . $fileName;
                $destination = $uploadDir . $uniqueFileName;
                if (move_uploaded_file($tmpName, $destination)) {
                    if ($i == 0) $image1 = $destination;
                    if ($i == 1) $image2 = $destination;
                    if ($i == 2) $image3 = $destination;
                    if ($i == 3) $image4 = $destination;
                    if ($i == 4) $image5 = $destination;
                } else {
                    echo "ફાઇલ અપલોડ કરવામાં ભૂલ: " . $_FILES['images']['name'][$i] . "<br>";
                    // તમે અહીં ભૂલ હેન્ડલિંગ ઉમેરી શકો છો
                }
            } elseif ($_FILES['images']['error'][$i] != UPLOAD_ERR_NO_FILE) {
                echo "ફાઇલ અપલોડમાં ભૂલ: " . $_FILES['images']['name'][$i] . " - ભૂલ કોડ: " . $_FILES['images']['error'][$i] . "<br>";
                // તમે અહીં વિગતવાર ભૂલ હેન્ડલિંગ ઉમેરી શકો છો
            }
        }
    }

    // ડેટા દાખલ કરવા માટે SQL ક્વેરી
    $sql = "INSERT INTO note (date, shift, machine_number, ref_number, lot_number, operator_name, setter, image1, image2, image3, image4, image5, notes)
            VALUES (:date, :shift, :machine_number, :ref_number, :lot_number, :operator_name, :setter, :image1, :image2, :image3, :image4, :image5, :notes)";

    // તૈયાર કરેલું સ્ટેટમેન્ટ બનાવો
    $stmt = $conn->prepare($sql);

    // પરિમાણો બાંધો
    $stmt->bindParam(':date', $date);
    $stmt->bindParam(':shift', $shift);
    $stmt->bindParam(':machine_number', $machine_number);
    $stmt->bindParam(':ref_number', $ref_number);
    $stmt->bindParam(':lot_number', $lot_number);
    $stmt->bindParam(':operator_name', $operator_name);
    $stmt->bindParam(':setter', $setter);
    $stmt->bindParam(':image1', $image1);
    $stmt->bindParam(':image2', $image2);
    $stmt->bindParam(':image3', $image3);
    $stmt->bindParam(':image4', $image4);
    $stmt->bindParam(':image5', $image5);
    $stmt->bindParam(':notes', $notes);

    // ક્વેરી એક્ઝિક્યુટ કરો
    $stmt->execute();

    echo "<div style='font-family: sans-serif; text-align: center; margin-top: 50px; background-color: #f0f9ff; padding: 20px; border: 1px solid #e0f2f7; border-radius: 5px;'>";
    echo "<h2 style='color: #1c84c6;'>ડેટા સફળતાપૂર્વક સંગ્રહિત થયો!</h2>";
    echo "<p><a href='home_page.php' style='color: #0d47a1; text-decoration: none; font-weight: bold;'>હોમ પેજ પર પાછા જાઓ</a></p>";
    echo "</div>";

} catch(PDOException $e) {
    echo "<div style='font-family: sans-serif; text-align: center; margin-top: 50px; background-color: #ffebee; padding: 20px; border: 1px solid #ef9a9a; border-radius: 5px;'>";
    echo "<h2 style='color: #d32f2f;'>ડેટા સંગ્રહિત કરવામાં ભૂલ!</h2>";
    echo "<p>ભૂલ: " . $e->getMessage() . "</p>";
    echo "<p>કૃપા કરીને સંચાલકનો સંપર્ક કરો અથવા પછીથી ફરી પ્રયાસ કરો.</p>";
    echo "</div>";
}

$conn = null; // કનેક્શન બંધ કરો

?>