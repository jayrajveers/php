<?php
// Database connection parameters - **UPDATE THESE WITH YOUR ACTUAL DETAILS**
$servername = "localhost"; // Replace with your database server name
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "dasp"; // Replace with your database name

$conn = null; // Initialize connection variable

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    $sql = "SELECT id, analysis_date, machine_id, part_name, problem_statement, team_leader, created_at FROM why_why_analysis_records WHERE 1=1";
    $params = [];

    // Filter by Date Range
    $start_date = $_GET['start_date'] ?? '';
    $end_date = $_GET['end_date'] ?? '';

    if (!empty($start_date)) {
        $sql .= " AND analysis_date >= :start_date";
        $params[':start_date'] = $start_date;
    }
    if (!empty($end_date)) {
        $sql .= " AND analysis_date <= :end_date";
        $params[':end_date'] = $end_date;
    }

    $sql .= " ORDER BY analysis_date DESC, created_at DESC";

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $reports = $stmt->fetchAll();

} catch (PDOException $e) {
    echo "<p style='color: red;'>ડેટાબેઝ ભૂલ: " . $e->getMessage() . "</p>";
    $reports = []; // Ensure $reports is an empty array on error
} finally {
    if ($conn) {
        $conn = null; // Close the database connection
    }
}
?>
<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Why-Why Analysis Reports</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f7f6;
            color: #333;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            max-width: 1200px;
            margin: auto;
            border-top: 5px solid #007bff;
        }
        h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 25px;
            font-size: 2.2em;
        }
        .filter-section {
            background-color: #e9f5ff;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 25px;
            display: flex;
            gap: 15px;
            align-items: flex-end;
            flex-wrap: wrap;
        }
        .filter-group {
            flex: 1;
            min-width: 180px;
        }
        .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        .filter-group input[type="date"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .filter-group button {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }
        .filter-group button:hover {
            background-color: #218838;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            color: #555;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #e6f7ff;
        }
        .view-details-btn {
            background-color: #007bff;
            color: white;
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 0.9em;
            transition: background-color 0.3s ease;
        }
        .view-details-btn:hover {
            background-color: #0056b3;
        }
        .no-records {
            text-align: center;
            padding: 20px;
            color: #777;
        }
        .add-new-button {
            display: inline-block;
            background-color: #17a2b8;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            margin-bottom: 20px;
            transition: background-color 0.3s ease;
        }
        .add-new-button:hover {
            background-color: #138496;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Why-Why Analysis રિપોર્ટ્સ</h2>

        <a href="view_records.php" class="add-new-button">HOME PAGE</a>
		<a href="why_why_form.php" class="add-new-button">નવો Why-Why ફોર્મ ભરો</a>

        <div class="filter-section">
            <form method="GET" action="view_why_why_reports.php" style="display:contents;">
                <div class="filter-group">
                    <label for="start_date">શરૂઆત તારીખ:</label>
                    <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>">
                </div>
                <div class="filter-group">
                    <label for="end_date">અંત તારીખ:</label>
                    <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>">
                </div>
                <div class="filter-group" style="flex-grow: 0;">
                    <button type="submit">ફિલ્ટર કરો</button>
                </div>
            </form>
        </div>

        <?php if (!empty($reports)): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>એનાલિસિસ તારીખ</th>
                        <th>મશીન ID</th>
                        <th>પાર્ટનું નામ</th>
                        <th>મુખ્ય સમસ્યા</th>
                        <th>ટીમ લીડર</th>
                        <th>ભર્યું તારીખ-સમય</th>
                        <th>એક્શન</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reports as $report): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($report['id']); ?></td>
                            <td><?php echo htmlspecialchars($report['analysis_date']); ?></td>
                            <td><?php echo htmlspecialchars($report['machine_id']); ?></td>
                            <td><?php echo htmlspecialchars($report['part_name']); ?></td>
                            <td><?php echo htmlspecialchars(mb_strimwidth($report['problem_statement'], 0, 70, "...")); ?></td>
                            <td><?php echo htmlspecialchars($report['team_leader']); ?></td>
                            <td><?php echo htmlspecialchars($report['created_at']); ?></td>
                            <td>
                                <a href="display_full_why_why_report.php?id=<?php echo htmlspecialchars($report['id']); ?>" class="view-details-btn">જુઓ વિગતો</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="no-records">કોઈ રેકોર્ડ મળ્યા નથી. કૃપા કરીને ફિલ્ટર બદલો અથવા નવો ફોર્મ ભરો.</p>
        <?php endif; ?>
    </div>
</body>
</html>