<?php
// Database connection parameters - **UPDATE THESE WITH YOUR ACTUAL DETAILS**
$servername = "localhost";
$username = "root"; // e.g., "root"
$password = ""; // e.g., "" for XAMPP default
$dbname = "dasp";   // e.g., "cnc_reports"

$conn = null; // Initialize connection variable
$record = null; // Initialize record variable

if (isset($_GET['id'])) {
    $record_id = htmlspecialchars($_GET['id']);

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

        // Fetch training record details
        $stmt_record = $conn->prepare("SELECT * FROM employee_training_records WHERE id = :id");
        $stmt_record->bindParam(':id', $record_id, PDO::PARAM_INT);
        $stmt_record->execute();
        $record = $stmt_record->fetch();

    } catch (PDOException $e) {
        echo "<p style='color: red;'>ડેટાબેઝ ભૂલ: " . $e->getMessage() . "</p>";
    } finally {
        if ($conn) {
            $conn = null; // Close the database connection
        }
    }
}
?>
<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>તાલીમ રેકોર્ડ વિગતો</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f8f9fa;
            color: #333;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            max-width: 800px;
            margin: auto;
            border-top: 5px solid #007bff;
        }
        h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 25px;
            font-size: 2.2em;
        }
        h3 {
            color: #0056b3;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-top: 30px;
            margin-bottom: 20px;
        }
        p {
            margin-bottom: 10px;
            line-height: 1.6;
        }
        strong {
            color: #555;
        }
        .detail-group {
            margin-bottom: 15px;
            background-color: #f9f9f9;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #eee;
        }
        .detail-group p:last-child {
            margin-bottom: 0;
        }
        .back-button {
            display: inline-block;
            background-color: #6c757d;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 30px;
            transition: background-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #5a6268;
        }
        .error-message {
            color: red;
            text-align: center;
            font-size: 1.1em;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if ($record): ?>
            <h2>તાલીમ રેકોર્ડ વિગતો (ID: <?php echo htmlspecialchars($record['id']); ?>)</h2>

            <h3>કર્મચારીની માહિતી</h3>
            <div class="detail-group">
                <p><strong>કર્મચારીનું નામ:</strong> <?php echo htmlspecialchars($record['employee_name']); ?></p>
                <p><strong>કર્મચારી ID:</strong> <?php echo htmlspecialchars($record['employee_id'] ?? 'N/A'); ?></p>
                <p><strong>વિભાગ:</strong> <?php echo htmlspecialchars($record['department'] ?? 'N/A'); ?></p>
            </div>

            <h3>તાલીમની વિગતો</h3>
            <div class="detail-group">
                <p><strong>તાલીમનું શીર્ષક / વિષય:</strong> <?php echo htmlspecialchars($record['training_title']); ?></p>
                <p><strong>તાલીમની તારીખ:</strong> <?php echo htmlspecialchars($record['training_date']); ?></p>
                <p><strong>તાલીમનો પ્રકાર:</strong> <?php echo htmlspecialchars($record['training_type'] ?? 'N/A'); ?></p>
                <p><strong>તાલીમ પ્રદાતા:</strong> <?php echo htmlspecialchars($record['training_provider'] ?? 'N/A'); ?></p>
                <p><strong>તાલીમ આપનારનું નામ:</strong> <?php echo htmlspecialchars($record['trainer_name'] ?? 'N/A'); ?></p>
                <p><strong>તાલીમનો સમયગાળો (કલાકોમાં):</strong> <?php echo htmlspecialchars($record['duration_hours'] ?? 'N/A'); ?></p>
            </div>

            <h3>પરિણામ અને મૂલ્યાંકન</h3>
            <div class="detail-group">
                <p><strong>મૂલ્યાંકન પરિણામો:</strong> <?php echo htmlspecialchars($record['assessment_results'] ?? 'N/A'); ?></p>
                <p><strong>પ્રાપ્ત સક્ષમતા સ્તર:</strong> <?php echo htmlspecialchars($record['competency_level_achieved'] ?? 'N/A'); ?></p>
                <p><strong>આગામી તાલીમની નિયત તારીખ:</strong> <?php echo htmlspecialchars($record['next_training_due_date'] ?? 'N/A'); ?></p>
                <p><strong>નોંધો / ટિપ્પણીઓ:</strong> <?php echo nl2br(htmlspecialchars($record['remarks'] ?? 'N/A')); ?></p>
                <p><strong>રેકોર્ડ બનાવ્યો તારીખ-સમય:</strong> <?php echo htmlspecialchars($record['created_at']); ?></p>
            </div>

            <a href="view_training_reports.php" class="back-button">બધા તાલીમ રિપોર્ટ્સ પર પાછા જાઓ</a>

        <?php else: ?>
            <p class="error-message">માફ કરશો, આ ID માટે કોઈ તાલીમ રેકોર્ડ મળ્યો નથી.</p>
            <a href="view_training_reports.php" class="back-button">બધા તાલીમ રિપોર્ટ્સ પર પાછા જાઓ</a>
        <?php endif; ?>
    </div>
</body>
</html>