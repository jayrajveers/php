<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Production Records</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 20px;
            background-color: #f0f2f5;
            color: #050505;
        }

        .add-button-container {
            margin: 20px 0;
            text-align: center;
        }
        .add-button {
            background-color: #1877f2;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: background-color 0.3s ease;
            border: none;
        }
        .add-button:hover {
            background-color: #166fe6;
        }

        .filter-form-container {
            text-align: center;
            margin-top: 20px;
            margin-bottom: 20px;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .filter-input-group {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
            margin-bottom: 10px;
        }
        .filter-label {
            font-size: 14px;
            font-weight: bold;
            color: #65676b;
        }
        .filter-input {
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccd0d5;
            border-radius: 4px;
            flex-grow: 1;
            min-width: 150px;
        }
        .filter-button, .reset-button {
            background-color: #1877f2;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .filter-button:hover {
            background-color: #166fe6;
        }
        .reset-button {
            background-color: #e4e6eb;
            color: #050505;
        }
        .reset-button:hover {
            background-color: #d8dadf;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            border-radius: 8px;
            overflow-x: auto;
            border: 1px solid #dddfe2;
            background-color: white;
            display: block;
        }
        th, td {
            padding: 10px 12px;
            text-align: center;
            border-bottom: 1px solid #dddfe2;
            white-space: nowrap;
        }
        th {
            background-color: #f0f2f5;
            color: #65676b;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #e9ecef;
        }
        a {
            color: #1877f2;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .edit-button {
            background-color: #e2e8f0;
            color: #1877f2;
            padding: 8px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            margin-right: 5px;
             border: 1px solid #ccd0d5;
        }
        .edit-button:hover {
            background-color: #d2dcf0;
        }
        .delete-button {
            background-color: #f5c6cb;
            color: #dc3545;
            padding: 8px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            cursor: pointer;
            border: 1px solid #e0b4b8;
        }
        .delete-button:hover {
            background-color: #edb3b7;
        }
        .no-records {
            color: #dc3545;
            text-align: center;
            font-weight: bold;
            margin-top: 20px;
        }
        .pagination-top {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 10px;
        }

        .page-button {
            color: #1877F2;
            padding: 6px 10px;
            text-decoration: none;
            border: 1px solid #ddd;
            margin: 0 5px;
            border-radius: 4px;
            font-size: 14px;
        }

        .page-button:hover {
            background-color: #f0f0f0;
        }

        .page-button.active {
            background-color: #1877F2;
            color: white;
            border: 1px solid #1877F2;
        }

        .page-info {
            margin: 0 10px;
            font-size: 20px;
            color: #65676b;
            font-weight: bold;
        }

        .first-last-button{
            color: #1877F2;
            padding: 6px 10px;
            text-decoration: none;
            border: 1px solid #ddd;
            margin: 0 5px;
            border-radius: 4px;
            font-size: 14px;
        }
        .first-last-button:hover {
            background-color: #f0f0f0;
        }

        .pagination-bottom {
            display: none;
        }

    </style>
</head>
<body>

    <div class="container">
        <div class="add-button-container">
            <a href="login.php" class="add-button">Login Page</a>
        </div>

        <div class="filter-form-container">
            <div class="filter-input-group">
                <label for="filterDate" class="filter-label">Date:</label>
                <input type="date" id="filterDate" class="filter-input">

                <label for="filterShift" class="filter-label">Shift:</label>
                <select id="filterShift" class="filter-input">
                    <option value="">All</option>
                    <option value="DAY">DAY</option>
                    <option value="NIGHT">NIGHT</option>
                </select>

                <label for="filterMachineNumber" class="filter-label">Machine Number:</label>
                <input type="text" id="filterMachineNumber" class="filter-input" placeholder="Enter Machine Number">

                <label for="filterPartCode" class="filter-label">Part Code:</label>
                <input type="text" id="filterPartCode" class="filter-input" placeholder="Enter Part Code">
            </div>
            <div class="filter-button-group">
                <button class="filter-button" onclick="filterData()">Search</button>
                <button class="reset-button" onclick="resetFilter()">Reset</button>
                <button id="exportVisibleButton" class="filter-button" onclick="exportVisibleDataToExcel()">Export</button>
            </div>
			
			
        </div>
		

        <h2 align="center">Rejection Data Records</h2>
        <div id="pagination-top" class="pagination-top"></div>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Shift</th>
                    <th>Machine Number</th>
                    <th>Part Code</th>
                    <th>Lot Number</th>
                    <th>Operator</th>
                    <th>Setter</th>
                    <th>Forging OD UNFILL</th>
                    <th>Forging OD LAPING</th>
                    <th>Forging OD CRAKE</th>
                    <th>Forging BORE UNFILL</th>
                    <th>Forging BORE LAPING</th>
                    <th>Forging BORE CRAKE</th>
                    <th>Forging WIDTH UNFILL</th>
                    <th>Forging WIDTH LAPING</th>
                    <th>Forging WIDTH CRAKE</th>
                    <th>Forging TRACK UNFILL</th>
                    <th>Forging TRACK LAPING</th>
                    <th>Forging TRACK CARKE</th>
                    <th>Inhouse</th>
                    <th>Vendor Name</th>
                    <th>Vendor Nos</th>
                    <th>CNC WIDTH</th>
                    <th>CNC ID</th>
                    <th>CNC OD</th>
                    <th>CNC TRACK</th>
                    <th>CNC LOCATION</th>
                    <th>CNC LOADING MISTAKE</th>
                    <th>CNC GROOVE</th>
                    <th>CNC SETTING</th>
                    <th>CNC OTHER</th>
                    <th>Forging Total</th>
                    <th>CNC Total</th>
                    <th>Vendor Total</th>
                    <th>Total</th>
                   </tr>
            </thead>
            <tbody id="rejectionData">
            </tbody>
        </table>
        <div id="pagination-bottom" class="pagination-bottom"></div>
    </div>

    <script>
        let allRejectionData = [];
        const recordsPerPage = 10;
        let currentPage = 1;
        let totalPages = 0;

        function loadRejectionData() {
            fetch('get_rejection_data.php')
                .then(response => response.json())
                .then(data => {
                    allRejectionData = data;
                    displayRejectionData(data, currentPage);
                    updatePagination(data); // Pass the data to calculate total pages
                })
                .catch(error => console.error('Error fetching data:', error));
        }



        function displayRejectionData(data, page) {
            const tableBody = document.getElementById('rejectionData');
            tableBody.innerHTML = '';
            if (data.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="38" class="no-records">No records found</td></tr>';
                return;
            }

            const startIndex = (page - 1) * recordsPerPage;
            const endIndex = startIndex + recordsPerPage;
            const pageData = data.slice(startIndex, endIndex);


            pageData.forEach(record => {
                let row = tableBody.insertRow();
                row.insertCell().textContent = record.ID;
                row.insertCell().textContent = record.EntryDate;
                row.insertCell().textContent = record.Shift;
                row.insertCell().textContent = record.MachineNumber;
                row.insertCell().textContent = record.PartCode;
                row.insertCell().textContent = record.lot_number;
                row.insertCell().textContent = record.Operator;
                row.insertCell().textContent = record.Setter;
                row.insertCell().textContent = record.FORGING_OD_UNFILL;
                row.insertCell().textContent = record.FORGING_OD_LAPING;
                row.insertCell().textContent = record.FORGING_OD_CRAKE;
                row.insertCell().textContent = record.FORGING_BORE_UNFILL;
                row.insertCell().textContent = record.FORGING_BORE_LAPING;
                row.insertCell().textContent = record.FORGING_BORE_CRAKE;
                row.insertCell().textContent = record.FORGING_WIDTH_UNFILL;
                row.insertCell().textContent = record.FORGING_WIDTH_LAPING;
                row.insertCell().textContent = record.FORGING_WIDTH_CRAKE;
                row.insertCell().textContent = record.FORGING_TRACK_UNFILL;
                row.insertCell().textContent = record.FORGING_TRACK_LAPING;
                row.insertCell().textContent = record.FORGING_TRACK_CARKE;
                row.insertCell().textContent = record.INHOUSE;
                row.insertCell().textContent = record.VendorName;
                row.insertCell().textContent = record.vendor_nos;
                row.insertCell().textContent = record.CNC_WIDTH;
                row.insertCell().textContent = record.CNC_ID;
                row.insertCell().textContent = record.CNC_OD;
                row.insertCell().textContent = record.CNC_TRACK;
                row.insertCell().textContent = record.CNC_LOCATION;
                row.insertCell().textContent = record.CNC_LOADING_MISTAKE;
                row.insertCell().textContent = record.CNC_GROOVE;
                row.insertCell().textContent = record.CNC_SETTING;
                row.insertCell().textContent = record.CNC_OTHER;
                row.insertCell().textContent = record.FORGING_TOTAL;
                row.insertCell().textContent = record.CNC_Total;
                row.insertCell().textContent = record.VENDOR_TOTAL;
                row.insertCell().textContent = record.TOTAL;

                let editCell = row.insertCell();
                let editLink = document.createElement('a');
               


            });
        }

        function filterData() {
            const filterDate = document.getElementById('filterDate').value;
            const filterShift = document.getElementById('filterShift').value;
            const filterMachineNumber = document.getElementById('filterMachineNumber').value.toLowerCase();
            const filterPartCode = document.getElementById('filterPartCode').value.toLowerCase();

            const filteredData = allRejectionData.filter(record => {
                const dateMatch = !filterDate || record.EntryDate === filterDate;
                const shiftMatch = !filterShift || record.Shift === filterShift;
                const machineNumberMatch = !filterMachineNumber || record.MachineNumber.toLowerCase().includes(filterMachineNumber);
                const partCodeMatch = !filterPartCode || record.PartCode.toLowerCase().includes(filterPartCode);

                return dateMatch && shiftMatch && machineNumberMatch && partCodeMatch;
            });

            currentPage = 1;
            displayRejectionData(filteredData, currentPage);
            updatePagination(filteredData);
        }

        function resetFilter() {
            document.getElementById('filterDate').value = '';
            document.getElementById('filterShift').value = '';
            document.getElementById('filterMachineNumber').value = '';
            document.getElementById('filterPartCode').value = '';
            currentPage = 1;
            loadRejectionData();
        }

        function updatePagination(filteredData) {
            const paginationTop = document.getElementById('pagination-top');
            const paginationBottom = document.getElementById('pagination-bottom');
            paginationTop.innerHTML = '';
            paginationBottom.innerHTML = '';

            totalPages = Math.ceil(filteredData.length / recordsPerPage);

            if (totalPages <= 1) return;

            const createPageButton = (page, text) => {
                const button = document.createElement('a');
                button.href = '#';
                button.textContent = text;
                button.className = 'page-button';
                if (page === currentPage) {
                    button.classList.add('active');
                }
                button.addEventListener('click', () => {
                    currentPage = page;
                    displayRejectionData(filteredData, currentPage);
                    updatePagination(filteredData);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                });
                return button;
            };

            const createEllipsis = () => {
                const span = document.createElement('span');
                span.textContent = '...';
                span.className = 'page-info';
                return span;
            };

            if (totalPages > 0) {
                paginationTop.appendChild(createPageButton(1, 'First'));
            }

            if (currentPage > 1) {
                paginationTop.appendChild(createPageButton(currentPage - 1, '<'));
            }

            if (totalPages <= 7) {
                for (let i = 1; i <= totalPages; i++) {
                    paginationTop.appendChild(createPageButton(i, i));
                }
            } else {
                if (currentPage <= 3) {
                    for (let i = 1; i <= 4; i++) {
                        paginationTop.appendChild(createPageButton(i, i));
                    }
                    paginationTop.appendChild(createEllipsis());
                    paginationTop.appendChild(createPageButton(totalPages, totalPages));
                } else if (currentPage >= totalPages - 2) {
                    paginationTop.appendChild(createPageButton(1, 1));
                    paginationTop.appendChild(createEllipsis());
                    for (let i = totalPages - 3; i <= totalPages; i++) {
                        paginationTop.appendChild(createPageButton(i, i));
                    }
                } else {
                    paginationTop.appendChild(createPageButton(1, 1));
                    paginationTop.appendChild(createEllipsis());
                    for (let i = currentPage - 1; i <= currentPage + 1; i++) {
                        paginationTop.appendChild(createPageButton(i, i));
                    }
                    paginationTop.appendChild(createEllipsis());
                    paginationTop.appendChild(createPageButton(totalPages, totalPages));
                }
            }

            if (currentPage < totalPages) {
                paginationTop.appendChild(createPageButton(currentPage + 1, '>'));
            }
             if (totalPages > 0) {
                paginationTop.appendChild(createPageButton(totalPages, 'Last'));
            }
        }

        function exportVisibleDataToExcel() {
            const table = document.querySelector('table');
            const thead = table.querySelector('thead');
            const tbody = table.querySelector('tbody');
            const visibleRows = Array.from(tbody.querySelectorAll('tr:not([style*="display: none"])'));

            if (!thead || visibleRows.length === 0) {
                alert('No visible data to export.');
                return;
            }

            const headers = Array.from(thead.querySelectorAll('th')).map(th => th.textContent);
            const dataToSend = visibleRows.map(row => {
                const cells = Array.from(row.querySelectorAll('td')).map(cell => cell.textContent);
                return cells;
            });

            const exportData = {
                headers: headers,
                data: dataToSend
            };

            fetch('export_visible_data.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(exportData),
            })
            .then(response => response.blob())
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'rejection_data.xls';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            })
            .catch(error => {
                console.error('Error exporting data:', error);
                alert('An error occurred during export.');
            });
        }

        loadRejectionData();
    </script>
</body>
</html>
