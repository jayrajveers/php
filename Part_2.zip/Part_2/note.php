<?php
    session_start();

    // Check karo ke user logged in chhe ke nahi.
    if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
        // Jo logged in nathi, to login page par redirect karo.
        header("location: login.php");
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <meta charset="UTF-8">
    <title>Rejection Note</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        /* Custom Theme CSS based on the provided dashboard image */
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif; /* Poppins font for modern look */
            background-color: #f0f2f5; /* Light grey background */
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column; /* Arrange items vertically */
            justify-content: flex-start; /* Align items at the top */
            align-items: center; /* Center items horizontally */
            min-height: 100vh;
        }

        .home-button-container {
            margin-bottom: 20px; /* Add space below the button */
            width: 95%; /* Match container width */
            max-width: 1200px; /* Adjusted to match container max-width */
            text-align: right; /* Align the button to the right */
        }

        .home-button {
            display: inline-block;
            background-color: #4a90e2; /* Primary blue color from dashboard */
            color: #fff;
            border: none;
            padding: 14px 30px; /* Larger padding for button */
            font-size: 17px; /* Larger font size */
            font-weight: bold;
            border-radius: 8px; /* Rounded button */
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Soft shadow */
        }

        .home-button:hover {
            background-color: #357ABD; /* Slightly darker blue on hover */
            transform: translateY(-2px); /* Slight lift effect */
        }

        .container {
            background-color: #ffffff; /* White background for the main form */
            padding: 30px 40px; /* More padding inside container */
            border-radius: 12px; /* More rounded corners like the dashboard cards */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow for depth */
            max-width: 1200px; /* Consistent max-width */
            width: 95%;
            border-top: 5px solid #4a90e2; /* Blue accent line at the top */
        }

        h2 {
            color: #333; /* Darker text for main heading */
            text-align: center;
            margin-bottom: 30px; /* More space below heading */
            font-weight: 600; /* Medium bold */
            font-size: 28px; /* Larger heading */
        }

        form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); /* Adjusted grid columns for better spacing */
            gap: 25px; /* Increased gap between form elements */
        }

        label {
            display: block;
            margin-bottom: 8px; /* Increased margin below labels */
            color: #555; /* Slightly lighter text for labels */
            font-weight: 600; /* Bolder labels */
            font-size: 15px;
        }

        input[type="date"],
        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 12px; /* Increased padding for inputs */
            border-radius: 8px; /* Rounded input fields */
            border: 1px solid #e0e0e0; /* Lighter, more subtle border */
            font-size: 16px;
            background-color: #fcfcfc; /* Very light background for inputs */
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: #4a90e2; /* Blue border on focus */
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.2); /* Soft blue glow on focus */
            outline: none; /* Remove default outline */
        }

        select {
            appearance: none; /* Remove default select arrow */
            background-image: url('data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 14 8" xmlns="http://www.w3.org/2000/svg"><path d="M1 1l6 6 6-6" fill="none" stroke="#666" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>');
            background-repeat: no-repeat;
            background-position: right 12px center;
            background-size: 10px;
        }

        .full-width {
            grid-column: 1 / -1;
            text-align: center;
            margin-top: 15px; /* Space before section heading */
            margin-bottom: 5px; /* Space after section heading */
        }

        h3 {
            color: #4a90e2; /* Blue for section titles */
            font-size: 22px;
            font-weight: 600;
            padding-bottom: 10px;
            border-bottom: 2px solid #e0e0e0; /* Subtle line below section titles */
            display: inline-block; /* Makes border-bottom only as wide as text */
            margin: 0 auto; /* Center the inline-block element */
        }

        button[type="submit"] {
            background-color: #28a745; /* Green submit button */
            color: #fff;
            border: none;
            padding: 14px 25px;
            font-size: 18px;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin-top: 25px;
            width: auto; /* Allow button to size based on content */
            display: block; /* Make it a block element to use margin auto for centering */
            margin-left: auto;
            margin-right: auto;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        button[type="submit"]:hover {
            background-color: #218838; /* Darker green on hover */
            transform: translateY(-2px);
        }

        .image-upload-container {
            display: flex;
            flex-direction: column;
            gap: 10px;
            border: 1px dashed #c1c1c1; /* Dashed border for file upload area */
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        .image-upload-container label[for="images"] {
            text-align: left;
            font-weight: 600;
            color: #4a90e2; /* Blue color for upload label */
            margin-bottom: 5px;
        }

        .image-preview {
            display: flex;
            flex-wrap: wrap; /* Allow images to wrap to next line */
            gap: 10px;
            margin-top: 10px;
            justify-content: center; /* Center images if few */
        }

        .image-preview img {
            max-width: 100px;
            height: auto;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        /* Select2 specific styling to match the theme */
        .select2-container--default .select2-selection--single {
            height: 44px; /* Match input height */
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            background-color: #fcfcfc;
            display: flex;
            align-items: center; /* Vertically align text */
        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 44px; /* Ensure text is centered vertically */
            padding-left: 12px;
            color: #333;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 42px; /* Adjust arrow height */
            right: 5px;
            top: 1px;
        }

        .select2-container--default .select2-results__option--highlighted.select2-results__option--selectable {
            background-color: #4a90e2; /* Highlight color in dropdown */
            color: white;
        }

        .select2-container--default .select2-results__option--selected {
            background-color: #f0f2f5; /* Selected item background */
            color: #333;
        }

        @media (max-width: 768px) {
            form {
                grid-template-columns: 1fr; /* Stack elements on smaller screens */
            }
            .container {
                padding: 20px;
            }
            h2 {
                font-size: 24px;
            }
            h3 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
<script>
    document.addEventListener('keydown', function(event) {
        if (event.ctrlKey && event.key === 'Enter') {
            document.querySelector('form').submit();
        }
    });

    function previewImages(event) {
        const previewContainer = document.getElementById('imagePreview');
        const files = event.target.files;
        previewContainer.innerHTML = ''; // Clear previous previews

        if (files.length > 5) {
            alert("You can upload a maximum of 5 images.");
            event.target.value = ''; // Clear selected files
            return;
        }

        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const reader = new FileReader();

            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                previewContainer.appendChild(img);
            }

            reader.readAsDataURL(file);
        }
    }
</script>
<div class="home-button-container">
    <a href="add_data.php" class="home-button">
        Home Page
    </a>
</div>
<div class="container">
    <h2>Note</h2>
    <form action="note_process.php" method="post" enctype="multipart/form-data">
        <label>Date: <input type="date" name="date" id="date" required></label>
        <label>Shift:<select name="shift" id="shift"><option value="">Select shift</option></select></label>
        <label>Machine Number:<select name="machine_number" id="machine_number"><option value="">Select Machine</option></select></label>
        <label>Part Code: <input type="text" name="ref_number" id="ref_number"></label>
        <label>Lot Number: <input type="text" name="lot_number" id="lot_number" readonly></label>
        <label>Operator: <input type="text" name="operator_name" id="operator_name" readonly></label>
        <label>Setter: <input type="text" name="setter" id="setter" readonly></label>

        <div class="full-width">
            <h3>Image Upload (Max 5)</h3>
        </div>
        <div class="full-width image-upload-container">
            <label for="images">Upload Images:</label>
            <input type="file" id="images" name="images[]" multiple accept="image/*" onchange="previewImages(event)">
            <div id="imagePreview" class="image-preview"></div>
        </div>

        <div class="full-width">
            <h3>Notes</h3>
        </div>
        <label>Notes: <textarea name="notes" rows="4"></textarea></label>

        <div class="full-width">
            <button type="submit">✅ Submit</button>
        </div>
    </form>
</div>
<script>
    $(document).ready(function() {
        $('#date').on('change', function() {
            var selectedDate = $(this).val();
            $('#shift').empty().append('<option value="">Select shift</option>');
            $('#machine_number').empty().append('<option value="">Select Machine</option>');
            $('#ref_number').val('');
            $('#lot_number').val('');
            $('#operator_name').val('');
            $('#setter').val('');

            if (selectedDate) {
                $.ajax({
                    url: 'get_shifts.php', // નવી PHP ફાઇલ
                    type: 'POST',
                    data: { date: selectedDate },
                    dataType: 'json',
                    success: function(data) {
                        var shiftSelect = $('#shift');
                        shiftSelect.empty().append('<option value="">Select shift</option>');
                        $.each(data, function(key, value) {
                            shiftSelect.append('<option value="' + value + '">' + value + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching shifts:", error);
                    }
                });
            }
        });

        $('#shift').on('change', function() {
            var selectedShift = $(this).val();
            var selectedDate = $('#date').val();
            $('#machine_number').empty().append('<option value="">Select Machine</option>');
            $('#ref_number').val('');
            $('#lot_number').val('');
            $('#operator_name').val('');
            $('#setter').val('');

            if (selectedShift && selectedDate) {
                $.ajax({
                    url: 'get_machines.php', // તમારી જૂની get_machines.php ફાઇલ
                    type: 'POST',
                    data: { date: selectedDate, shift: selectedShift },
                    dataType: 'json',
                    success: function(data) {
                        var machineSelect = $('#machine_number');
                        machineSelect.empty().append('<option value="">Select Machine</option>');
                        $.each(data, function(key, value) {
                            machineSelect.append('<option value="' + value + '">' + value + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching machines:", error);
                    }
                });
            }
        });

        $('#machine_number').on('change', function() {
            var selectedMachine = $(this).val();
            var selectedDate = $('#date').val();
            var selectedShift = $('#shift').val();
            if (selectedMachine && selectedDate && selectedShift) {
                $.ajax({
                    url: 'get_machine_details.php',
                    type: 'POST',
                    data: { date: selectedDate, machine: selectedMachine, shift: selectedShift },
                    dataType: 'json',
                    success: function(data) {
                        if (data) {
                            $('#ref_number').val(data.ref_number || '');
                            $('#lot_number').val(data.lot_number || '');
                            $('#operator_name').val(data.operator_name || '');
                            $('#setter').val(data.setter_name || '');
                        } else {
                            $('#ref_number').val('');
                            $('#lot_number').val('');
                            $('#operator_name').val('');
                            $('#setter').val('');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("Error fetching machine details:", error);
                    }
                });
            } else {
                $('#ref_number').val('');
                $('#lot_number').val('');
                $('#operator_name').val('');
                $('#setter').val('');
            }
        });
    });
</script>

</body>
</html>