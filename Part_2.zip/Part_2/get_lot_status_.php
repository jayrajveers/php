<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dasp";
$rejection_dbname = "dasp"; // New database name for rejection data

$conn = new mysqli($servername, $username, $password, $dbname);
$conn_rejection = new mysqli($servername, $username, $password, $rejection_dbname); // New connection for rejection data

if ($conn->connect_error) {
    die("Connection failed (dasp): " . $conn->connect_error);
}

if ($conn_rejection->connect_error) {
    die("Connection failed (dasp - rejectiondata): " . $conn_rejection->connect_error);
}

$partcode = "";
$result_lots = []; // Changed to array
$grand_total_production_setup_2 = 0;

if (isset($_POST['clear'])) {
    $partcode = "";
} elseif (isset($_POST['partcode'])) {
    $partcode = $_POST['partcode'];

    $sql_lots = "SELECT
                        pl.lot_number,
                        MAX(pl.lot_qty) AS lot_qty,
                        SUM(CASE WHEN pl.setup = 2 THEN pl.total_production ELSE 0 END) AS total_production_setup_2,
                        MAX(pl.shift_target) AS target_qty,
                        GROUP_CONCAT(DISTINCT pl.heat_number SEPARATOR ', ') AS heat_numbers,
                        GROUP_CONCAT(DISTINCT pl.grade SEPARATOR ', ') AS grades,
                        GROUP_CONCAT(DISTINCT pl.customer SEPARATOR ', ') AS customers
                    FROM production pl
                    WHERE pl.ref_number LIKE '%$partcode%'
                    GROUP BY pl.lot_number";

    $result_lots_query = $conn->query($sql_lots);
    if ($result_lots_query) {
        while ($row_lot = $result_lots_query->fetch_assoc()) {
            $lot_number = $row_lot['lot_number'];
            $result_lots[$lot_number] = $row_lot;
            $result_lots[$lot_number]['FORGING_TOTAL'] = 0;
            $result_lots[$lot_number]['CNC_Total'] = 0;
            $result_lots[$lot_number]['VENDOR_TOTAL'] = 0;
            $result_lots[$lot_number]['TOTAL_REJECTION'] = 0;

            $sql_rejection = "SELECT
                                            SUM(FORGING_TOTAL) AS FORGING_TOTAL,
                                            SUM(CNC_Total) AS CNC_Total,
                                            SUM(VENDOR_TOTAL) AS VENDOR_TOTAL,
                                            SUM(TOTAL) AS TOTAL_REJECTION
                                        FROM rejectiondata
                                        WHERE PARTCODE LIKE '%$partcode%' AND LOT_NUMBER = '$lot_number'";

            $result_rejection_query = $conn_rejection->query($sql_rejection);
            if ($result_rejection_query && $result_rejection_query->num_rows > 0) {
                $row_rejection = $result_rejection_query->fetch_assoc();
                $result_lots[$lot_number]['FORGING_TOTAL'] = $row_rejection['FORGING_TOTAL'] ?? 0;
                $result_lots[$lot_number]['CNC_Total'] = $row_rejection['CNC_Total'] ?? 0;
                $result_lots[$lot_number]['VENDOR_TOTAL'] = $row_rejection['VENDOR_TOTAL'] ?? 0;
                $result_lots[$lot_number]['TOTAL_REJECTION'] = $row_rejection['TOTAL_REJECTION'] ?? 0;
            }
        }
        $result_lots = array_values($result_lots); // Convert associative array to indexed array
    } else {
        echo "Error fetching lot data: " . $conn->error;
    }

    // Grand total of total_production where setup = 2 for the entire part code
    $sql_grand_total_production_setup_2 = "SELECT SUM(total_production) AS grand_total_production_setup_2
                                                FROM production
                                                WHERE ref_number LIKE '%$partcode%' AND setup = 2";
    $result_grand_total_production_setup_2_result = $conn->query($sql_grand_total_production_setup_2);

    if ($result_grand_total_production_setup_2_result && $result_grand_total_production_setup_2_result->num_rows > 0) {
        $row_grand_total_production_setup_2 = $result_grand_total_production_setup_2_result->fetch_assoc();
        $grand_total_production_setup_2 = $row_grand_total_production_setup_2['grand_total_production_setup_2'];
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Check Lot Status</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 1	0px;
            background-color: #f4f4f4;
        }
        h1, h2 {
            color: #333;
            text-align: center;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            text-align: center;
        }
        input[type="text"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 10px;
        }
        input[type="submit"] {
            background-color: #5cb85c;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .status-done {
            color: green;
            font-weight: bold;
        }
        .status-running {
            color: orange;
            font-weight: bold;
        }
        .no-records {
            color: #777;
            font-style: italic;
            text-align: center;
            padding: 10px;
        }
        .grand-total {
            margin-top: 20px;
            text-align: center;
            font-weight: bold;
            color: #337ab7;
        }
        .clear-button {
            background-color: #d9534f;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 10px;
        }
        .clear-button:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
<div class="container">
    <div style="margin: 20px 0; text-align: center;">
        <a href="login.php" style="
            background-color: #28a745;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: background-color 0.3s ease;
        " onmouseover="this.style.backgroundColor='#218838'" onmouseout="this.style.backgroundColor='#28a745'">
            Login Page
        </a>
    </div>
    <h1>Check Lot Status</h1>
    <form method="post">
        Part Code: <input type="text" name="partcode" value="<?php echo $partcode; ?>">
        <input type="submit" value="Check Status">
        <input type="submit" name="clear" class="clear-button" value="Clear">
    </form>

    <?php if (!empty($result_lots) && $partcode != ""): ?>
        <h2>Lot Status for Part Code: <?php echo $partcode; ?></h2>
        <?php if (count($result_lots) > 0): ?>
            <table border='1'>
    <tr>
                                <th>Customer</th>
                                <th>Lot Number</th>
                                <th>Heat Number</th>
                                <th>Grade</th>
                                <th>Lot Quantity</th>
                                <th>Partcount wise Production</th>
                                <th>Rework Nos</th>
                                <th>Forging Rejection</th>
                                <th>CNC Rejection</th>
                                <th>Vendor Rejection</th>
                                <th>Total Rejection</th>
                                <th>Status</th>
                            </tr>
                            <?php foreach ($result_lots as $row): ?>
                                <?php
                                $lot_number = $row["lot_number"];
                                $lot_qty = $row["lot_qty"];
                                $total_production_setup_2 = $row["total_production_setup_2"];
                                $target_qty = $row["target_qty"];
                                $heat_numbers = $row["heat_numbers"];
                                $grades = $row["grades"];
                                $customers = $row["customers"]; // Retrieve customer(s)
                                $forging_total = $row["FORGING_TOTAL"] ?? 0;
                                $cnc_total = $row["CNC_Total"] ?? 0;
                                $vendor_total = $row["VENDOR_TOTAL"] ?? 0;
                                $total_rejection = $row["TOTAL_REJECTION"] ?? 0;
                                // Calculate Rework Nos and ensure it's not negative
                                $rework_nos = max(0, $total_production_setup_2 - $lot_qty - $total_rejection);
                                $status = (($total_production_setup_2 + $total_rejection) >= $lot_qty) ? "Done" : "Running";
                                $status_class = ($status == "Done") ? "status-done" : "status-running";
                                ?>
                                <tr>
                                    <td><?php echo $customers; ?></td>
                                    <td><?php echo $lot_number; ?></td>
                                    <td><?php echo $heat_numbers; ?></td>
                                    <td><?php echo $grades; ?></td>
                                    <td><?php echo $lot_qty; ?></td>
                                    <td><?php echo $total_production_setup_2; ?></td>
                                    <td><?php echo $rework_nos; ?></td>
                                    <td><?php echo $forging_total; ?></td>
                                    <td><?php echo $cnc_total; ?></td>
                                    <td><?php echo $vendor_total; ?></td>
                                    <td><?php echo $total_rejection; ?></td>
                                    <td class="<?php echo $status_class; ?>"><?php echo $status; ?></td>
                                </tr>
                            <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p class="no-records">No production records found for Part Code: <?php echo $partcode; ?></p>
        <?php endif; ?>

        <h2 class="grand-total">Grand Total Production for Part Code '<?php echo $partcode; ?>': <?php echo $grand_total_production_setup_2; ?></h2>
    <?php endif; ?>

</body>
</html>

<?php
$conn->close();
$conn_rejection->close();
?>